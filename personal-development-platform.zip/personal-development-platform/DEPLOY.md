# Deploy guide — GitHub → Vercel (or Netlify) → custom domain

Total time: ~15 minutes. You need: a GitHub account, a Vercel account (free tier is fine), and a
managed PostgreSQL database (Neon or Supabase — both have free tiers).

The app **requires** a Postgres `DATABASE_URL` in production. The embedded database used for local
development cannot write to a read-only serverless filesystem, and the app fails fast with an
explicit error if `DATABASE_URL` is missing on Vercel/Netlify.

---

## 1. Create the production database

### Option A — Neon (recommended, serverless friendly)

1. Sign in at <https://console.neon.tech> → **Create project** (pick the region closest to you,
   e.g. `ap-southeast-1` for India).
2. Copy the **pooled** connection string. It looks like:
   ```
   postgresql://USER:PASSWORD@ep-xxxx-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
   ```
3. Keep `?sslmode=require` — the driver enables TLS automatically for non-local hosts.

### Option B — Supabase

1. <https://supabase.com/dashboard> → **New project**.
2. **Settings → Database → Connection string → URI**. Use the **Connection pooling** (port `6543`)
   variant, and append `?sslmode=require`.
3. Save the database password — it is only shown once.

> Either way, no extensions are required. UUIDs use PostgreSQL's built-in `gen_random_uuid()`.

---

## 2. Apply the schema

From your machine, against the production database:

```bash
npm install
DATABASE_URL="postgresql://…?sslmode=require" npm run db:migrate
```

That applies the idempotent DDL and refreshes `db/schema.sql`. If you prefer `psql`:

```bash
psql "$DATABASE_URL" -f db/schema.sql
```

Re-running is safe: every statement is `IF NOT EXISTS` / additive.

---

## 3. Push to GitHub

```bash
cd personal-development-platform
git init
git add .
git commit -m "Momentum: personal development platform"
git branch -M main
git remote add origin git@github.com:<you>/personal-development-platform.git
git push -u origin main
```

`.gitignore` already excludes `node_modules`, `.next`, `.env*` and `.data` (your local database).

---

## 4. Deploy on Vercel

1. <https://vercel.com/new> → **Import Git Repository** → pick the repo.
2. Framework preset: **Next.js** (auto-detected). Build command `npm run build`, output handled
   automatically. Node 20+.
3. **Environment Variables** (Production *and* Preview):
   | Key | Value |
   | --- | --- |
   | `DATABASE_URL` | your Postgres URI with `?sslmode=require` |
   | `MIGRATE_ON_START` | `true` for the first deploy, then `false` (optional) |
4. **Deploy**. First build takes ~1–2 minutes.
5. Open the deployment URL → you should land on `/login`. Register an account.

### Netlify alternative

1. <https://app.netlify.com/start> → import the repo.
2. Build command `npm run build`, publish directory `.next`.
3. Install the **Next.js Runtime** plugin (Netlify installs `@netlify/plugin-nextjs` automatically
   for Next projects; if not, add it under *Plugins*).
4. Add the same environment variables under **Site configuration → Environment variables**.
5. Deploy.

> Any Node host works the same way (`npm run build && npm start`) — e.g. Railway, Render, Fly.io —
> as long as `DATABASE_URL` is set.

---

## 5. Custom domain

**Vercel:** Project → **Settings → Domains → Add**. Either use a `*.vercel.app` subdomain or your own
domain. Then at your registrar:

| Record | Name | Value |
| --- | --- | --- |
| `A` | `@` | `76.76.21.21` |
| `CNAME` | `www` | `cname.vercel-dns.com` |

**Netlify:** Domain management → **Add custom domain**, then point `A`/`CNAME` at the values Netlify
shows. TLS certificates are issued automatically on both platforms (a few minutes after DNS
propagates). Because the session cookie is `Secure` in production, always use HTTPS — that is the
default on both hosts.

---

## 6. Post-deploy verification

```bash
BASE=https://your-domain.example

curl -s -o /dev/null -w "%{http_code}\n" $BASE/login            # 200
curl -s -o /dev/null -w "%{http_code}\n" $BASE/                 # 307 -> /login (not authenticated)

# create an account and keep the cookie
curl -s -c /tmp/c.txt -X POST $BASE/api/auth/register \
  -H 'content-type: application/json' \
  -d '{"name":"Test User","email":"test@example.com","password":"secret123"}'

curl -s -b /tmp/c.txt $BASE/api/auth/me                          # 200 with your user
curl -s -b /tmp/c.txt -X POST $BASE/api/water \
  -H 'content-type: application/json' \
  -d '{"date":"2026-11-13","amountMl":250}'                      # 201
```

In the browser: log water, save sleep, add a task, run a 25-minute focus block (or shorten it by
temporarily choosing a 25-minute block and letting it finish), open Analytics, toggle the theme,
then download the JSON export from Settings. Reload the page — everything must still be there.

---

## 7. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `DATABASE_URL is not set` on a deployed build | Add the variable in the host dashboard and redeploy; preview deployments need it too. |
| `password authentication failed` | Wrong password in the URI, or special characters in the password must be URL-encoded (`@` → `%40`). |
| `SSL required` / connection reset | Append `?sslmode=require` to the connection string. |
| `self signed certificate` | Managed providers use valid certs; for a self-hosted PG set a proper CA or use a tunnel. |
| Schema mismatch after an update | Re-run `DATABASE_URL=… npm run db:migrate` (additive and idempotent). |
| Embedded DB warning in the logs | `DATABASE_URL` is empty on a serverless host — expected to fail; configure Postgres. |
| Slow first request after idle | Serverless cold start plus a paused Neon compute; both wake in ~1s. |

---

## 8. Operational notes

* **Backups:** Neon and Supabase take automatic snapshots; in addition, users can export their own
  data as JSON from Settings at any time.
* **Scaling:** all queries are indexed on `(user_id, log_date)` and the driver pool is capped at 5
  connections per instance, which is safe with a pooled Neon/Supabase endpoint.
* **Session cleanup:** expired sessions are deleted opportunistically on login/register.
* **No cron jobs, queues or background workers** are required.
