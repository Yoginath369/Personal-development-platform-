# Momentum — Personal Development Platform

One private, authenticated dashboard for the three things that compound: **physical health,
study productivity and tasks**. Hydration, sleep, activity, nutrition, a timestamp-accurate
Pomodoro timer, a task manager with categories and overdue detection, editable daily goals,
7/30-day analytics with streaks, and a JSON data export.

Mobile-first (360 px → desktop), light/dark/system themes, keyboard accessible, WCAG AA contrast.

---

## 1. Stack

| Layer | Choice | Why |
| --- | --- | --- |
| Framework | **Next.js 15.5 (App Router) + React 19 + TypeScript (strict)** | Server components for the authenticated shell, route handlers for the API, one deployable unit |
| Styling | **Tailwind CSS 3.4** with CSS custom-property design tokens | Theme resolves before paint, no FOUC, no `dark:` variant sprawl |
| Database | **PostgreSQL** (managed: Neon/Supabase) — embedded Postgres (PGlite) locally | Identical SQL and schema in dev and production; no Docker required to run it |
| Driver | `pg` (production) / `@electric-sql/pglite` (local file-backed) | One `query(text, params) → rows` contract in `src/lib/db/client.ts` |
| Auth | Custom sessions: scrypt password hashing, SHA-256 hashed session tokens, httpOnly cookie | No third-party dependency, no secrets in the client, 30-day sliding sessions |
| Validation | **Zod** schemas shared by every write endpoint | Field-level error messages rendered inline |
| Charts | Hand-written SVG (no chart library), lazy-loaded with `next/dynamic` | Zero extra bundle on other pages, accessible data tables included |
| Tests | `node:test` + `tsx` | Timer, date, goal, streak, task and validation logic |

No UI kit, no state library, no ORM — the code is meant to be read.

---

## 2. Architecture

```
Browser (React client components)
   │  fetch('/api/…', credentials: 'same-origin')
   ▼
Route handlers  ──►  requireApiUser()  ──►  repositories  ──►  PostgreSQL
(src/app/api)          (session guard)      (src/lib/db)      (pg or PGlite)
```

* **Route handlers** do four things: authenticate, validate (Zod), call one repository function,
  return JSON. All errors funnel through `src/lib/api/handler.ts` (`422` validation, `401` auth,
  `403` cross-site, `404` missing, `429` rate limit, `500` generic).
* **Repositories** are the only place SQL exists. Every statement is scoped by `user_id`, so
  per-user isolation is structural rather than something a handler has to remember.
* **Client data** is fetched with a small `useResource` hook (abort-on-supersede, keeps stale data
  while refreshing, exposes `reload()`), so every screen has explicit loading / empty / error /
  success states.
* **Timezone rule:** the browser computes the local calendar date (`YYYY-MM-DD`) and sends it with
  every request. The server never guesses "today", so a user in IST gets IST days even if the
  server is in UTC. Rows store a `log_date date` (or `completed_on date`) alongside timestamps.

### Folder tree

```
personal-development-platform/
├── db/schema.sql                  # generated from src/lib/db/schema.ts
├── scripts/
│   ├── migrate.ts                 # npm run db:migrate  (applies schema, rewrites db/schema.sql)
│   └── export-schema.ts           # npm run db:schema   (schema.ts -> db/schema.sql)
├── src/
│   ├── middleware.ts              # edge gate: no session cookie -> /login
│   ├── types/index.ts             # shared domain + API types
│   ├── app/
│   │   ├── layout.tsx             # <html data-theme> from cookie (no flash)
│   │   ├── globals.css            # design tokens, base + component utilities
│   │   ├── (auth)/layout.tsx      # redirects signed-in users away
│   │   ├── (auth)/login/page.tsx
│   │   ├── (auth)/register/page.tsx
│   │   ├── (app)/layout.tsx       # requirePageUser -> AuthProvider/ToastProvider/AppShell
│   │   ├── (app)/page.tsx         # dashboard
│   │   ├── (app)/health/page.tsx
│   │   ├── (app)/study/page.tsx
│   │   ├── (app)/tasks/page.tsx
│   │   ├── (app)/analytics/page.tsx
│   │   ├── (app)/settings/page.tsx
│   │   └── api/                   # auth, settings, summary, water, sleep, activity,
│   │                              # meals, study-sessions, tasks, analytics, export
│   ├── components/
│   │   ├── auth/ dashboard/ health/ study/ tasks/ analytics/ settings/
│   │   ├── layout/  (AppShell, Sidebar, BottomNav, ThemeToggle, LogoutButton)
│   │   ├── shared/  (PageHeader, GoalCard)
│   │   ├── ui/      (ProgressBar, States, ConfirmButton, DeleteDialog)
│   │   └── icons.tsx
│   ├── hooks/
│   │   ├── useAuth.tsx            # user + settings context
│   │   ├── useResource.ts         # fetch/abort/reload
│   │   ├── useToday.ts            # local date + midnight rollover
│   │   ├── useTheme.ts            # cookie + data-theme
│   │   ├── useToast.tsx
│   │   └── usePomodoro.ts         # timestamp-driven timer + persistence
│   └── lib/
│       ├── api/        (client fetch helpers, server handler, errors, rate limit)
│       ├── auth/       (password, session, guard)
│       ├── db/         (client, schema, mappers, repositories/*)
│       ├── logic/      (dates, goals, streak, pomodoro, tasks)  ← pure, unit tested
│       ├── services/   (dashboard, analytics, export)
│       └── validation/schemas.ts
└── tests/              (dates, goals, streak, pomodoro, tasks, validation)
```

---

## 3. Data model

| Table | Purpose | Key constraints |
| --- | --- | --- |
| `users` | account | unique index on `lower(email)` |
| `sessions` | server-side sessions | PK = SHA-256 of the cookie token, `expires_at` |
| `user_settings` | daily goals + theme | 1 row per user, CHECK ranges on every goal |
| `water_logs` | glasses/ml | `amount_ml` 1–5000 per entry, 20 L/day cap enforced in the API |
| `sleep_logs` | hours + quality | `UNIQUE (user_id, log_date)`, hours 0.25–24, quality 1–5 |
| `activity_logs` | steps and exercise | CHECK enforces the steps/exercise shape per `kind` |
| `meals` | meals + calories | calories 1–5000, meal type enum |
| `study_sessions` | completed focus blocks | `UNIQUE (user_id, client_id)` → idempotent logging |
| `tasks` | to-dos | category enum, `due_date`, `completed_on` (local date) |

Full DDL: [`db/schema.sql`](db/schema.sql) — idempotent, safe to re-run.

---

## 4. Run it locally

```bash
git clone <your-repo-url> && cd personal-development-platform
npm install
cp .env.example .env.local        # DATABASE_URL can stay empty for local dev
npm run dev                       # http://localhost:3000
```

With `DATABASE_URL` empty the app starts an **embedded PostgreSQL** and writes it to
`./.data/pgdata` — real Postgres SQL, zero setup, data survives restarts and reloads.
Open `/register`, create an account, and everything you log is stored persistently.

To use a real server instead (recommended before deploying):

```bash
# .env.local
DATABASE_URL=postgresql://user:pass@host:5432/dbname?sslmode=require
npm run db:migrate
```

### Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Dev server on `0.0.0.0:3000` |
| `npm run build` | Production build (fails on type errors) |
| `npm start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm test` | 60 logic/validation tests (`node:test` + `tsx`) |
| `npm run db:migrate` | Apply the schema to `DATABASE_URL` and regenerate `db/schema.sql` |
| `npm run db:schema` | Regenerate `db/schema.sql` without touching a database |

### Environment variables

| Variable | Required | Description |
| --- | --- | --- |
| `DATABASE_URL` | prod | Managed Postgres connection string. Empty = embedded DB. |
| `MIGRATE_ON_START` | no | `true` (default) runs the idempotent schema once per process. Set `false` after a manual migration. |
| `NODE_ENV` | no | `production` on the host; also makes the session cookie `Secure`. |

No secrets are committed; there is deliberately no `NEXT_PUBLIC_*` secret surface.

---

## 5. How the tricky parts work

**Pomodoro accuracy.** The timer stores `startedAt`/`endsAt` epoch timestamps. `setInterval` only
schedules repaints; every tick recomputes `endsAt - Date.now()` through the pure state machine in
`src/lib/logic/pomodoro.ts`. A backgrounded tab, a sleeping laptop or a 2-hour gap produces exactly
the same transitions as a foreground tab: `tick()` emits a `focus-completed` event for the block
that ended, then either starts the break or (if the break also elapsed) returns to idle — it never
logs a wrong duration and never logs twice. In-flight state is mirrored to `localStorage`, so a
reload resumes the run and logs a block that expired while the tab was closed. The server also
deduplicates by `client_id`, so retries are harmless.

**Midnight rollover.** `useToday()` recomputes the local date at exactly the next local midnight,
on `focus` and on `visibilitychange`; every screen keys its queries on that value, so the dashboard
flips to the new day without a reload.

**Streaks.** A day counts when at least one daily goal was hit **or** at least one task was
completed. The streak keeps running until a whole calendar day is missed (today being incomplete
does not break it). Uses the *current* goals over the last 400 days.

**Charts.** `next/dynamic(..., { ssr: false })` code-splits the SVG renderer to the analytics route
only; each chart ships a native `<table>` fallback inside a `<details>` element.

---

## 6. Security notes

* Passwords: scrypt (N=16384, 64-byte key) with a random 16-byte salt per user; comparison is
  `timingSafeEqual`. Login always runs a hash check so response time does not reveal whether an
  email exists.
* Sessions: 32 random bytes, stored only as SHA-256 hash; cookie is `httpOnly`, `SameSite=Lax`,
  `Secure` in production, 30-day expiry. Logout deletes the row server-side.
* Every query is scoped by `user_id`; ids are validated as UUIDs before use.
* State-changing requests reject a cross-origin `Origin` header (in addition to SameSite), and
  login/register are rate limited per IP.
* All input passes through Zod (length, range, enum, real calendar dates); React escapes output,
  no `dangerouslySetInnerHTML` anywhere.
* `middleware.ts` redirects unauthenticated navigation; the app layout re-validates the session
  against the database, so a forged cookie cannot render a page.

---

## 7. Accessibility

Semantic landmarks (`header`/`nav`/`main`/`section`), skip link, every input has a `<label>`
(visually hidden where the design is compact), `aria-invalid` + `aria-describedby` for inline
errors, `role="progressbar"` with `aria-valuetext`, `aria-current="page"` navigation, `aria-pressed`
on toggles, `role="radiogroup"` for quality/theme pickers, live regions for toasts and the timer
phase (but not the per-second count, which would spam screen readers), visible focus rings
everywhere, 44 px minimum touch targets, and `prefers-reduced-motion` support. Contrast targets
WCAG AA in both themes.

---

## 8. Verification

```bash
npm run typecheck   # clean
npm test            # 60 tests, all passing
npm run build       # production build, no errors or warnings
```

Also verified against a running production server with `curl`: registration, duplicate-email 409,
login/logout, 401 after logout, water/sleep/steps/exercise/meal/study writes, validation 422s,
duplicate-task 409, cross-origin 403, task CRUD, summary, 7/30-day analytics, JSON export, and the
auth redirects on every page.

---

## 9. Known limitations

1. **Single user per account, no collaboration/sharing** — the product is explicitly a personal
   dashboard.
2. **Streaks and goal-hit counts use your *current* goals**, not the goals you had on that day
   (goal history is not versioned).
3. **Password reset and email verification are not implemented** — there is no mail provider in
   this deployment. Accounts are created with a password and no recovery flow.
4. **The rate limiter is per-process memory**, so it is approximate on multi-instance hosts; a
   shared Redis store would be the production answer.
5. **Embedded PGlite is for local/dev only** — serverless filesystems are read-only, so a managed
   Postgres `DATABASE_URL` is required in production (the app fails fast with a clear message).
6. **Data export is download-only** — no import/restore feature yet.
7. **No push/email reminders** for goals or due tasks.
8. Sleep is logged as one record per day; naps are not modelled separately.
