import type { Metadata } from 'next';
import { StudyView } from '@/components/study/StudyView';

export const metadata: Metadata = { title: 'Study mode' };

export default function StudyPage() {
  return <StudyView />;
}
