import type { Metadata, Viewport } from 'next';
import { cookies } from 'next/headers';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Momentum · Personal Development Platform',
    template: '%s · Momentum',
  },
  description:
    'Track hydration, sleep, activity, nutrition, study sessions and tasks in one private dashboard.',
  applicationName: 'Momentum',
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

/**
 * The theme is read from the cookie on the server so the very first paint is
 * already correct - no flash of the wrong palette and no blocking inline script.
 */
export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies();
  const cookieTheme = cookieStore.get('pdp_theme')?.value;
  const theme = cookieTheme === 'light' || cookieTheme === 'dark' ? cookieTheme : 'system';

  return (
    <html lang="en" data-theme={theme} suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
