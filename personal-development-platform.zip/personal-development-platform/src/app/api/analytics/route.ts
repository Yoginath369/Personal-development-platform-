import { jsonResponse, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { getAnalytics } from '@/lib/services/analytics';
import { analyticsQuerySchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const query = readQuery(request, analyticsQuerySchema);
  const summary = await getAnalytics(user.id, settings, query);
  return jsonResponse(summary);
});
