import { ApiError } from '@/lib/api/errors';
import { jsonResponse, readJson, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { deleteTask, updateTask } from '@/lib/db/repositories/tasks';
import { taskUpdateSchema } from '@/lib/validation/schemas';
import { todayISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const PATCH = route(async (request, context: { params: Promise<{ id: string }> }) => {
  const { user } = await requireApiUser();
  const { id } = await context.params;
  if (!UUID.test(id)) throw new ApiError(400, 'Invalid task id.');

  const input = await readJson(request, taskUpdateSchema);
  const task = await updateTask(user.id, id, { ...input, today: todayISO() });
  if (!task) throw new ApiError(404, 'That task no longer exists.');
  return jsonResponse({ task });
});

export const DELETE = route(async (_request, context: { params: Promise<{ id: string }> }) => {
  const { user } = await requireApiUser();
  const { id } = await context.params;
  if (!UUID.test(id)) throw new ApiError(400, 'Invalid task id.');

  const deleted = await deleteTask(user.id, id);
  if (!deleted) throw new ApiError(404, 'That task no longer exists.');
  return jsonResponse({ ok: true });
});
