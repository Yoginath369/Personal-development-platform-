import { ApiError } from '@/lib/api/errors';
import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { createTask, duplicateTaskExists, listTasks } from '@/lib/db/repositories/tasks';
import { taskCreateSchema, taskListQuerySchema } from '@/lib/validation/schemas';
import { todayISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user } = await requireApiUser();
  const query = readQuery(request, taskListQuerySchema);
  const today = new URL(request.url).searchParams.get('today') ?? todayISO();

  const tasks = await listTasks(user.id, {
    status: query.status,
    category: query.category,
    search: query.q,
    today,
  });
  return jsonResponse({ tasks, today });
});

export const POST = route(async (request) => {
  const { user } = await requireApiUser();
  const input = await readJson(request, taskCreateSchema);

  if (await duplicateTaskExists(user.id, input.title, input.dueDate)) {
    throw new ApiError(409, 'You already have an open task with that title.', {
      title: ['An open task with this title already exists.'],
    });
  }

  const task = await createTask(user.id, {
    title: input.title,
    notes: input.notes,
    category: input.category,
    dueDate: input.dueDate,
  });
  return jsonResponse({ task }, 201);
});
