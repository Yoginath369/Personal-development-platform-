import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import {
  addExercise,
  addSteps,
  getActivityEntries,
  getDayActivityTotals,
} from '@/lib/db/repositories/activity';
import { activityCreateSchema, activityQuerySchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, activityQuerySchema);
  const [entries, totals] = await Promise.all([
    getActivityEntries(user.id, date),
    getDayActivityTotals(user.id, date),
  ]);
  return jsonResponse({
    date,
    steps: totals.steps,
    stepsGoal: settings.stepsGoal,
    exerciseMinutes: totals.exerciseMinutes,
    walkCount: totals.walkCount,
    entries,
  });
});

export const POST = route(async (request) => {
  const { user } = await requireApiUser();
  const input = await readJson(request, activityCreateSchema);

  if (input.kind === 'steps') {
    const totals = await getDayActivityTotals(user.id, input.date);
    const entry = await addSteps(user.id, input.date, input.steps);
    return jsonResponse({ entry, steps: totals.steps + input.steps }, 201);
  }

  const entry = await addExercise(user.id, input.date, input.exerciseType, input.durationMinutes);
  return jsonResponse({ entry }, 201);
});
