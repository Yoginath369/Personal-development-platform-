import { route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { buildUserExport } from '@/lib/services/export';
import { todayISO } from '@/lib/logic/dates';
import { jsonResponse } from '@/lib/api/handler';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const { user, settings } = await requireApiUser();
  const payload = await buildUserExport(user, settings, todayISO());
  const body = JSON.stringify(payload, null, 2);

  return new Response(body, {
    status: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'content-disposition': `attachment; filename="pdp-export-${todayISO()}.json"`,
      'cache-control': 'no-store',
    },
  });
});

export const POST = route(async () => {
  // Same payload, but returned inline so the settings screen can preview it.
  const { user, settings } = await requireApiUser();
  const payload = await buildUserExport(user, settings, todayISO());
  return jsonResponse(payload);
});
