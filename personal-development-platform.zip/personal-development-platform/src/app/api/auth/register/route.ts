import { ApiError } from '@/lib/api/errors';
import { jsonResponse, readJson, route } from '@/lib/api/handler';
import { clientIp, rateLimit } from '@/lib/api/rate-limit';
import { hashPassword } from '@/lib/auth/password';
import { startSession } from '@/lib/auth/session';
import { deleteExpiredSessions } from '@/lib/db/repositories/sessions';
import { createUser, findUserByEmail, getSettings } from '@/lib/db/repositories/users';
import { registerSchema } from '@/lib/validation/schemas';
import { todayISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = route(async (request) => {
  const limit = rateLimit(`register:${clientIp(request)}`, 10, 60 * 60 * 1000);
  if (!limit.ok) {
    throw new ApiError(429, 'Too many accounts created from this device. Try again later.');
  }

  const input = await readJson(request, registerSchema);

  const existing = await findUserByEmail(input.email);
  if (existing) {
    throw new ApiError(409, 'That email is already registered. Try signing in instead.', {
      email: ['That email is already registered.'],
    });
  }

  const passwordHash = await hashPassword(input.password);
  const user = await createUser({ email: input.email, name: input.name, passwordHash });
  const settings = await getSettings(user.id);

  await deleteExpiredSessions().catch(() => undefined);
  await startSession(user.id);

  return jsonResponse({ user, settings, today: todayISO() }, 201);
});
