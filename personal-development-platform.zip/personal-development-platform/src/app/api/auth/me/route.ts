import { jsonResponse, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { todayISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const { user, settings } = await requireApiUser();
  return jsonResponse({ user, settings, today: todayISO() });
});
