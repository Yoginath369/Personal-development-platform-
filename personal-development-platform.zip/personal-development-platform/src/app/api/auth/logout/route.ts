import { jsonResponse, route } from '@/lib/api/handler';
import { endSession } from '@/lib/auth/session';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = route(async () => {
  await endSession();
  return jsonResponse({ ok: true });
});
