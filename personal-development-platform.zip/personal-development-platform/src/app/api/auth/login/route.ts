import { ApiError } from '@/lib/api/errors';
import { jsonResponse, readJson, route } from '@/lib/api/handler';
import { clientIp, rateLimit } from '@/lib/api/rate-limit';
import { verifyPassword } from '@/lib/auth/password';
import { startSession } from '@/lib/auth/session';
import { deleteExpiredSessions } from '@/lib/db/repositories/sessions';
import { findUserByEmail, getSettings } from '@/lib/db/repositories/users';
import { loginSchema } from '@/lib/validation/schemas';
import { todayISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = route(async (request) => {
  const limit = rateLimit(`login:${clientIp(request)}`, 15, 10 * 60 * 1000);
  if (!limit.ok) {
    throw new ApiError(
      429,
      `Too many sign-in attempts. Please wait ${limit.retryAfterSeconds}s and try again.`,
    );
  }

  const input = await readJson(request, loginSchema);
  const found = await findUserByEmail(input.email);

  // Constant-ish time: always run a verification so timing does not reveal
  // whether the email exists.
  const hash = found?.passwordHash ?? 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';
  const valid = await verifyPassword(input.password, hash);

  if (!found || !valid) {
    throw new ApiError(401, 'Email or password is incorrect.');
  }

  await deleteExpiredSessions().catch(() => undefined);
  await startSession(found.user.id);
  const settings = await getSettings(found.user.id);

  return jsonResponse({ user: found.user, settings, today: todayISO() });
});
