import { jsonResponse, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { getDashboardSummary } from '@/lib/services/dashboard';
import { z } from 'zod';
import { isoDateField } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const summaryQuery = z.object({ date: isoDateField.optional() });

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, summaryQuery);
  const summary = await getDashboardSummary(user.id, settings, date);
  return jsonResponse(summary);
});
