import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { deleteSleep, getSleep, upsertSleep } from '@/lib/db/repositories/sleep';
import { sleepQuerySchema, sleepWriteSchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, sleepQuerySchema);
  const entry = await getSleep(user.id, date);
  return jsonResponse({ date, entry, goalHours: settings.sleepGoalHours });
});

export const PUT = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const input = await readJson(request, sleepWriteSchema);
  const entry = await upsertSleep(user.id, input.date, input.hours, input.quality);
  return jsonResponse({ date: input.date, entry, goalHours: settings.sleepGoalHours });
});

export const DELETE = route(async (request) => {
  const { user } = await requireApiUser();
  const { date } = readQuery(request, sleepQuerySchema);
  await deleteSleep(user.id, date);
  return jsonResponse({ ok: true, date });
});
