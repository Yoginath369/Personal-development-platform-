import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { addMeal, getCalorieTotals, getMeals } from '@/lib/db/repositories/meals';
import { mealCreateSchema, nutritionQuerySchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, nutritionQuerySchema);
  const [entries, totals] = await Promise.all([
    getMeals(user.id, date),
    getCalorieTotals(user.id, date, date),
  ]);
  return jsonResponse({
    date,
    totalCalories: totals.get(date) ?? 0,
    calorieLimit: settings.calorieLimit,
    entries,
  });
});

export const POST = route(async (request) => {
  const { user } = await requireApiUser();
  const input = await readJson(request, mealCreateSchema);
  const entry = await addMeal(user.id, input);
  const totals = await getCalorieTotals(user.id, input.date, input.date);
  return jsonResponse({ entry, totalCalories: totals.get(input.date) ?? 0 }, 201);
});
