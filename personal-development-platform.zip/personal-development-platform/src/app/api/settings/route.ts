import { jsonResponse, readJson, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { updateSettings } from '@/lib/db/repositories/users';
import { settingsPatchSchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const { settings } = await requireApiUser();
  return jsonResponse({ settings });
});

export const PATCH = route(async (request) => {
  const { user } = await requireApiUser();
  const patch = await readJson(request, settingsPatchSchema);
  const settings = await updateSettings(user.id, patch);
  return jsonResponse({ settings });
});
