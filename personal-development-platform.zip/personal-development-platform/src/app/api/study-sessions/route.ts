import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import {
  addSession,
  getDayMinutes,
  getRecentSubjects,
  getSessions,
} from '@/lib/db/repositories/study';
import { getDailyMinutes } from '@/lib/db/repositories/study';
import { studyCreateSchema, studyQuerySchema } from '@/lib/validation/schemas';
import { addDaysISO } from '@/lib/logic/dates';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, studyQuerySchema);
  const weekStart = addDaysISO(date, -6);

  const [sessions, totalMinutes, week, subjects] = await Promise.all([
    getSessions(user.id, date),
    getDayMinutes(user.id, date),
    getDailyMinutes(user.id, weekStart, date),
    getRecentSubjects(user.id),
  ]);

  return jsonResponse({
    date,
    totalMinutes,
    goalMinutes: settings.studyGoalMinutes,
    sessions,
    subjects,
    last7Days: Array.from({ length: 7 }, (_, index) => {
      const day = addDaysISO(weekStart, index);
      return { date: day, minutes: week.get(day) ?? 0 };
    }),
  });
});

export const POST = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const input = await readJson(request, studyCreateSchema);

  const { session, created } = await addSession(user.id, input);
  const totalMinutes = await getDayMinutes(user.id, input.date);

  return jsonResponse(
    { session, created, totalMinutes, goalMinutes: settings.studyGoalMinutes, date: input.date },
    created ? 201 : 200,
  );
});
