import { ApiError } from '@/lib/api/errors';
import { jsonResponse, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { deleteWater } from '@/lib/db/repositories/water';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const DELETE = route(async (_request, context: { params: Promise<{ id: string }> }) => {
  const { user } = await requireApiUser();
  const { id } = await context.params;
  if (!UUID.test(id)) throw new ApiError(400, 'Invalid entry id.');

  const deleted = await deleteWater(user.id, id);
  if (!deleted) throw new ApiError(404, 'That entry no longer exists.');
  return jsonResponse({ ok: true });
});
