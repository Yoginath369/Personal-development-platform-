import { ApiError } from '@/lib/api/errors';
import { jsonResponse, readJson, readQuery, route } from '@/lib/api/handler';
import { requireApiUser } from '@/lib/auth/guard';
import { addWater, getWaterEntries, getWaterTotal } from '@/lib/db/repositories/water';
import { waterCreateSchema, waterQuerySchema } from '@/lib/validation/schemas';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const { date } = readQuery(request, waterQuerySchema);
  const [entries, totalMl] = await Promise.all([
    getWaterEntries(user.id, date),
    getWaterTotal(user.id, date),
  ]);
  return jsonResponse({ date, totalMl, goalMl: settings.waterGoalMl, entries });
});

export const POST = route(async (request) => {
  const { user, settings } = await requireApiUser();
  const input = await readJson(request, waterCreateSchema);

  const total = await getWaterTotal(user.id, input.date);
  if (total + input.amountMl > 20000) {
    throw new ApiError(422, 'That would exceed the 20 L daily safety cap for this day.', {
      amountMl: ['Daily total cannot exceed 20 L.'],
    });
  }

  const entry = await addWater(user.id, input.date, input.amountMl);
  const totalMl = total + input.amountMl;

  return jsonResponse(
    { entry, totalMl, goalMl: settings.waterGoalMl, date: input.date },
    201,
  );
});
