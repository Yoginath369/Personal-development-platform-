import { Suspense } from 'react';
import type { Metadata } from 'next';
import { AuthForm } from '@/components/auth/AuthForm';
import { LoadingBlock } from '@/components/ui/States';

export const metadata: Metadata = { title: 'Sign in' };

export default function LoginPage() {
  return (
    <Suspense fallback={<LoadingBlock label="Loading sign in form" rows={3} />}>
      <AuthForm mode="login" />
    </Suspense>
  );
}
