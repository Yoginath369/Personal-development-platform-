import Link from 'next/link';
import { redirect } from 'next/navigation';
import { currentSession } from '@/lib/auth/guard';

export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const session = await currentSession();
  if (session) redirect('/');

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link href="/login" className="flex items-center gap-2 rounded-lg focus-visible:outline-none">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-accent-ink">
            <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true">
              <path d="M4 18V9m5 9V5m5 13v-6m5 6V8" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" fill="none" />
            </svg>
          </span>
          <span className="text-base font-semibold tracking-tight">Momentum</span>
        </Link>
        <span className="text-xs text-muted">Personal development platform</span>
      </header>

      <main id="main" className="flex flex-1 items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <div className="w-full max-w-md">{children}</div>
      </main>

      <footer className="mx-auto w-full max-w-6xl px-4 pb-6 text-center text-xs text-muted sm:px-6">
        Your data is private to your account.
      </footer>
    </div>
  );
}
