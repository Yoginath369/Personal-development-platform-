import { Suspense } from 'react';
import type { Metadata } from 'next';
import { AuthForm } from '@/components/auth/AuthForm';
import { LoadingBlock } from '@/components/ui/States';

export const metadata: Metadata = { title: 'Create account' };

export default function RegisterPage() {
  return (
    <Suspense fallback={<LoadingBlock label="Loading sign up form" rows={3} />}>
      <AuthForm mode="register" />
    </Suspense>
  );
}
