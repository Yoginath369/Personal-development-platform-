/**
 * Shared domain types. These describe the exact shapes the API returns so the
 * client and server cannot drift apart.
 */

export type ThemePreference = 'light' | 'dark' | 'system';

export type TaskCategory = 'study' | 'personal' | 'fitness' | 'work';

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export type ActivityKind = 'steps' | 'exercise';

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface Settings {
  waterGoalMl: number;
  sleepGoalHours: number;
  stepsGoal: number;
  calorieLimit: number;
  studyGoalMinutes: number;
  theme: ThemePreference;
}

export interface WaterEntry {
  id: string;
  amountMl: number;
  loggedAt: string;
}

export interface WaterDay {
  date: string;
  totalMl: number;
  goalMl: number;
  entries: WaterEntry[];
}

export interface SleepEntry {
  date: string;
  hours: number;
  quality: number;
  updatedAt: string;
}

export interface SleepDay {
  date: string;
  entry: SleepEntry | null;
  goalHours: number;
}

export interface ActivityEntry {
  id: string;
  kind: ActivityKind;
  steps: number | null;
  exerciseType: string | null;
  durationMinutes: number | null;
  loggedAt: string;
}

export interface ActivityDay {
  date: string;
  steps: number;
  stepsGoal: number;
  exerciseMinutes: number;
  walkCount: number;
  entries: ActivityEntry[];
}

export interface MealEntry {
  id: string;
  mealType: MealType;
  name: string;
  calories: number;
  loggedAt: string;
}

export interface NutritionDay {
  date: string;
  totalCalories: number;
  calorieLimit: number;
  entries: MealEntry[];
}

export interface StudySession {
  id: string;
  subject: string;
  focusMinutes: number;
  startedAt: string;
  endedAt: string;
  completed: boolean;
}

export interface StudyDay {
  date: string;
  totalMinutes: number;
  goalMinutes: number;
  sessions: StudySession[];
  last7Days: Array<{ date: string; minutes: number }>;
}

export interface Task {
  id: string;
  title: string;
  notes: string | null;
  category: TaskCategory;
  dueDate: string | null;
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface DayMetrics {
  date: string;
  waterMl: number;
  sleepHours: number | null;
  sleepQuality: number | null;
  steps: number;
  exerciseMinutes: number;
  calories: number;
  studyMinutes: number;
  tasksCompleted: number;
}

export interface GoalDefinition {
  key: 'water' | 'sleep' | 'steps' | 'study' | 'calories';
  label: string;
  target: number;
  unit: string;
}

export interface AnalyticsSummary {
  range: { start: string; end: string; days: number };
  goals: Settings;
  days: DayMetrics[];
  totals: {
    waterMl: number;
    sleepHours: number;
    steps: number;
    exerciseMinutes: number;
    calories: number;
    studyMinutes: number;
    tasksCompleted: number;
  };
  averages: {
    waterMl: number;
    sleepHours: number;
    steps: number;
    studyMinutes: number;
    calories: number;
  };
  goalHitDays: {
    water: number;
    sleep: number;
    steps: number;
    study: number;
  };
  streak: number;
  bestStreak: number;
}

export interface DashboardSummary {
  today: string;
  goals: Settings;
  water: WaterDay;
  sleep: SleepDay;
  activity: ActivityDay;
  nutrition: NutritionDay;
  study: StudyDay;
  tasks: { open: Task[]; completedToday: number; overdue: number };
  streak: number;
}

export interface ApiErrorBody {
  error: string;
  fieldErrors?: Record<string, string[]>;
}
