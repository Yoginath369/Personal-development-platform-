import { NextResponse, type NextRequest } from 'next/server';

const SESSION_COOKIE = 'pdp_session';
const AUTH_PAGES = ['/login', '/register'];

/**
 * Fast edge gate: no session cookie -> /login. The authoritative check happens
 * server-side in the app layout (which validates the session against the DB).
 */
export function middleware(request: NextRequest) {
  const token = request.cookies.get(SESSION_COOKIE)?.value;
  const { pathname, search } = request.nextUrl;
  const isAuthPage = AUTH_PAGES.includes(pathname);

  if (!token && !isAuthPage) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    url.search = pathname === '/' ? '' : `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  if (token && isAuthPage) {
    const url = request.nextUrl.clone();
    url.pathname = '/';
    url.search = '';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  // API routes authenticate themselves and return 401 JSON instead of redirects.
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico|icon.svg).*)'],
};
