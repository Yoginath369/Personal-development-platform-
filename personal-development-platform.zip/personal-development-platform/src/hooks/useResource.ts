'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { apiFetch, describeError, isAbortError } from '@/lib/api/client';

export interface ResourceState<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
  refreshing: boolean;
}

export interface Resource<T> extends ResourceState<T> {
  reload: () => Promise<void>;
  setData: (updater: T | ((current: T | null) => T)) => void;
}

/**
 * Minimal data-fetching hook (no external state library):
 *  - auto-aborts superseded requests so late responses cannot clobber newer data
 *  - keeps previous data while refreshing (no layout thrash)
 *  - exposes `setData` for optimistic updates
 */
export function useResource<T>(url: string | null): Resource<T> {
  const [state, setState] = useState<ResourceState<T>>({
    data: null,
    error: null,
    loading: Boolean(url),
    refreshing: false,
  });

  const controllerRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      controllerRef.current?.abort();
    };
  }, []);

  const load = useCallback(
    async (urlToLoad: string | null) => {
      if (!urlToLoad) {
        setState({ data: null, error: null, loading: false, refreshing: false });
        return;
      }

      controllerRef.current?.abort();
      const controller = new AbortController();
      controllerRef.current = controller;

      setState((current) => ({
        ...current,
        loading: current.data === null,
        refreshing: current.data !== null,
        error: null,
      }));

      try {
        const data = await apiFetch<T>(urlToLoad, { signal: controller.signal });
        if (!mountedRef.current || controller.signal.aborted) return;
        setState({ data, error: null, loading: false, refreshing: false });
      } catch (error) {
        if (isAbortError(error) || !mountedRef.current || controller.signal.aborted) return;
        setState((current) => ({
          ...current,
          error: describeError(error),
          loading: false,
          refreshing: false,
        }));
      }
    },
    [],
  );

  const urlRef = useRef<string | null>(url);
  urlRef.current = url;

  useEffect(() => {
    void load(url);
  }, [url, load]);

  const reload = useCallback(async () => {
    await load(urlRef.current);
  }, [load]);

  const setData = useCallback((updater: T | ((current: T | null) => T)) => {
    setState((current) => ({
      ...current,
      data:
        typeof updater === 'function'
          ? (updater as (current: T | null) => T)(current.data)
          : updater,
    }));
  }, []);

  return { ...state, reload, setData };
}
