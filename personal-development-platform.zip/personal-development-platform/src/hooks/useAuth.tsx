'use client';

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Settings, User } from '@/types';
import { useThemeSync } from './useTheme';

interface AuthContextValue {
  user: User;
  settings: Settings;
  updateSettings: (next: Settings) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({
  user,
  settings: initialSettings,
  children,
}: {
  user: User;
  settings: Settings;
  children: ReactNode;
}) {
  const [settings, setSettings] = useState<Settings>(initialSettings);

  // Keeps <html data-theme> in sync with the stored preference (incl. after a
  // settings save that came back from the server).
  useThemeSync(settings.theme);

  const updateSettings = useCallback((next: Settings) => setSettings(next), []);
  const value = useMemo(
    () => ({ user, settings, updateSettings }),
    [user, settings, updateSettings],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside <AuthProvider>');
  return context;
}
