'use client';

import { useCallback, useEffect } from 'react';
import type { ThemePreference } from '@/types';

export const THEME_COOKIE = 'pdp_theme';

/**
 * Applies the theme via `data-theme` on <html>. The server reads the same cookie
 * so the first paint already uses the right palette (no flash of wrong theme).
 * `system` is resolved by a CSS media query, so it updates live with the OS.
 */
export function applyTheme(theme: ThemePreference): void {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.theme = theme;
  document.cookie = `${THEME_COOKIE}=${theme}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
}

export function useThemeSync(theme: ThemePreference): void {
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);
}

export function useThemeSwitcher(current: ThemePreference, onChange: (theme: ThemePreference) => void) {
  const setTheme = useCallback(
    (theme: ThemePreference) => {
      applyTheme(theme);
      onChange(theme);
    },
    [onChange],
  );
  return { theme: current, setTheme };
}
