'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  deserializePomodoro,
  initialPomodoroState,
  pause as pauseState,
  remainingMs,
  reset as resetState,
  resume as resumeState,
  serializePomodoro,
  setFocusMinutes as setFocusMinutesState,
  setSubject as setSubjectState,
  startFocus,
  tick,
  type PomodoroEvent,
  type PomodoroState,
} from '@/lib/logic/pomodoro';
import { localDateFromTimestamp } from '@/lib/logic/dates';

export interface CompletedFocus {
  clientId: string;
  subject: string;
  focusMinutes: number;
  startedAt: number;
  endedAt: number;
  date: string;
}

interface Options {
  storageKey: string;
  initialSubject?: string;
  onFocusComplete: (session: CompletedFocus) => void;
  onBreakComplete?: () => void;
}

export interface PomodoroController {
  state: PomodoroState;
  /** Live remaining milliseconds, recomputed from timestamps on every render tick. */
  remaining: number;
  now: number;
  ready: boolean;
  start: () => void;
  pause: () => void;
  resume: () => void;
  reset: () => void;
  chooseFocusMinutes: (minutes: number) => void;
  changeSubject: (subject: string) => void;
}

/**
 * Timestamp-driven Pomodoro controller.
 *
 * `setInterval` is used ONLY to schedule repaints. All state transitions are
 * derived from `Date.now()` vs the stored `endsAt`, so a throttled/background
 * tab (or a closed tab that is reopened later) computes exactly the same result
 * as a foreground tab would have.
 */
export function usePomodoro({
  storageKey,
  initialSubject = '',
  onFocusComplete,
  onBreakComplete,
}: Options): PomodoroController {
  const [state, setState] = useState<PomodoroState>(() => initialPomodoroState(initialSubject));
  const [now, setNow] = useState<number>(() => Date.now());
  const [ready, setReady] = useState(false);

  const stateRef = useRef(state);
  stateRef.current = state;

  const onFocusCompleteRef = useRef(onFocusComplete);
  onFocusCompleteRef.current = onFocusComplete;
  const onBreakCompleteRef = useRef(onBreakComplete);
  onBreakCompleteRef.current = onBreakComplete;

  const handledRef = useRef<Set<string>>(new Set());

  const emit = useCallback((events: PomodoroEvent[], at: number) => {
    for (const event of events) {
      if (event.type === 'focus-completed') {
        const key = event.session.clientId;
        if (handledRef.current.has(key)) continue;
        handledRef.current.add(key);
        onFocusCompleteRef.current({
          clientId: event.session.clientId,
          subject: event.session.subject,
          focusMinutes: event.session.focusMinutes,
          startedAt: event.session.startedAt,
          endedAt: event.session.endedAt,
          date: localDateFromTimestamp(at),
        });
      } else {
        onBreakCompleteRef.current?.();
      }
    }
  }, []);

  /** Advance the machine to "now" and notify listeners of finished blocks. */
  const step = useCallback(() => {
    const current = stateRef.current;
    const timestamp = Date.now();
    const { state: next, events } = tick(current, timestamp);
    if (next !== current) {
      stateRef.current = next;
      setState(next);
    }
    setNow(timestamp);
    if (events.length > 0) emit(events, timestamp);
  }, [emit]);

  // Restore a running timer after a reload (including one that expired while away).
  useEffect(() => {
    let restored = initialPomodoroState(initialSubject);
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) restored = deserializePomodoro(JSON.parse(raw), initialSubject);
    } catch {
      restored = initialPomodoroState(initialSubject);
    }

    const timestamp = Date.now();
    const { state: caughtUp, events } = tick(restored, timestamp);
    stateRef.current = caughtUp;
    setState(caughtUp);
    setNow(timestamp);
    setReady(true);
    if (events.length > 0) emit(events, timestamp);

    return () => {
      handledRef.current.clear();
    };
  }, [storageKey, initialSubject, emit]);

  // Persist so a reload (or accidental close) never loses an in-flight session.
  useEffect(() => {
    if (!ready) return;
    try {
      if (state.phase === 'idle' && state.pausedRemainingMs === null) {
        window.localStorage.removeItem(storageKey);
      } else {
        window.localStorage.setItem(storageKey, JSON.stringify(serializePomodoro(state)));
      }
    } catch {
      /* storage may be unavailable (private mode) - timer still works in memory */
    }
  }, [state, ready, storageKey]);

  // Repaint loop - only while a block is actually running.
  useEffect(() => {
    if (!ready) return;
    const running = state.phase !== 'idle' && state.pausedRemainingMs === null;
    if (!running) return;

    step();
    const interval = window.setInterval(step, 250);
    const onVisible = () => {
      if (document.visibilityState === 'visible') step();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);

    return () => {
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
    };
  }, [ready, state.phase, state.pausedRemainingMs, step]);

  const start = useCallback(() => {
    const timestamp = Date.now();
    const subject = stateRef.current.subject.trim() || 'General';
    const sessionId = globalThis.crypto?.randomUUID?.() ?? `focus-${timestamp}-${Math.random().toString(36).slice(2, 10)}`;
    const next = startFocus({ ...stateRef.current, subject }, timestamp, sessionId);
    stateRef.current = next;
    setState(next);
    setNow(timestamp);
  }, []);

  const pause = useCallback(() => {
    const next = pauseState(stateRef.current, Date.now());
    stateRef.current = next;
    setState(next);
    setNow(Date.now());
  }, []);

  const resume = useCallback(() => {
    const timestamp = Date.now();
    const next = resumeState(stateRef.current, timestamp);
    stateRef.current = next;
    setState(next);
    setNow(timestamp);
  }, []);

  const reset = useCallback(() => {
    const next = resetState(stateRef.current);
    stateRef.current = next;
    setState(next);
    setNow(Date.now());
  }, []);

  const chooseFocusMinutes = useCallback((minutes: number) => {
    const next = setFocusMinutesState(stateRef.current, minutes);
    stateRef.current = next;
    setState(next);
  }, []);

  const changeSubject = useCallback((subject: string) => {
    const next = setSubjectState(stateRef.current, subject.slice(0, 60));
    stateRef.current = next;
    setState(next);
  }, []);

  return {
    state,
    remaining: remainingMs(state, now),
    now,
    ready,
    start,
    pause,
    resume,
    reset,
    chooseFocusMinutes,
    changeSubject,
  };
}
