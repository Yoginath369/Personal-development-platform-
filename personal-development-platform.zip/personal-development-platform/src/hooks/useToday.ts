'use client';

import { useEffect, useState } from 'react';
import { msUntilNextMidnight, todayISO } from '@/lib/logic/dates';

/**
 * The user's local calendar date, refreshed exactly at local midnight (and when
 * the tab regains focus) so the dashboard rolls over without a reload.
 */
export function useToday(): string {
  const [today, setToday] = useState<string>(() => todayISO());

  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;

    const arm = () => {
      timeout = setTimeout(() => {
        setToday(todayISO());
        arm();
      }, msUntilNextMidnight());
    };

    const check = () => {
      if (document.visibilityState === 'hidden') return;
      const current = todayISO();
      setToday((previous) => (previous === current ? previous : current));
      clearTimeout(timeout);
      arm();
    };

    arm();
    document.addEventListener('visibilitychange', check);
    window.addEventListener('focus', check);

    return () => {
      clearTimeout(timeout);
      document.removeEventListener('visibilitychange', check);
      window.removeEventListener('focus', check);
    };
  }, []);

  return today;
}
