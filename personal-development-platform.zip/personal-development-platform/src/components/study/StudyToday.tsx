'use client';

import type { StudyDay } from '@/types';
import { formatMinutes, goalProgress } from '@/lib/logic/goals';
import { shortDate, weekdayShort } from '@/lib/logic/dates';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmButton } from '@/components/ui/ConfirmButton';
import { EmptyState, ErrorState, LoadingBlock } from '@/components/ui/States';
import { Icon } from '@/components/icons';

export function StudyToday({
  data,
  loading,
  error,
  onRetry,
  onDelete,
}: {
  data: StudyDay | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onDelete: (id: string) => void;
}) {
  if (loading) {
    return (
      <section className="card" aria-busy="true">
        <LoadingBlock label="Loading study sessions" rows={3} />
      </section>
    );
  }

  if (error || !data) {
    return (
      <section className="card">
        <ErrorState message={error ?? 'Study data could not be loaded.'} onRetry={onRetry} />
      </section>
    );
  }

  const progress = goalProgress(data.totalMinutes, data.goalMinutes);
  const max = Math.max(...data.last7Days.map((day) => day.minutes), 1);

  return (
    <section className="card" aria-labelledby="study-today-heading">
      <h2 id="study-today-heading" className="text-base font-semibold">
        Today&apos;s study
      </h2>

      <p className="mt-2 text-3xl font-semibold tabular-nums">
        {formatMinutes(data.totalMinutes)}
        <span className="ml-1 text-xs font-medium text-muted">of {formatMinutes(data.goalMinutes)}</span>
      </p>
      <div className="mt-2">
        <ProgressBar
          value={data.totalMinutes}
          max={data.goalMinutes}
          label="Study goal progress"
          tone={progress.met ? 'ok' : 'accent'}
          valueText={`${progress.pct}%`}
        />
      </div>

      <div className="mt-5">
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Last 7 days</h3>
        <div className="flex h-24 items-end gap-1.5">
          {data.last7Days.map((day) => {
            const height = day.minutes === 0 ? 4 : Math.max(10, Math.round((day.minutes / max) * 88));
            return (
              <div key={day.date} className="flex min-w-0 flex-1 flex-col items-center justify-end gap-1">
                <span className="text-[9px] tabular-nums text-muted">{day.minutes > 0 ? day.minutes : ''}</span>
                <div
                  className={`w-full rounded-t ${day.minutes >= data.goalMinutes ? 'bg-ok' : day.minutes > 0 ? 'bg-accent' : 'bg-line'}`}
                  style={{ height }}
                  title={`${shortDate(day.date)}: ${formatMinutes(day.minutes)}`}
                />
                <span className="text-[9px] font-medium uppercase text-muted">{weekdayShort(day.date).slice(0, 1)}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-5">
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
          Sessions ({data.sessions.length})
        </h3>
        {data.sessions.length === 0 ? (
          <EmptyState
            icon="timer"
            title="No sessions today"
            description="Finish a focus block and it appears here automatically."
          />
        ) : (
          <ul className="max-h-64 space-y-1.5 overflow-y-auto pr-1">
            {data.sessions.map((session) => (
              <li
                key={session.id}
                className="flex items-center justify-between gap-2 rounded-lg border border-line px-2.5 py-2 text-xs"
              >
                <span className="min-w-0">
                  <span className="flex items-center gap-1.5 font-semibold">
                    <Icon name="book" size={13} className="shrink-0 text-accent" />
                    <span className="truncate">{session.subject}</span>
                  </span>
                  <span className="mt-0.5 block text-muted">
                    {formatMinutes(session.focusMinutes)} ·{' '}
                    {new Date(session.startedAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                    {' – '}
                    {new Date(session.endedAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </span>
                <ConfirmButton onConfirm={() => onDelete(session.id)} label="Delete study session" />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
