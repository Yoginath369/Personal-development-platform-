'use client';

import { useCallback, useRef, useState } from 'react';
import type { StudyDay } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { useResource } from '@/hooks/useResource';
import { useToday } from '@/hooks/useToday';
import { useToast } from '@/hooks/useToast';
import { usePomodoro, type CompletedFocus } from '@/hooks/usePomodoro';
import { apiFetch, describeError } from '@/lib/api/client';
import { formatMinutes } from '@/lib/logic/goals';
import { longDate } from '@/lib/logic/dates';
import { PageHeader } from '@/components/shared/PageHeader';
import { Badge } from '@/components/ui/States';
import { PomodoroTimer } from './PomodoroTimer';
import { StudyToday } from './StudyToday';

interface StudyResponse extends StudyDay {
  subjects: string[];
}

export function StudyView() {
  const today = useToday();
  const { user } = useAuth();
  const { notify } = useToast();
  const resource = useResource<StudyResponse>(`/api/study-sessions?date=${today}`);
  const [logging, setLogging] = useState(false);
  const retryRef = useRef<CompletedFocus | null>(null);

  const logSession = useCallback(
    async (session: CompletedFocus, attempt = 0): Promise<void> => {
      setLogging(true);
      try {
        const result = await apiFetch<{ created: boolean; totalMinutes: number }>('/api/study-sessions', {
          method: 'POST',
          body: {
            clientId: session.clientId,
            subject: session.subject,
            focusMinutes: session.focusMinutes,
            startedAt: new Date(session.startedAt).toISOString(),
            endedAt: new Date(session.endedAt).toISOString(),
            date: session.date,
          },
        });
        retryRef.current = null;
        if (result.created) {
          notify(
            `Focus session logged: ${formatMinutes(session.focusMinutes)} of ${session.subject}.`,
            'success',
          );
        }
        await resource.reload();
      } catch (error) {
        if (attempt < 2) {
          retryRef.current = session;
          setTimeout(() => void logSession(session, attempt + 1), 1200 * (attempt + 1));
          return;
        }
        notify(
          `Your ${formatMinutes(session.focusMinutes)} session could not be saved. ${describeError(error)}`,
          'error',
        );
      } finally {
        setLogging(false);
      }
    },
    [notify, resource],
  );

  const controller = usePomodoro({
    storageKey: `pdp:pomodoro:${user.id}`,
    initialSubject: '',
    onFocusComplete: (session) => {
      void logSession(session);
    },
    onBreakComplete: () => notify('Break finished — ready for another focus block.', 'info'),
  });

  const deleteSession = useCallback(
    async (id: string) => {
      try {
        await apiFetch(`/api/study-sessions/${id}`, { method: 'DELETE' });
        notify('Session deleted.', 'info');
        await resource.reload();
      } catch (error) {
        notify(describeError(error), 'error');
      }
    },
    [notify, resource],
  );

  return (
    <>
      <PageHeader title="Study mode" description={longDate(today)}>
        <Badge tone="neutral">
          {controller.state.focusMinutes} min focus · {controller.state.breakMinutes} min break
        </Badge>
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-2 lg:items-start">
        <PomodoroTimer
          controller={controller}
          subjects={resource.data?.subjects ?? []}
          logging={logging}
        />
        <StudyToday
          data={resource.data}
          loading={resource.loading}
          error={resource.error}
          onRetry={() => void resource.reload()}
          onDelete={(id) => void deleteSession(id)}
        />
      </div>

      <p className="mt-4 text-xs text-muted">
        The timer is timestamp based: if your device sleeps or the tab is backgrounded, the remaining time and
        the logged duration stay correct. An in-flight block also survives a page reload.
      </p>
    </>
  );
}
