'use client';

import type { PomodoroController } from '@/hooks/usePomodoro';
import { FOCUS_OPTIONS, formatClock, isPaused, progressFraction } from '@/lib/logic/pomodoro';
import { Icon } from '@/components/icons';
import { InlineError } from '@/components/ui/States';
import { useState } from 'react';

const RADIUS = 78;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function PomodoroTimer({
  controller,
  subjects,
  logging,
}: {
  controller: PomodoroController;
  subjects: string[];
  logging: boolean;
}) {
  const { state, remaining, now } = controller;
  const [subjectError, setSubjectError] = useState<string>();
  const running = state.phase !== 'idle' && state.pausedRemainingMs === null;
  const paused = isPaused(state);
  const idle = state.phase === 'idle';
  const fraction = progressFraction(state, now);
  const totalMinutes = state.phase === 'break' ? state.breakMinutes : state.focusMinutes;

  const phaseLabel = idle
    ? 'Ready to focus'
    : state.phase === 'focus'
      ? paused
        ? 'Focus paused'
        : 'Focus in progress'
      : paused
        ? 'Break paused'
        : 'Break time';

  const handleStart = () => {
    if (state.subject.trim().length > 60) {
      setSubjectError('Keep the subject under 60 characters.');
      return;
    }
    setSubjectError(undefined);
    controller.start();
  };

  return (
    <section className="card" aria-labelledby="pomodoro-heading">
      <div className="mb-4 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h2 id="pomodoro-heading" className="text-base font-semibold">
            Pomodoro timer
          </h2>
          <p className="mt-0.5 text-xs text-muted">
            Completed focus blocks are logged automatically, even if you switch tabs.
          </p>
        </div>
        <span className="chip shrink-0 whitespace-nowrap">
          {state.completedFocusCount} done today
        </span>
      </div>

      <div className="flex flex-col items-center gap-1">
        <div className="relative grid place-items-center">
          <svg
            viewBox="0 0 200 200"
            className="h-52 w-52 -rotate-90"
            role="img"
            aria-label={`${phaseLabel}: ${formatClock(remaining)} remaining`}
          >
            <circle cx="100" cy="100" r={RADIUS} strokeWidth="12" className="fill-none stroke-elevated" />
            <circle
              cx="100"
              cy="100"
              r={RADIUS}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={CIRCUMFERENCE * (1 - fraction)}
              className={`fill-none transition-[stroke-dashoffset] duration-200 ${
                state.phase === 'break' ? 'stroke-ok' : 'stroke-accent'
              }`}
            />
          </svg>
          <div className="absolute inset-0 grid place-content-center text-center">
            <p className="text-4xl font-semibold tabular-nums tracking-tight" role="timer" aria-live="off">
              {formatClock(remaining)}
            </p>
            <p className="mt-1 text-xs font-medium uppercase tracking-wide text-muted">
              {state.phase === 'break' ? `${totalMinutes} min break` : `${totalMinutes} min focus`}
            </p>
          </div>
        </div>

        <p className="mt-2 text-sm font-semibold text-ink" aria-live="polite">
          {phaseLabel}
        </p>
        {state.subject && !idle && (
          <p className="text-xs text-muted">Subject: {state.subject}</p>
        )}
      </div>

      <div className="mt-5">
        <label htmlFor="focus-subject" className="label">
          Subject
        </label>
        <input
          id="focus-subject"
          type="text"
          value={state.subject}
          onChange={(event) => {
            controller.changeSubject(event.target.value);
            setSubjectError(undefined);
          }}
          list="subject-suggestions"
          placeholder="e.g. Linear algebra"
          maxLength={60}
          disabled={!idle}
          aria-invalid={Boolean(subjectError)}
          aria-describedby={subjectError ? 'subject-error' : 'subject-hint'}
          className="field"
        />
        <datalist id="subject-suggestions">
          {subjects.map((subject) => (
            <option key={subject} value={subject} />
          ))}
        </datalist>
        {subjectError ? (
          <span id="subject-error">
            <InlineError>{subjectError}</InlineError>
          </span>
        ) : (
          <p id="subject-hint" className="hint">
            Leave blank to log the block as “General”.
          </p>
        )}
      </div>

      <fieldset className="mt-3" disabled={!idle}>
        <legend className="label">Focus length</legend>
        <div className="flex gap-2">
          {FOCUS_OPTIONS.map((minutes) => (
            <button
              key={minutes}
              type="button"
              onClick={() => controller.chooseFocusMinutes(minutes)}
              aria-pressed={state.focusMinutes === minutes}
              className={`flex-1 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors ${
                state.focusMinutes === minutes
                  ? 'border-accent bg-accent/10 text-accent'
                  : 'border-line bg-surface text-muted hover:bg-elevated'
              } ${!idle ? 'cursor-not-allowed opacity-60' : ''}`}
            >
              {minutes} min
            </button>
          ))}
        </div>
        <p className="hint">A 5 minute break starts automatically after each focus block.</p>
      </fieldset>

      <div className="mt-4 flex flex-wrap gap-2">
        {idle && (
          <button type="button" onClick={handleStart} className="btn-primary flex-1">
            <Icon name="play" size={15} />
            Start focus
          </button>
        )}

        {running && (
          <button type="button" onClick={controller.pause} className="btn-secondary flex-1">
            <Icon name="pause" size={15} />
            Pause
          </button>
        )}

        {paused && (
          <button type="button" onClick={controller.resume} className="btn-primary flex-1">
            <Icon name="play" size={15} />
            Resume
          </button>
        )}

        {!idle && (
          <button type="button" onClick={controller.reset} className="btn-ghost">
            <Icon name="close" size={15} />
            Cancel block
          </button>
        )}
      </div>

      {logging && (
        <p className="mt-2 text-xs text-muted" role="status">
          Saving completed session…
        </p>
      )}
    </section>
  );
}
