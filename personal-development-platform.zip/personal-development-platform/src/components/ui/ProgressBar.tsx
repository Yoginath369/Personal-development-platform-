interface ProgressBarProps {
  value: number;
  max: number;
  label: string;
  tone?: 'accent' | 'ok' | 'warn' | 'danger';
  showValue?: boolean;
  valueText?: string;
  /** Hides the label visually while keeping it available to screen readers. */
  hideLabel?: boolean;
}

const TONES: Record<string, string> = {
  accent: 'bg-accent',
  ok: 'bg-ok',
  warn: 'bg-warn',
  danger: 'bg-danger',
};

export function ProgressBar({
  value,
  max,
  label,
  tone = 'accent',
  showValue = true,
  valueText,
  hideLabel = false,
}: ProgressBarProps) {
  const safeMax = max > 0 ? max : 1;
  const pct = Math.min(100, Math.max(0, Math.round((value / safeMax) * 100)));

  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <span className={hideLabel ? 'sr-only' : 'text-xs font-medium text-muted'}>{label}</span>
        {showValue && (
          <span className="text-xs font-semibold tabular-nums text-ink">
            {valueText ?? `${pct}%`}
          </span>
        )}
      </div>
      <div
        role="progressbar"
        aria-valuenow={Math.min(value, safeMax)}
        aria-valuemin={0}
        aria-valuemax={safeMax}
        aria-label={label}
        aria-valuetext={valueText ?? `${pct}%`}
        className="h-2 w-full overflow-hidden rounded-full bg-elevated"
      >
        <div
          className={`h-full rounded-full transition-[width] duration-300 ${TONES[tone]}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
