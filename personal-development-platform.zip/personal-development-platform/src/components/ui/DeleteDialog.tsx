'use client';

import { useEffect, useRef } from 'react';

/**
 * Accessible confirmation dialog: focus moves to the cancel button, Escape
 * closes, and the destructive action is never the default focused button.
 */
export function DeleteDialog({
  open,
  title,
  description,
  confirmLabel = 'Delete',
  pending = false,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel?: string;
  pending?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const cancelRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    cancelRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onCancel();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onCancel();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-dialog-title"
        aria-describedby={description ? 'delete-dialog-description' : undefined}
        className="w-full max-w-sm rounded-2xl border border-line bg-surface p-5 shadow-xl animate-fade-in"
      >
        <h2 id="delete-dialog-title" className="text-base font-semibold">
          {title}
        </h2>
        {description && (
          <p id="delete-dialog-description" className="mt-1.5 text-sm text-muted">
            {description}
          </p>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <button ref={cancelRef} type="button" onClick={onCancel} className="btn-secondary">
            Cancel
          </button>
          <button type="button" onClick={onConfirm} disabled={pending} className="btn-danger !bg-danger !text-white">
            {pending ? 'Deleting…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
