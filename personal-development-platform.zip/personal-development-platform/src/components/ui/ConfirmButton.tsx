'use client';

import { useEffect, useRef, useState } from 'react';
import { Icon } from '@/components/icons';

/**
 * Two-step destructive action: the first click arms it, the second commits.
 * Reverts automatically after 4s and on Escape, so nothing is deleted by accident.
 */
export function ConfirmButton({
  onConfirm,
  label,
  confirmLabel = 'Confirm',
  disabled = false,
  className = '',
  iconOnly = true,
}: {
  onConfirm: () => void;
  label: string;
  confirmLabel?: string;
  disabled?: boolean;
  className?: string;
  iconOnly?: boolean;
}) {
  const [armed, setArmed] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!armed) return;
    timerRef.current = setTimeout(() => setArmed(false), 4000);
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setArmed(false);
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [armed]);

  if (!armed) {
    return (
      <button
        type="button"
        onClick={() => setArmed(true)}
        disabled={disabled}
        aria-label={label}
        title={label}
        className={`btn-ghost !px-2 !py-1.5 text-muted hover:text-danger ${className}`}
      >
        <Icon name="trash" size={16} />
        {!iconOnly && <span className="text-xs font-medium">Delete</span>}
      </button>
    );
  }

  return (
    <span className="inline-flex items-center gap-1">
      <button
        type="button"
        onClick={() => {
          setArmed(false);
          onConfirm();
        }}
        className="btn-danger !px-2 !py-1 text-[11px]"
        autoFocus
      >
        {confirmLabel}
      </button>
      <button
        type="button"
        onClick={() => setArmed(false)}
        aria-label="Cancel delete"
        className="btn-ghost !px-1.5 !py-1 text-[11px]"
      >
        Cancel
      </button>
    </span>
  );
}
