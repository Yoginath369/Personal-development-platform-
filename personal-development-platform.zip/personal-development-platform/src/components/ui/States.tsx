import type { ReactNode } from 'react';
import { Icon, type IconName } from '@/components/icons';

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-elevated ${className}`} aria-hidden="true" />;
}

/** Loading placeholder that announces itself to screen readers. */
export function LoadingBlock({ label = 'Loading', rows = 3 }: { label?: string; rows?: number }) {
  return (
    <div role="status" aria-live="polite" className="space-y-3">
      <span className="sr-only">{label}…</span>
      <Skeleton className="h-4 w-1/3" />
      {Array.from({ length: rows }, (_, index) => (
        <Skeleton key={index} className={`h-10 w-full ${index === rows - 1 ? 'w-2/3' : ''}`} />
      ))}
    </div>
  );
}

export function ErrorState({
  message,
  onRetry,
  compact = false,
}: {
  message: string;
  onRetry?: () => void;
  compact?: boolean;
}) {
  return (
    <div
      role="alert"
      className={`flex flex-col items-start gap-3 rounded-xl border border-danger/40 bg-danger/10 text-danger ${
        compact ? 'p-3 text-xs' : 'p-4 text-sm'
      }`}
    >
      <div className="flex items-start gap-2">
        <Icon name="alert" size={18} className="mt-0.5 shrink-0" />
        <p>{message}</p>
      </div>
      {onRetry && (
        <button type="button" onClick={onRetry} className="btn-secondary !py-1.5 !text-xs">
          <Icon name="refresh" size={14} />
          Try again
        </button>
      )}
    </div>
  );
}

export function EmptyState({
  icon = 'check',
  title,
  description,
  action,
}: {
  icon?: IconName;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-line px-4 py-8 text-center">
      <span className="rounded-full bg-elevated p-2 text-muted">
        <Icon name={icon} size={20} />
      </span>
      <p className="text-sm font-semibold text-ink">{title}</p>
      {description && <p className="max-w-sm text-xs text-muted">{description}</p>}
      {action}
    </div>
  );
}

export function InlineError({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <p role="alert" className="mt-1 flex items-center gap-1 text-xs font-medium text-danger">
      <Icon name="alert" size={13} />
      {children}
    </p>
  );
}

export function Badge({
  children,
  tone = 'neutral',
}: {
  children: ReactNode;
  tone?: 'neutral' | 'ok' | 'warn' | 'danger' | 'accent';
}) {
  const tones: Record<string, string> = {
    neutral: 'border-line bg-elevated text-muted',
    ok: 'border-ok/40 bg-ok/10 text-ok',
    warn: 'border-warn/40 bg-warn/10 text-warn',
    danger: 'border-danger/40 bg-danger/10 text-danger',
    accent: 'border-accent/40 bg-accent/10 text-accent',
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${tones[tone]}`}
    >
      {children}
    </span>
  );
}
