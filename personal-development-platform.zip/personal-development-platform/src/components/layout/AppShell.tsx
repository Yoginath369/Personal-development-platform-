'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { Icon } from '@/components/icons';
import { useAuth } from '@/hooks/useAuth';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { ThemeToggle } from './ThemeToggle';

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { user } = useAuth();

  return (
    <div className="min-h-dvh lg:flex">
      <a href="#main" className="skip-link">
        Skip to main content
      </a>

      <Sidebar pathname={pathname} />

      <div className="flex min-h-dvh w-full min-w-0 flex-col">
        <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur">
          <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <Link href="/" className="flex items-center gap-2 lg:hidden">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-accent-ink">
                <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
                  <path
                    d="M4 18V9m5 9V5m5 13v-6m5 6V8"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    fill="none"
                  />
                </svg>
              </span>
              <span className="text-sm font-semibold">Momentum</span>
            </Link>

            <p className="hidden text-sm font-medium text-muted lg:block">
              Welcome back, <span className="font-semibold text-ink">{user.name.split(' ')[0]}</span>
            </p>

            <div className="flex items-center gap-2">
              <ThemeToggle compact />
              <Link
                href="/settings"
                aria-label="Settings"
                aria-current={pathname === '/settings' ? 'page' : undefined}
                className={`btn-ghost !px-2 !py-2 ${
                  pathname === '/settings' ? 'bg-elevated text-ink' : ''
                }`}
              >
                <Icon name="settings" size={18} />
              </Link>
              <span
                aria-hidden="true"
                className="grid h-8 w-8 place-items-center rounded-full bg-elevated text-xs font-semibold lg:hidden"
              >
                {user.name.slice(0, 1).toUpperCase()}
              </span>
            </div>
          </div>
        </header>

        <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-5 sm:px-6 lg:pb-10">
          {children}
        </main>
      </div>

      <BottomNav pathname={pathname} />
    </div>
  );
}
