'use client';

import { useCallback, useEffect, useState } from 'react';
import type { ThemePreference } from '@/types';
import { Icon } from '@/components/icons';
import { applyTheme } from '@/hooks/useTheme';
import { apiFetch } from '@/lib/api/client';
import { useAuth } from '@/hooks/useAuth';

const OPTIONS: Array<{ value: ThemePreference; label: string; icon: 'sun' | 'moon' | 'monitor' }> = [
  { value: 'light', label: 'Light', icon: 'sun' },
  { value: 'dark', label: 'Dark', icon: 'moon' },
  { value: 'system', label: 'System', icon: 'monitor' },
];

/**
 * Instant local switch + fire-and-forget persistence. A failed save keeps the
 * local theme applied and reports the problem through the button's title text.
 */
export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { settings, updateSettings } = useAuth();
  const [pending, setPending] = useState<ThemePreference | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => setFailed(false), [settings.theme]);

  const choose = useCallback(
    async (theme: ThemePreference) => {
      applyTheme(theme);
      updateSettings({ ...settings, theme });
      setPending(theme);
      try {
        const result = await apiFetch<{ settings: typeof settings }>('/api/settings', {
          method: 'PATCH',
          body: { theme },
        });
        updateSettings(result.settings);
      } catch {
        setFailed(true);
      } finally {
        setPending(null);
      }
    },
    [settings, updateSettings],
  );

  return (
    <div
      className="inline-flex items-center gap-0.5 rounded-lg border border-line bg-surface p-0.5"
      role="group"
      aria-label="Colour theme"
    >
      {OPTIONS.map((option) => {
        const active = settings.theme === option.value;
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => void choose(option.value)}
            aria-pressed={active}
            title={
              failed && active ? 'Saved on this device; server sync failed.' : `Use ${option.label.toLowerCase()} theme`
            }
            className={`flex items-center justify-center gap-1 rounded-md px-2 py-1.5 text-xs font-semibold transition-colors ${
              active ? 'bg-accent text-accent-ink' : 'text-muted hover:bg-elevated hover:text-ink'
            } ${pending === option.value ? 'opacity-70' : ''}`}
          >
            <Icon name={option.icon} size={15} />
            {!compact && <span className="hidden sm:inline">{option.label}</span>}
            {!compact && <span className="sr-only sm:hidden">{option.label}</span>}
          </button>
        );
      })}
    </div>
  );
}
