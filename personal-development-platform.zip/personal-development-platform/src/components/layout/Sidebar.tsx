'use client';

import Link from 'next/link';
import { Icon } from '@/components/icons';
import { PRIMARY_NAV, SETTINGS_NAV, isActivePath } from '@/lib/navigation';
import { useAuth } from '@/hooks/useAuth';
import { LogoutButton } from './LogoutButton';

export function Sidebar({ pathname }: { pathname: string }) {
  const { user } = useAuth();
  const items = [...PRIMARY_NAV, SETTINGS_NAV];

  return (
    <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-line bg-surface px-4 py-5 lg:flex">
      <Link href="/" className="mb-7 flex items-center gap-2 rounded-lg px-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-accent-ink">
          <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true">
            <path
              d="M4 18V9m5 9V5m5 13v-6m5 6V8"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              fill="none"
            />
          </svg>
        </span>
        <span>
          <span className="block text-sm font-semibold leading-tight">Momentum</span>
          <span className="block text-[11px] text-muted">Personal development</span>
        </span>
      </Link>

      <nav aria-label="Main navigation" className="flex-1">
        <ul className="space-y-1">
          {items.map((item) => {
            const active = isActivePath(pathname, item.href);
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    active
                      ? 'bg-accent/10 text-accent'
                      : 'text-muted hover:bg-elevated hover:text-ink'
                  }`}
                >
                  <Icon name={item.icon} size={18} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-4 border-t border-line pt-4">
        <div className="mb-2 flex items-center gap-2 px-2">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-elevated text-xs font-semibold text-ink">
            {user.name.slice(0, 1).toUpperCase()}
          </span>
          <span className="min-w-0">
            <span className="block truncate text-xs font-semibold text-ink">{user.name}</span>
            <span className="block truncate text-[11px] text-muted">{user.email}</span>
          </span>
        </div>
        <LogoutButton full />
      </div>
    </aside>
  );
}
