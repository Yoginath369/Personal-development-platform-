'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Icon } from '@/components/icons';
import { apiFetch, describeError } from '@/lib/api/client';

export function LogoutButton({ full = false }: { full?: boolean }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const logout = async () => {
    setPending(true);
    setError(null);
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
      router.replace('/login');
      router.refresh();
    } catch (cause) {
      setError(describeError(cause));
      setPending(false);
    }
  };

  return (
    <div className={full ? 'w-full' : ''}>
      <button
        type="button"
        onClick={() => void logout()}
        disabled={pending}
        className={`btn-ghost w-full !justify-start gap-2 text-sm ${pending ? 'opacity-70' : ''}`}
      >
        <Icon name="logout" size={16} />
        {pending ? 'Signing out…' : 'Sign out'}
      </button>
      {error && (
        <p role="alert" className="mt-1 px-2 text-xs text-danger">
          {error}
        </p>
      )}
    </div>
  );
}
