import type { SVGProps } from 'react';

export type IconName =
  | 'home'
  | 'heart'
  | 'timer'
  | 'tasks'
  | 'chart'
  | 'settings'
  | 'sun'
  | 'moon'
  | 'monitor'
  | 'plus'
  | 'trash'
  | 'edit'
  | 'close'
  | 'check'
  | 'droplet'
  | 'bed'
  | 'shoe'
  | 'meal'
  | 'book'
  | 'flame'
  | 'download'
  | 'logout'
  | 'chevronRight'
  | 'alert'
  | 'pause'
  | 'play'
  | 'refresh';

const PATHS: Record<IconName, string> = {
  home: 'M3 10.5 12 3l9 7.5M5.25 9.75V20a1 1 0 0 0 1 1h3.5v-5.5h4.5V21h3.5a1 1 0 0 0 1-1V9.75',
  heart: 'M12 20s-7.5-4.6-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 5-7.5 9.6-7.5 9.6Z',
  timer: 'M12 8v4l3 2M12 21a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM9 2h6',
  tasks: 'M4 6.5 6 8.5 9.5 5M4 17.5l2 2L9.5 16M13 7h7M13 18h7',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  settings:
    'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.1l2-1.5-2-3.4-2.3 1a7.6 7.6 0 0 0-1.9-1.1L14.6 3h-3.9l-.4 2.4a7.6 7.6 0 0 0-1.9 1.1l-2.3-1-2 3.4 2 1.5a7.4 7.4 0 0 0 0 2.2l-2 1.5 2 3.4 2.3-1a7.6 7.6 0 0 0 1.9 1.1l.4 2.4h3.9l.4-2.4a7.6 7.6 0 0 0 1.9-1.1l2.3 1 2-3.4-2-1.5c.1-.4.1-.7.1-1.1Z',
  sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
  moon: 'M21 12.8A8.5 8.5 0 1 1 11.2 3a6.5 6.5 0 0 0 9.8 9.8Z',
  monitor: 'M3 4h18v12H3zM8 20h8M12 16v4',
  plus: 'M12 5v14M5 12h14',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v5M14 11v5',
  edit: 'M4 20h4L20 8l-4-4L4 16v4ZM14 6l4 4',
  close: 'M6 6l12 12M18 6 6 18',
  check: 'M4 12.5 9 17.5 20 6.5',
  droplet: 'M12 3s6 6.3 6 10.4A6 6 0 0 1 6 13.4C6 9.3 12 3 12 3Z',
  bed: 'M3 18v-7h13a4 4 0 0 1 4 4v3M3 11V7M3 18h18M7.5 11a1.75 1.75 0 1 1 0-3.5 1.75 1.75 0 0 1 0 3.5Z',
  shoe: 'M3 16c0-3 1-5 1-8h3l2 3 4 1c3 .7 5 1.5 5 4v2H3v-2Z',
  meal: 'M6 3v8a2 2 0 0 0 4 0V3M8 11v10M16 3c-1.5 1.5-2 3-2 5 0 1.7.8 3 2 3v10',
  book: 'M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5V5.5ZM4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5A2.5 2.5 0 0 1 4 20.5Z',
  flame: 'M12 22c4 0 6-2.7 6-6 0-4.5-4-6.5-4-10-2 1.5-3 3.5-3 5.5 0-1-1-2.5-2-3.5C8 10 6 12.5 6 16c0 3.3 2 6 6 6Z',
  download: 'M12 3v12M7 11l5 5 5-5M4 21h16',
  logout: 'M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 16l-4-4 4-4M6 12h10',
  chevronRight: 'M9 6l6 6-6 6',
  alert: 'M12 8v5M12 16.5h.01M10.3 3.9 2.6 17a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z',
  pause: 'M9 5v14M15 5v14',
  play: 'M7 4l13 8-13 8V4Z',
  refresh: 'M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4',
};

interface IconProps extends SVGProps<SVGSVGElement> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 20, ...props }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      <path d={PATHS[name]} />
    </svg>
  );
}
