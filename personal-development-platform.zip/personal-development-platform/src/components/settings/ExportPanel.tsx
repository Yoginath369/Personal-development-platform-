'use client';

import { useState } from 'react';
import { useToast } from '@/hooks/useToast';
import { apiFetch, describeError } from '@/lib/api/client';
import { useToday } from '@/hooks/useToday';
import { Icon } from '@/components/icons';

interface ExportShape {
  counts: Record<string, number>;
  exportedAt: string;
}

export function ExportPanel() {
  const { notify } = useToast();
  const today = useToday();
  const [pending, setPending] = useState(false);
  const [lastExport, setLastExport] = useState<ExportShape | null>(null);

  const download = async () => {
    setPending(true);
    try {
      const response = await fetch('/api/export', { credentials: 'same-origin' });
      if (!response.ok) throw new Error(`Export failed with status ${response.status}.`);
      const text = await response.text();
      const blob = new Blob([text], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `pdp-export-${today}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);

      const parsed = JSON.parse(text) as ExportShape;
      setLastExport(parsed);
      notify('Export downloaded.', 'success');
    } catch (error) {
      notify(describeError(error), 'error');
    } finally {
      setPending(false);
    }
  };

  const preview = async () => {
    setPending(true);
    try {
      const data = await apiFetch<ExportShape>('/api/export', { method: 'POST' });
      setLastExport(data);
      notify('Export preview refreshed.', 'info');
    } catch (error) {
      notify(describeError(error), 'error');
    } finally {
      setPending(false);
    }
  };

  return (
    <section className="card" aria-labelledby="export-heading">
      <h2 id="export-heading" className="text-base font-semibold">
        Your data
      </h2>
      <p className="mt-0.5 text-xs text-muted">
        Download everything you have logged as a single JSON file: hydration, sleep, activity, meals, study
        sessions, tasks and settings.
      </p>

      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={() => void download()} className="btn-primary" disabled={pending}>
          <Icon name="download" size={15} />
          {pending ? 'Preparing…' : 'Download JSON'}
        </button>
        <button type="button" onClick={() => void preview()} className="btn-secondary" disabled={pending}>
          Show record counts
        </button>
      </div>

      {lastExport && (
        <div className="mt-3 rounded-lg bg-elevated p-3 text-xs" role="status">
          <p className="font-semibold text-ink">
            Last prepared {new Date(lastExport.exportedAt).toLocaleString()}
          </p>
          <ul className="mt-1 grid grid-cols-2 gap-x-4 gap-y-0.5 text-muted sm:grid-cols-3">
            {Object.entries(lastExport.counts).map(([key, value]) => (
              <li key={key} className="flex justify-between gap-2">
                <span className="capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                <span className="font-medium tabular-nums text-ink">{value}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
