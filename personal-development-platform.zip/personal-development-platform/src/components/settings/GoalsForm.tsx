'use client';

import { useEffect, useState, type FormEvent } from 'react';
import type { Settings } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { InlineError } from '@/components/ui/States';
import { Icon } from '@/components/icons';

interface GoalField {
  key: keyof Pick<
    Settings,
    'waterGoalMl' | 'sleepGoalHours' | 'stepsGoal' | 'calorieLimit' | 'studyGoalMinutes'
  >;
  label: string;
  hint: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  integer: boolean;
}

const FIELDS: GoalField[] = [
  {
    key: 'waterGoalMl',
    label: 'Daily water goal',
    hint: 'Between 250 ml and 20 L',
    unit: 'ml',
    min: 250,
    max: 20000,
    step: 50,
    integer: true,
  },
  {
    key: 'sleepGoalHours',
    label: 'Nightly sleep goal',
    hint: 'Between 1 and 24 hours',
    unit: 'hours',
    min: 1,
    max: 24,
    step: 0.5,
    integer: false,
  },
  {
    key: 'stepsGoal',
    label: 'Daily step goal',
    hint: 'Between 100 and 200,000 steps',
    unit: 'steps',
    min: 100,
    max: 200000,
    step: 500,
    integer: true,
  },
  {
    key: 'calorieLimit',
    label: 'Daily calorie limit',
    hint: 'Between 500 and 20,000 kcal',
    unit: 'kcal',
    min: 500,
    max: 20000,
    step: 50,
    integer: true,
  },
  {
    key: 'studyGoalMinutes',
    label: 'Daily study goal',
    hint: 'Between 15 and 1440 minutes',
    unit: 'minutes',
    min: 15,
    max: 1440,
    step: 5,
    integer: true,
  },
];

export function GoalsForm() {
  const { settings, updateSettings } = useAuth();
  const { notify } = useToast();
  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  useEffect(() => {
    setValues({
      waterGoalMl: String(settings.waterGoalMl),
      sleepGoalHours: String(settings.sleepGoalHours),
      stepsGoal: String(settings.stepsGoal),
      calorieLimit: String(settings.calorieLimit),
      studyGoalMinutes: String(settings.studyGoalMinutes),
    });
  }, [settings]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    const payload: Record<string, number> = {};

    for (const field of FIELDS) {
      const raw = (values[field.key] ?? '').trim();
      const parsed = Number(raw);
      if (raw === '' || Number.isNaN(parsed)) {
        nextErrors[field.key] = 'Enter a number.';
        continue;
      }
      if (field.integer && !Number.isInteger(parsed)) {
        nextErrors[field.key] = 'Use a whole number.';
        continue;
      }
      if (parsed < field.min) {
        nextErrors[field.key] = `Minimum is ${field.min}.`;
        continue;
      }
      if (parsed > field.max) {
        nextErrors[field.key] = `Maximum is ${field.max}.`;
        continue;
      }
      payload[field.key] = field.integer ? parsed : Number(parsed.toFixed(2));
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setPending(true);
    try {
      const result = await apiFetch<{ settings: Settings }>('/api/settings', {
        method: 'PATCH',
        body: payload,
      });
      updateSettings(result.settings);
      notify('Goals updated.');
    } catch (error) {
      if (error instanceof ApiClientError && Object.keys(error.fieldErrors).length > 0) {
        setErrors(
          Object.fromEntries(
            Object.entries(error.fieldErrors).map(([field, messages]) => [field, messages[0] ?? '']),
          ),
        );
        notify(error.message, 'error');
      } else {
        notify(describeError(error), 'error');
      }
    } finally {
      setPending(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate className="card space-y-4">
      <div>
        <h2 className="text-base font-semibold">Daily goals</h2>
        <p className="mt-0.5 text-xs text-muted">
          These targets drive progress bars, goal-hit counts and streaks across the app.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {FIELDS.map((field) => (
          <div key={field.key}>
            <label htmlFor={`goal-${field.key}`} className="label">
              {field.label}
            </label>
            <div className="relative">
              <input
                id={`goal-${field.key}`}
                type="number"
                inputMode={field.integer ? 'numeric' : 'decimal'}
                min={field.min}
                max={field.max}
                step={field.step}
                value={values[field.key] ?? ''}
                onChange={(event) => {
                  setValues((current) => ({ ...current, [field.key]: event.target.value }));
                  setErrors((current) => ({ ...current, [field.key]: '' }));
                }}
                aria-invalid={Boolean(errors[field.key])}
                aria-describedby={errors[field.key] ? `goal-${field.key}-error` : `goal-${field.key}-hint`}
                className="field pr-16"
              />
              <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-medium text-muted">
                {field.unit}
              </span>
            </div>
            {errors[field.key] ? (
              <span id={`goal-${field.key}-error`}>
                <InlineError>{errors[field.key]}</InlineError>
              </span>
            ) : (
              <p id={`goal-${field.key}-hint`} className="hint">
                {field.hint}
              </p>
            )}
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-line pt-3">
        <p className="text-xs text-muted">Changes apply immediately to new progress calculations.</p>
        <button type="submit" className="btn-primary" disabled={pending}>
          <Icon name="check" size={15} />
          {pending ? 'Saving…' : 'Save goals'}
        </button>
      </div>
    </form>
  );
}
