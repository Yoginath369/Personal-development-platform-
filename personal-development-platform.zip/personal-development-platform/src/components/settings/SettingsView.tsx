'use client';

import { useAuth } from '@/hooks/useAuth';
import { useToday } from '@/hooks/useToday';
import { longDate, shortDate } from '@/lib/logic/dates';
import { PageHeader } from '@/components/shared/PageHeader';
import { Badge } from '@/components/ui/States';
import { LogoutButton } from '@/components/layout/LogoutButton';
import { GoalsForm } from './GoalsForm';
import { ThemeSettings } from './ThemeSettings';
import { ExportPanel } from './ExportPanel';

export function SettingsView() {
  const { user } = useAuth();
  const today = useToday();

  return (
    <>
      <PageHeader title="Settings" description={longDate(today)}>
        <Badge tone="neutral">Account: {user.email}</Badge>
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-2 lg:items-start">
        <div className="space-y-4">
          <GoalsForm />
          <ThemeSettings />
        </div>

        <div className="space-y-4">
          <ExportPanel />

          <section className="card" aria-labelledby="account-heading">
            <h2 id="account-heading" className="text-base font-semibold">
              Account
            </h2>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Name</dt>
                <dd className="font-medium">{user.name}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Email</dt>
                <dd className="truncate font-medium">{user.email}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted">Member since</dt>
                <dd className="font-medium">{shortDate(user.createdAt.slice(0, 10))}</dd>
              </div>
            </dl>

            <div className="mt-4 border-t border-line pt-3">
              <LogoutButton full />
            </div>
          </section>

          <section className="card" aria-labelledby="privacy-heading">
            <h2 id="privacy-heading" className="text-base font-semibold">
              Privacy
            </h2>
            <ul className="mt-2 space-y-1.5 text-xs text-muted">
              <li>Every record is scoped to your user id — no other account can read it.</li>
              <li>Passwords are hashed with scrypt and a per-user random salt.</li>
              <li>Session cookies are httpOnly, same-site and expire after 30 days.</li>
              <li>Your data never leaves your deployment&apos;s database.</li>
            </ul>
          </section>
        </div>
      </div>
    </>
  );
}
