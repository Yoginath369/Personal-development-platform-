'use client';

import type { ThemePreference } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { applyTheme } from '@/hooks/useTheme';
import { apiFetch, describeError } from '@/lib/api/client';
import { Icon } from '@/components/icons';
import { useState } from 'react';

const OPTIONS: Array<{ value: ThemePreference; label: string; description: string; icon: 'sun' | 'moon' | 'monitor' }> = [
  { value: 'light', label: 'Light', description: 'Bright surface, dark text', icon: 'sun' },
  { value: 'dark', label: 'Dark', description: 'Lower light, comfortable at night', icon: 'moon' },
  { value: 'system', label: 'System', description: 'Follows your device setting', icon: 'monitor' },
];

export function ThemeSettings() {
  const { settings, updateSettings } = useAuth();
  const { notify } = useToast();
  const [pending, setPending] = useState<ThemePreference | null>(null);

  const choose = async (theme: ThemePreference) => {
    if (theme === settings.theme) return;
    applyTheme(theme);
    updateSettings({ ...settings, theme });
    setPending(theme);
    try {
      const result = await apiFetch<{ settings: typeof settings }>('/api/settings', {
        method: 'PATCH',
        body: { theme },
      });
      updateSettings(result.settings);
      notify(`Theme set to ${theme}.`, 'success');
    } catch (error) {
      notify(`${describeError(error)} The theme still applies on this device.`, 'error');
    } finally {
      setPending(null);
    }
  };

  return (
    <section className="card" aria-labelledby="theme-heading">
      <h2 id="theme-heading" className="text-base font-semibold">
        Appearance
      </h2>
      <p className="mt-0.5 text-xs text-muted">Saved to your account and applied before first paint.</p>

      <div role="radiogroup" aria-label="Colour theme" className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
        {OPTIONS.map((option) => {
          const active = settings.theme === option.value;
          return (
            <button
              key={option.value}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => void choose(option.value)}
              disabled={pending !== null}
              className={`flex items-start gap-2 rounded-xl border p-3 text-left transition-colors ${
                active ? 'border-accent bg-accent/10' : 'border-line hover:bg-elevated'
              }`}
            >
              <span className={`mt-0.5 ${active ? 'text-accent' : 'text-muted'}`}>
                <Icon name={option.icon} size={18} />
              </span>
              <span>
                <span className="block text-sm font-semibold text-ink">{option.label}</span>
                <span className="block text-xs text-muted">{option.description}</span>
              </span>
              {active && <Icon name="check" size={16} className="ml-auto text-accent" />}
            </button>
          );
        })}
      </div>
    </section>
  );
}
