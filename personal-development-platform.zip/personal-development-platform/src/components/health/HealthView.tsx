'use client';

import { useToday } from '@/hooks/useToday';
import { longDate } from '@/lib/logic/dates';
import { PageHeader } from '@/components/shared/PageHeader';
import { Badge } from '@/components/ui/States';
import { HydrationCard } from './HydrationCard';
import { SleepCard } from './SleepCard';
import { ActivityCard } from './ActivityCard';
import { NutritionCard } from './NutritionCard';

export function HealthView() {
  const today = useToday();

  return (
    <>
      <PageHeader title="Health" description={longDate(today)}>
        <Badge tone="neutral">All values saved to your account</Badge>
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-2">
        <HydrationCard date={today} />
        <SleepCard date={today} />
        <ActivityCard date={today} />
        <NutritionCard date={today} />
      </div>
    </>
  );
}
