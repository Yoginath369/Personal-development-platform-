'use client';

import { useState, type FormEvent } from 'react';
import type { ActivityDay } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToast } from '@/hooks/useToast';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { formatMinutes, formatNumber, goalProgress } from '@/lib/logic/goals';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmButton } from '@/components/ui/ConfirmButton';
import { EmptyState, ErrorState, InlineError, LoadingBlock } from '@/components/ui/States';
import { Icon } from '@/components/icons';

const STEP_PRESETS = [1000, 2500, 5000];
const EXERCISE_SUGGESTIONS = ['Walk', 'Run', 'Gym', 'Cycling', 'Yoga', 'Swim', 'Sport'];

export function ActivityCard({ date }: { date: string }) {
  const { notify } = useToast();
  const resource = useResource<ActivityDay>(`/api/activity?date=${date}`);

  const [steps, setSteps] = useState('');
  const [stepsError, setStepsError] = useState<string>();
  const [exerciseType, setExerciseType] = useState('');
  const [duration, setDuration] = useState('');
  const [exerciseErrors, setExerciseErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState<'steps' | 'exercise' | null>(null);

  const addSteps = async (value: number) => {
    if (!Number.isInteger(value) || value <= 0) {
      setStepsError('Steps must be a whole number greater than 0.');
      return;
    }
    if (value > 200000) {
      setStepsError('That is more steps than a day allows — check the number.');
      return;
    }
    setStepsError(undefined);
    setPending('steps');
    try {
      await apiFetch('/api/activity', { method: 'POST', body: { kind: 'steps', date, steps: value } });
      setSteps('');
      notify(`${formatNumber(value)} steps added.`);
      await resource.reload();
    } catch (error) {
      if (error instanceof ApiClientError && error.fieldError('steps')) setStepsError(error.fieldError('steps'));
      else notify(describeError(error), 'error');
    } finally {
      setPending(null);
    }
  };

  const addExercise = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const errors: Record<string, string> = {};
    const type = exerciseType.trim();
    const minutes = Number(duration);

    if (type.length < 2) errors.exerciseType = 'Name the activity (at least 2 characters).';
    if (type.length > 60) errors.exerciseType = 'Keep the name under 60 characters.';
    if (duration.trim() === '' || Number.isNaN(minutes)) errors.durationMinutes = 'Enter how long it lasted.';
    else if (!Number.isInteger(minutes)) errors.durationMinutes = 'Duration must be whole minutes.';
    else if (minutes <= 0) errors.durationMinutes = 'Duration must be at least 1 minute.';
    else if (minutes > 1440) errors.durationMinutes = 'A session longer than 24h looks like a typo.';

    setExerciseErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setPending('exercise');
    try {
      await apiFetch('/api/activity', {
        method: 'POST',
        body: { kind: 'exercise', date, exerciseType: type, durationMinutes: minutes },
      });
      setExerciseType('');
      setDuration('');
      notify('Activity logged.');
      await resource.reload();
    } catch (error) {
      if (error instanceof ApiClientError && Object.keys(error.fieldErrors).length > 0) {
        setExerciseErrors(
          Object.fromEntries(
            Object.entries(error.fieldErrors).map(([field, messages]) => [field, messages[0] ?? '']),
          ),
        );
      } else {
        notify(describeError(error), 'error');
      }
    } finally {
      setPending(null);
    }
  };

  const remove = async (id: string) => {
    try {
      await apiFetch(`/api/activity/${id}`, { method: 'DELETE' });
      notify('Activity entry removed.', 'info');
      await resource.reload();
    } catch (error) {
      notify(describeError(error), 'error');
    }
  };

  const data = resource.data;
  const stepsProgress = data ? goalProgress(data.steps, data.stepsGoal) : null;

  return (
    <section id="activity" className="card scroll-mt-20" aria-labelledby="activity-heading">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 id="activity-heading" className="flex items-center gap-2 text-base font-semibold">
            <Icon name="shoe" size={17} className="text-ok" />
            Activity
          </h2>
          <p className="mt-0.5 text-xs text-muted">Steps, walks and workouts for the day.</p>
        </div>
        {stepsProgress?.met && (
          <span className="chip !border-ok/40 !text-ok">
            <Icon name="check" size={12} /> Step goal met
          </span>
        )}
      </div>

      {resource.loading && <LoadingBlock label="Loading activity" rows={2} />}
      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} compact />
      )}

      {!resource.loading && data && (
        <>
          <p className="text-2xl font-semibold tabular-nums">
            {formatNumber(data.steps)}
            <span className="ml-1 text-xs font-medium text-muted">/ {formatNumber(data.stepsGoal)} steps</span>
          </p>
          <div className="mt-2 space-y-2">
            <ProgressBar
              value={data.steps}
              max={data.stepsGoal}
              label="Step progress"
              tone={stepsProgress?.met ? 'ok' : 'accent'}
              valueText={`${stepsProgress?.pct ?? 0}%`}
            />
            <p className="text-xs text-muted">
              {formatMinutes(data.exerciseMinutes)} of exercise · {data.walkCount}{' '}
              {data.walkCount === 1 ? 'walk' : 'walks'} logged
            </p>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {STEP_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => void addSteps(preset)}
                disabled={pending === 'steps'}
                className="btn-secondary !py-1.5"
              >
                <Icon name="plus" size={14} />
                {formatNumber(preset)}
              </button>
            ))}
          </div>

          <form
            noValidate
            className="mt-3 flex items-start gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              void addSteps(Number(steps));
            }}
          >
            <div className="flex-1">
              <label htmlFor="steps-input" className="sr-only">
                Steps to add
              </label>
              <input
                id="steps-input"
                type="number"
                inputMode="numeric"
                min={1}
                max={200000}
                step={100}
                value={steps}
                onChange={(event) => {
                  setSteps(event.target.value);
                  setStepsError(undefined);
                }}
                placeholder="Add steps"
                aria-invalid={Boolean(stepsError)}
                aria-describedby={stepsError ? 'steps-error' : undefined}
                className="field"
              />
              {stepsError && (
                <span id="steps-error">
                  <InlineError>{stepsError}</InlineError>
                </span>
              )}
            </div>
            <button type="submit" className="btn-primary" disabled={pending === 'steps' || steps.trim() === ''}>
              Add
            </button>
          </form>

          <form onSubmit={addExercise} noValidate className="mt-4 space-y-2 rounded-xl border border-line p-3">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted">Log exercise</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              <div>
                <label htmlFor="exercise-type" className="label !mb-1 !text-xs">
                  Type
                </label>
                <input
                  id="exercise-type"
                  type="text"
                  list="exercise-suggestions"
                  value={exerciseType}
                  onChange={(event) => {
                    setExerciseType(event.target.value);
                    setExerciseErrors((current) => ({ ...current, exerciseType: '' }));
                  }}
                  placeholder="Walk, gym, yoga…"
                  maxLength={60}
                  aria-invalid={Boolean(exerciseErrors.exerciseType)}
                  aria-describedby={exerciseErrors.exerciseType ? 'exercise-type-error' : undefined}
                  className="field"
                />
                <datalist id="exercise-suggestions">
                  {EXERCISE_SUGGESTIONS.map((suggestion) => (
                    <option key={suggestion} value={suggestion} />
                  ))}
                </datalist>
                {exerciseErrors.exerciseType && (
                  <span id="exercise-type-error">
                    <InlineError>{exerciseErrors.exerciseType}</InlineError>
                  </span>
                )}
              </div>
              <div>
                <label htmlFor="exercise-duration" className="label !mb-1 !text-xs">
                  Minutes
                </label>
                <input
                  id="exercise-duration"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={1440}
                  step={5}
                  value={duration}
                  onChange={(event) => {
                    setDuration(event.target.value);
                    setExerciseErrors((current) => ({ ...current, durationMinutes: '' }));
                  }}
                  placeholder="30"
                  aria-invalid={Boolean(exerciseErrors.durationMinutes)}
                  aria-describedby={exerciseErrors.durationMinutes ? 'exercise-duration-error' : undefined}
                  className="field"
                />
                {exerciseErrors.durationMinutes && (
                  <span id="exercise-duration-error">
                    <InlineError>{exerciseErrors.durationMinutes}</InlineError>
                  </span>
                )}
              </div>
            </div>
            <button type="submit" className="btn-secondary w-full !py-1.5" disabled={pending === 'exercise'}>
              {pending === 'exercise' ? 'Saving…' : 'Log exercise'}
            </button>
          </form>

          <div className="mt-4">
            <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted">
              Entries ({data.entries.length})
            </h3>
            {data.entries.length === 0 ? (
              <EmptyState icon="shoe" title="Nothing logged yet" description="Steps or a workout will show here." />
            ) : (
              <ul className="max-h-44 space-y-1 overflow-y-auto pr-1">
                {data.entries.map((entry) => (
                  <li
                    key={entry.id}
                    className="flex items-center justify-between gap-2 rounded-lg border border-line px-2.5 py-1.5 text-xs"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <Icon
                        name={entry.kind === 'steps' ? 'shoe' : 'heart'}
                        size={13}
                        className={entry.kind === 'steps' ? 'text-ok' : 'text-accent'}
                      />
                      <span className="truncate font-semibold">
                        {entry.kind === 'steps'
                          ? `${formatNumber(entry.steps ?? 0)} steps`
                          : `${entry.exerciseType} · ${formatMinutes(entry.durationMinutes ?? 0)}`}
                      </span>
                      <span className="shrink-0 text-muted">
                        {new Date(entry.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </span>
                    <ConfirmButton onConfirm={() => void remove(entry.id)} label="Delete activity entry" />
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </section>
  );
}
