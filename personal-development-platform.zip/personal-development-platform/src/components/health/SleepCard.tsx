'use client';

import { useEffect, useState, type FormEvent } from 'react';
import type { SleepDay } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToast } from '@/hooks/useToast';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { formatMinutes, goalProgress } from '@/lib/logic/goals';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmButton } from '@/components/ui/ConfirmButton';
import { EmptyState, ErrorState, InlineError, LoadingBlock, Badge } from '@/components/ui/States';
import { Icon } from '@/components/icons';

export function SleepCard({ date }: { date: string }) {
  const { notify } = useToast();
  const resource = useResource<SleepDay>(`/api/sleep?date=${date}`);
  const [hours, setHours] = useState('');
  const [quality, setQuality] = useState(3);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (resource.data?.entry) {
      setHours(String(resource.data.entry.hours));
      setQuality(resource.data.entry.quality);
    }
  }, [resource.data]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    const parsed = Number(hours);
    if (hours.trim() === '' || Number.isNaN(parsed)) nextErrors.hours = 'Enter the hours you slept.';
    else if (parsed <= 0) nextErrors.hours = 'Hours must be greater than 0.';
    else if (parsed > 24) nextErrors.hours = 'That is more than a day — check the number.';
    if (quality < 1 || quality > 5) nextErrors.quality = 'Quality must be between 1 and 5.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setPending(true);
    try {
      await apiFetch('/api/sleep', {
        method: 'PUT',
        body: { date, hours: Number(parsed.toFixed(2)), quality },
      });
      notify('Sleep saved.');
      await resource.reload();
    } catch (error) {
      if (error instanceof ApiClientError && Object.keys(error.fieldErrors).length > 0) {
        setErrors(
          Object.fromEntries(
            Object.entries(error.fieldErrors).map(([field, messages]) => [field, messages[0] ?? '']),
          ),
        );
      } else {
        notify(describeError(error), 'error');
      }
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    try {
      await apiFetch(`/api/sleep?date=${date}`, { method: 'DELETE' });
      setHours('');
      setQuality(3);
      notify('Sleep entry removed.', 'info');
      await resource.reload();
    } catch (error) {
      notify(describeError(error), 'error');
    }
  };

  const data = resource.data;
  const progress = data?.entry ? goalProgress(data.entry.hours, data.goalHours) : null;

  return (
    <section id="sleep" className="card scroll-mt-20" aria-labelledby="sleep-heading">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 id="sleep-heading" className="flex items-center gap-2 text-base font-semibold">
            <Icon name="bed" size={17} className="text-accent" />
            Sleep
          </h2>
          <p className="mt-0.5 text-xs text-muted">One record per day — saving again updates it.</p>
        </div>
        {progress?.met && (
          <span className="chip !border-ok/40 !text-ok">
            <Icon name="check" size={12} /> Goal met
          </span>
        )}
      </div>

      {resource.loading && <LoadingBlock label="Loading sleep" rows={2} />}
      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} compact />
      )}

      {!resource.loading && data && (
        <>
          {data.entry ? (
            <div className="mb-3 flex items-center justify-between gap-3 rounded-lg bg-elevated px-3 py-2">
              <div>
                <p className="text-xl font-semibold tabular-nums leading-tight">
                  {data.entry.hours}h
                  <span className="ml-1 text-xs font-medium text-muted">of {data.goalHours}h</span>
                </p>
                <p className="mt-0.5 text-xs text-muted">
                  Quality {data.entry.quality}/5 · {formatMinutes(data.entry.hours * 60)} slept
                </p>
              </div>
              <ConfirmButton onConfirm={() => void remove()} label="Delete sleep entry" />
            </div>
          ) : (
            <EmptyState icon="bed" title="No sleep logged" description="Add last night's sleep below." />
          )}

          {progress && (
            <div className="mb-3">
              <ProgressBar
                value={data.entry?.hours ?? 0}
                max={data.goalHours}
                label="Sleep progress"
                tone={progress.met ? 'ok' : 'accent'}
                valueText={`${progress.pct}%`}
              />
            </div>
          )}

          <form onSubmit={submit} noValidate className="space-y-3">
            <div>
              <label htmlFor="sleep-hours" className="label">
                Hours slept
              </label>
              <input
                id="sleep-hours"
                type="number"
                inputMode="decimal"
                min={0.25}
                max={24}
                step={0.25}
                value={hours}
                onChange={(event) => {
                  setHours(event.target.value);
                  setErrors((current) => ({ ...current, hours: '' }));
                }}
                placeholder="7.5"
                aria-invalid={Boolean(errors.hours)}
                aria-describedby={errors.hours ? 'sleep-hours-error' : undefined}
                className="field"
              />
              {errors.hours && (
                <span id="sleep-hours-error">
                  <InlineError>{errors.hours}</InlineError>
                </span>
              )}
            </div>

            <fieldset>
              <legend className="label">Sleep quality</legend>
              <div className="flex gap-1.5" role="radiogroup" aria-label="Sleep quality">
                {[1, 2, 3, 4, 5].map((value) => (
                  <button
                    key={value}
                    type="button"
                    role="radio"
                    aria-checked={quality === value}
                    onClick={() => setQuality(value)}
                    className={`h-9 flex-1 rounded-lg border text-sm font-semibold transition-colors ${
                      quality === value
                        ? 'border-accent bg-accent text-accent-ink'
                        : 'border-line bg-surface text-muted hover:bg-elevated'
                    }`}
                  >
                    {value}
                  </button>
                ))}
              </div>
              <p className="hint">1 = exhausted, 5 = fully rested</p>
              {errors.quality && <InlineError>{errors.quality}</InlineError>}
            </fieldset>

            <div className="flex items-center gap-2">
              <button type="submit" className="btn-primary flex-1" disabled={pending}>
                {pending ? 'Saving…' : data.entry ? 'Update sleep' : 'Save sleep'}
              </button>
              {data.entry && <Badge tone="neutral">Saved for {date}</Badge>}
            </div>
          </form>
        </>
      )}
    </section>
  );
}
