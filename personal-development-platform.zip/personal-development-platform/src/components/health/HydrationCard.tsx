'use client';

import { useState } from 'react';
import type { WaterDay } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToast } from '@/hooks/useToast';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { formatMl, goalProgress } from '@/lib/logic/goals';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmButton } from '@/components/ui/ConfirmButton';
import { EmptyState, ErrorState, InlineError, LoadingBlock } from '@/components/ui/States';
import { Icon } from '@/components/icons';

const QUICK_AMOUNTS = [250, 500, 750];

export function HydrationCard({ date }: { date: string }) {
  const { notify } = useToast();
  const resource = useResource<WaterDay>(`/api/water?date=${date}`);
  const [custom, setCustom] = useState('');
  const [fieldError, setFieldError] = useState<string>();
  const [pending, setPending] = useState(false);

  const addWater = async (amountMl: number) => {
    if (!Number.isFinite(amountMl) || amountMl <= 0) {
      setFieldError('Enter an amount greater than 0 ml.');
      return;
    }
    if (amountMl > 5000) {
      setFieldError('A single entry can be at most 5000 ml.');
      return;
    }
    setFieldError(undefined);
    setPending(true);
    try {
      await apiFetch('/api/water', { method: 'POST', body: { date, amountMl: Math.round(amountMl) } });
      setCustom('');
      notify(`Added ${formatMl(amountMl)} of water.`);
      await resource.reload();
    } catch (error) {
      if (error instanceof ApiClientError && error.fieldError('amountMl')) {
        setFieldError(error.fieldError('amountMl'));
      } else {
        notify(describeError(error), 'error');
      }
    } finally {
      setPending(false);
    }
  };

  const remove = async (id: string) => {
    try {
      await apiFetch(`/api/water/${id}`, { method: 'DELETE' });
      notify('Water entry removed.', 'info');
      await resource.reload();
    } catch (error) {
      notify(describeError(error), 'error');
    }
  };

  const data = resource.data;
  const progress = data ? goalProgress(data.totalMl, data.goalMl) : null;

  return (
    <section id="hydration" className="card scroll-mt-20" aria-labelledby="hydration-heading">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 id="hydration-heading" className="flex items-center gap-2 text-base font-semibold">
            <Icon name="droplet" size={17} className="text-accent" />
            Hydration
          </h2>
          <p className="mt-0.5 text-xs text-muted">Log every glass — the goal adapts to your settings.</p>
        </div>
        {progress?.met && (
          <span className="chip !border-ok/40 !text-ok">
            <Icon name="check" size={12} /> Goal met
          </span>
        )}
      </div>

      {resource.loading && <LoadingBlock label="Loading hydration" rows={2} />}

      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} compact />
      )}

      {!resource.loading && data && (
        <>
          <p className="text-2xl font-semibold tabular-nums">
            {formatMl(data.totalMl)}
            <span className="ml-1 text-xs font-medium text-muted">of {formatMl(data.goalMl)}</span>
          </p>
          <div className="mt-2">
            <ProgressBar
              value={data.totalMl}
              max={data.goalMl}
              label="Hydration progress"
              valueText={`${progress?.pct ?? 0}%`}
              tone={progress?.met ? 'ok' : 'accent'}
            />
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {QUICK_AMOUNTS.map((amount) => (
              <button
                key={amount}
                type="button"
                onClick={() => void addWater(amount)}
                disabled={pending}
                className="btn-secondary !py-1.5"
              >
                <Icon name="plus" size={14} />
                {amount} ml
              </button>
            ))}
          </div>

          <form
            noValidate
            className="mt-3 flex items-start gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              void addWater(Number(custom));
            }}
          >
            <div className="flex-1">
              <label htmlFor="custom-water" className="sr-only">
                Custom amount in millilitres
              </label>
              <input
                id="custom-water"
                type="number"
                inputMode="numeric"
                min={1}
                max={5000}
                step={50}
                value={custom}
                onChange={(event) => {
                  setCustom(event.target.value);
                  setFieldError(undefined);
                }}
                placeholder="Custom amount (ml)"
                aria-invalid={Boolean(fieldError)}
                aria-describedby={fieldError ? 'custom-water-error' : undefined}
                className="field"
              />
              {fieldError && (
                <span id="custom-water-error">
                  <InlineError>{fieldError}</InlineError>
                </span>
              )}
            </div>
            <button type="submit" className="btn-primary" disabled={pending || custom.trim() === ''}>
              Add
            </button>
          </form>

          <div className="mt-4">
            <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted">Today&apos;s entries</h3>
            {data.entries.length === 0 ? (
              <EmptyState
                icon="droplet"
                title="No water logged yet"
                description="Tap a quick amount above to start."
              />
            ) : (
              <ul className="max-h-44 space-y-1 overflow-y-auto pr-1">
                {data.entries.map((entry) => (
                  <li
                    key={entry.id}
                    className="flex items-center justify-between gap-2 rounded-lg border border-line px-2.5 py-1.5 text-xs"
                  >
                    <span className="flex items-center gap-2">
                      <Icon name="droplet" size={13} className="text-accent" />
                      <span className="font-semibold">{formatMl(entry.amountMl)}</span>
                      <span className="text-muted">
                        {new Date(entry.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </span>
                    <ConfirmButton onConfirm={() => void remove(entry.id)} label="Delete water entry" />
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </section>
  );
}
