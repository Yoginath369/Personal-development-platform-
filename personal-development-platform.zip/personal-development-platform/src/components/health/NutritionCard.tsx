'use client';

import { useState, type FormEvent } from 'react';
import type { MealType, NutritionDay } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToast } from '@/hooks/useToast';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { formatNumber, limitProgress } from '@/lib/logic/goals';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmButton } from '@/components/ui/ConfirmButton';
import { EmptyState, ErrorState, InlineError, LoadingBlock } from '@/components/ui/States';
import { Icon } from '@/components/icons';

const MEAL_TYPES: Array<{ value: MealType; label: string }> = [
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'lunch', label: 'Lunch' },
  { value: 'dinner', label: 'Dinner' },
  { value: 'snack', label: 'Snack' },
];

export function NutritionCard({ date }: { date: string }) {
  const { notify } = useToast();
  const resource = useResource<NutritionDay>(`/api/meals?date=${date}`);

  const [name, setName] = useState('');
  const [calories, setCalories] = useState('');
  const [mealType, setMealType] = useState<MealType>('lunch');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    const trimmed = name.trim();
    const kcal = Number(calories);

    if (trimmed.length === 0) nextErrors.name = 'What did you eat?';
    else if (trimmed.length > 80) nextErrors.name = 'Keep the name under 80 characters.';

    if (calories.trim() === '' || Number.isNaN(kcal)) nextErrors.calories = 'Enter the calories.';
    else if (!Number.isInteger(kcal)) nextErrors.calories = 'Calories must be a whole number.';
    else if (kcal <= 0) nextErrors.calories = 'Calories must be greater than 0.';
    else if (kcal > 5000) nextErrors.calories = 'A single meal over 5000 kcal looks like a typo.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setPending(true);
    try {
      await apiFetch('/api/meals', {
        method: 'POST',
        body: { date, name: trimmed, calories: kcal, mealType },
      });
      setName('');
      setCalories('');
      notify('Meal logged.');
      await resource.reload();
    } catch (error) {
      if (error instanceof ApiClientError && Object.keys(error.fieldErrors).length > 0) {
        setErrors(
          Object.fromEntries(
            Object.entries(error.fieldErrors).map(([field, messages]) => [field, messages[0] ?? '']),
          ),
        );
      } else {
        notify(describeError(error), 'error');
      }
    } finally {
      setPending(false);
    }
  };

  const remove = async (id: string) => {
    try {
      await apiFetch(`/api/meals/${id}`, { method: 'DELETE' });
      notify('Meal removed.', 'info');
      await resource.reload();
    } catch (error) {
      notify(describeError(error), 'error');
    }
  };

  const data = resource.data;
  const progress = data ? limitProgress(data.totalCalories, data.calorieLimit) : null;
  const remaining = data ? data.calorieLimit - data.totalCalories : 0;

  return (
    <section id="nutrition" className="card scroll-mt-20" aria-labelledby="nutrition-heading">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h2 id="nutrition-heading" className="flex items-center gap-2 text-base font-semibold">
            <Icon name="meal" size={17} className="text-warn" />
            Nutrition
          </h2>
          <p className="mt-0.5 text-xs text-muted">Track meals against your daily calorie limit.</p>
        </div>
        {progress?.over && (
          <span className="chip !border-danger/40 !text-danger">
            <Icon name="alert" size={12} /> Over limit
          </span>
        )}
      </div>

      {resource.loading && <LoadingBlock label="Loading meals" rows={2} />}
      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} compact />
      )}

      {!resource.loading && data && (
        <>
          <p className="text-2xl font-semibold tabular-nums">
            {formatNumber(data.totalCalories)}
            <span className="ml-1 text-xs font-medium text-muted">/ {formatNumber(data.calorieLimit)} kcal</span>
          </p>
          <div className="mt-2">
            <ProgressBar
              value={data.totalCalories}
              max={data.calorieLimit}
              label="Calorie progress"
              tone={progress?.over ? 'danger' : (progress?.pct ?? 0) > 85 ? 'warn' : 'ok'}
              valueText={`${progress?.rawPct ?? 0}%`}
            />
            <p className={`mt-1 text-xs ${progress?.over ? 'font-medium text-danger' : 'text-muted'}`}>
              {progress?.over
                ? `${formatNumber(progress.overBy)} kcal over your limit`
                : `${formatNumber(Math.max(0, remaining))} kcal remaining`}
            </p>
          </div>

          <form onSubmit={submit} noValidate className="mt-4 space-y-2 rounded-xl border border-line p-3">
            <div>
              <label htmlFor="meal-name" className="label !mb-1 !text-xs">
                Meal
              </label>
              <input
                id="meal-name"
                type="text"
                value={name}
                onChange={(event) => {
                  setName(event.target.value);
                  setErrors((current) => ({ ...current, name: '' }));
                }}
                placeholder="Oats with berries"
                maxLength={80}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'meal-name-error' : undefined}
                className="field"
              />
              {errors.name && (
                <span id="meal-name-error">
                  <InlineError>{errors.name}</InlineError>
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label htmlFor="meal-calories" className="label !mb-1 !text-xs">
                  Calories
                </label>
                <input
                  id="meal-calories"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={5000}
                  step={10}
                  value={calories}
                  onChange={(event) => {
                    setCalories(event.target.value);
                    setErrors((current) => ({ ...current, calories: '' }));
                  }}
                  placeholder="350"
                  aria-invalid={Boolean(errors.calories)}
                  aria-describedby={errors.calories ? 'meal-calories-error' : undefined}
                  className="field"
                />
                {errors.calories && (
                  <span id="meal-calories-error">
                    <InlineError>{errors.calories}</InlineError>
                  </span>
                )}
              </div>
              <div>
                <label htmlFor="meal-type" className="label !mb-1 !text-xs">
                  Type
                </label>
                <select
                  id="meal-type"
                  value={mealType}
                  onChange={(event) => setMealType(event.target.value as MealType)}
                  className="field"
                >
                  {MEAL_TYPES.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button type="submit" className="btn-secondary w-full !py-1.5" disabled={pending}>
              {pending ? 'Saving…' : 'Log meal'}
            </button>
          </form>

          <div className="mt-4">
            <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted">
              Meals ({data.entries.length})
            </h3>
            {data.entries.length === 0 ? (
              <EmptyState icon="meal" title="No meals logged" description="Add what you ate to track calories." />
            ) : (
              <ul className="max-h-44 space-y-1 overflow-y-auto pr-1">
                {data.entries.map((entry) => (
                  <li
                    key={entry.id}
                    className="flex items-center justify-between gap-2 rounded-lg border border-line px-2.5 py-1.5 text-xs"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-semibold">{entry.name}</span>
                      <span className="text-muted capitalize">
                        {entry.mealType} · {formatNumber(entry.calories)} kcal
                      </span>
                    </span>
                    <ConfirmButton onConfirm={() => void remove(entry.id)} label="Delete meal" />
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </section>
  );
}
