'use client';

import { useState, type FormEvent } from 'react';
import type { Task, TaskCategory } from '@/types';
import { CATEGORY_LABELS, TASK_CATEGORIES } from '@/lib/logic/tasks';
import { ApiClientError } from '@/lib/api/client';
import { InlineError } from '@/components/ui/States';
import { Icon } from '@/components/icons';

export interface TaskFormValues {
  title: string;
  notes: string;
  category: TaskCategory;
  dueDate: string;
}

interface Props {
  initial?: Task | null;
  defaultDueDate?: string;
  submitting: boolean;
  onSubmit: (values: TaskFormValues) => Promise<void> | void;
  onCancel?: () => void;
}

export function TaskForm({ initial, defaultDueDate = '', submitting, onSubmit, onCancel }: Props) {
  const [values, setValues] = useState<TaskFormValues>({
    title: initial?.title ?? '',
    notes: initial?.notes ?? '',
    category: initial?.category ?? 'personal',
    dueDate: initial?.dueDate ?? defaultDueDate,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const update = <K extends keyof TaskFormValues>(key: K, value: TaskFormValues[K]) => {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: '' }));
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    const title = values.title.trim();

    if (title.length === 0) nextErrors.title = 'Give the task a title.';
    else if (title.length > 120) nextErrors.title = 'Keep titles under 120 characters.';
    else if (values.title.length > 200) nextErrors.title = 'That title is too long.';

    if (values.notes.length > 1000) nextErrors.notes = 'Notes must be 1000 characters or fewer.';

    if (values.dueDate) {
      const parsed = Date.parse(`${values.dueDate}T00:00:00`);
      if (Number.isNaN(parsed)) nextErrors.dueDate = 'Use a valid date.';
      else if (values.dueDate < '2000-01-01' || values.dueDate > '2100-12-31') {
        nextErrors.dueDate = 'Pick a date between 2000 and 2100.';
      }
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    if (initial && title.toLowerCase() === initial.title.toLowerCase() && values.dueDate === (initial.dueDate ?? '')) {
      // No change - just close the editor instead of hitting the API.
      onCancel?.();
      return;
    }

    try {
      await onSubmit({ ...values, title, notes: values.notes.trim() });
    } catch (error) {
      if (error instanceof ApiClientError && Object.keys(error.fieldErrors).length > 0) {
        setErrors(
          Object.fromEntries(
            Object.entries(error.fieldErrors).map(([field, messages]) => [field, messages[0] ?? '']),
          ),
        );
      } else {
        setErrors({ form: error instanceof Error ? error.message : 'Could not save the task.' });
      }
    }
  };

  return (
    <form onSubmit={submit} noValidate className="space-y-3 rounded-xl border border-line bg-elevated/60 p-3">
      <div>
        <label htmlFor="task-title" className="label !mb-1 !text-xs">
          Title
        </label>
        <input
          id="task-title"
          type="text"
          value={values.title}
          onChange={(event) => update('title', event.target.value)}
          placeholder="Finish chapter 4 problem set"
          maxLength={120}
          aria-invalid={Boolean(errors.title)}
          aria-describedby={errors.title ? 'task-title-error' : undefined}
          className="field"
          autoFocus
        />
        {errors.title && (
          <span id="task-title-error">
            <InlineError>{errors.title}</InlineError>
          </span>
        )}
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label htmlFor="task-category" className="label !mb-1 !text-xs">
            Category
          </label>
          <select
            id="task-category"
            value={values.category}
            onChange={(event) => update('category', event.target.value as TaskCategory)}
            className="field"
          >
            {TASK_CATEGORIES.map((category) => (
              <option key={category} value={category}>
                {CATEGORY_LABELS[category]}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="task-due" className="label !mb-1 !text-xs">
            Due date <span className="font-normal text-muted">(optional)</span>
          </label>
          <input
            id="task-due"
            type="date"
            value={values.dueDate}
            onChange={(event) => update('dueDate', event.target.value)}
            aria-invalid={Boolean(errors.dueDate)}
            aria-describedby={errors.dueDate ? 'task-due-error' : undefined}
            className="field"
          />
          {errors.dueDate && (
            <span id="task-due-error">
              <InlineError>{errors.dueDate}</InlineError>
            </span>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="task-notes" className="label !mb-1 !text-xs">
          Notes <span className="font-normal text-muted">(optional)</span>
        </label>
        <textarea
          id="task-notes"
          rows={2}
          value={values.notes}
          onChange={(event) => update('notes', event.target.value)}
          maxLength={1000}
          placeholder="Anything that helps you start"
          aria-invalid={Boolean(errors.notes)}
          aria-describedby={errors.notes ? 'task-notes-error' : undefined}
          className="field resize-y"
        />
        {errors.notes && (
          <span id="task-notes-error">
            <InlineError>{errors.notes}</InlineError>
          </span>
        )}
      </div>

      {errors.form && <InlineError>{errors.form}</InlineError>}

      <div className="flex items-center gap-2">
        <button type="submit" className="btn-primary flex-1" disabled={submitting}>
          {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add task'}
        </button>
        {onCancel && (
          <button type="button" onClick={onCancel} className="btn-secondary">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}

export function AddTaskButton({ onClick, expanded }: { onClick: () => void; expanded: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="btn-primary"
      aria-expanded={expanded}
      aria-controls="task-form-panel"
    >
      <Icon name={expanded ? 'close' : 'plus'} size={16} />
      {expanded ? 'Close' : 'New task'}
    </button>
  );
}
