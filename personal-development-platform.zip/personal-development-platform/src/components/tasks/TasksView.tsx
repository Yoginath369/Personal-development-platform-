'use client';

import { useCallback, useMemo, useState } from 'react';
import type { Task, TaskCategory } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToday } from '@/hooks/useToday';
import { useToast } from '@/hooks/useToast';
import { apiFetch, describeError } from '@/lib/api/client';
import {
  filterTasks,
  searchTasks,
  sortTasks,
  taskCounts,
  type TaskSort,
  type TaskStatusFilter,
} from '@/lib/logic/tasks';
import { longDate } from '@/lib/logic/dates';
import { PageHeader } from '@/components/shared/PageHeader';
import { Badge, EmptyState, ErrorState, LoadingBlock } from '@/components/ui/States';
import { DeleteDialog } from '@/components/ui/DeleteDialog';
import { Icon } from '@/components/icons';
import { AddTaskButton, TaskForm, type TaskFormValues } from './TaskForm';
import { TaskFilters } from './TaskFilters';
import { TaskItem } from './TaskItem';

interface TasksResponse {
  tasks: Task[];
  today: string;
}

export function TasksView() {
  const today = useToday();
  const { notify } = useToast();
  const resource = useResource<TasksResponse>(`/api/tasks?today=${today}`);
  const [status, setStatus] = useState<TaskStatusFilter>('all');
  const [category, setCategory] = useState<TaskCategory | 'all'>('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<TaskSort>('due');
  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Task | null>(null);
  const [deleting, setDeleting] = useState(false);

  const tasks = resource.data?.tasks ?? [];
  const counts = useMemo(() => taskCounts(tasks, today), [tasks, today]);

  const visibleTasks = useMemo(() => {
    let list = filterTasks(tasks, status, today);
    if (category !== 'all') list = list.filter((task) => task.category === category);
    list = searchTasks(list, search);
    return sortTasks(list, sort);
  }, [tasks, status, category, search, sort, today]);

  const createTask = useCallback(
    async (values: TaskFormValues) => {
      setSubmitting(true);
      try {
        await apiFetch('/api/tasks', {
          method: 'POST',
          body: {
            title: values.title.trim(),
            notes: values.notes.trim() === '' ? null : values.notes.trim(),
            category: values.category,
            dueDate: values.dueDate === '' ? null : values.dueDate,
          },
        });
        setCreating(false);
        setStatus('active');
        notify('Task added.');
        await resource.reload();
      } finally {
        setSubmitting(false);
      }
    },
    [notify, resource],
  );

  const editTask = useCallback(
    async (id: string, values: TaskFormValues) => {
      setSubmitting(true);
      try {
        await apiFetch(`/api/tasks/${id}`, {
          method: 'PATCH',
          body: {
            title: values.title.trim(),
            notes: values.notes.trim() === '' ? null : values.notes.trim(),
            category: values.category,
            dueDate: values.dueDate === '' ? null : values.dueDate,
          },
        });
        setEditingId(null);
        notify('Task updated.');
        await resource.reload();
      } finally {
        setSubmitting(false);
      }
    },
    [notify, resource],
  );

  const toggleTask = useCallback(
    async (task: Task) => {
      setBusyId(task.id);
      try {
        await apiFetch(`/api/tasks/${task.id}`, {
          method: 'PATCH',
          body: { completed: !task.completed, completedOn: today },
        });
        notify(task.completed ? 'Task reopened.' : 'Nice — task completed.');
        await resource.reload();
      } catch (error) {
        notify(describeError(error), 'error');
      } finally {
        setBusyId(null);
      }
    },
    [notify, resource, today],
  );

  const confirmDelete = useCallback(async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await apiFetch(`/api/tasks/${pendingDelete.id}`, { method: 'DELETE' });
      notify('Task deleted.', 'info');
      setPendingDelete(null);
      await resource.reload();
    } catch (error) {
      notify(describeError(error), 'error');
    } finally {
      setDeleting(false);
    }
  }, [notify, pendingDelete, resource]);

  return (
    <>
      <PageHeader title="Tasks" description={longDate(today)}>
        <Badge tone={counts.overdue > 0 ? 'danger' : 'neutral'}>
          <Icon name="flame" size={12} />
          {counts.active} active
        </Badge>
        {counts.dueToday > 0 && <Badge tone="warn">{counts.dueToday} due today</Badge>}
        <AddTaskButton
          expanded={creating}
          onClick={() => {
            setCreating((value) => !value);
            setEditingId(null);
          }}
        />
      </PageHeader>

      {creating && (
        <div id="task-form-panel" className="mb-4">
          <TaskForm
            defaultDueDate={today}
            submitting={submitting}
            onSubmit={createTask}
            onCancel={() => setCreating(false)}
          />
        </div>
      )}

      {!resource.loading && !resource.error && tasks.length > 0 && (
        <div className="card mb-4 !p-3">
          <TaskFilters
            status={status}
            category={category}
            search={search}
            sort={sort}
            counts={counts}
            onStatusChange={setStatus}
            onCategoryChange={setCategory}
            onSearchChange={setSearch}
            onSortChange={setSort}
          />
        </div>
      )}

      {resource.loading && (
        <div className="card">
          <LoadingBlock label="Loading tasks" rows={4} />
        </div>
      )}

      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} />
      )}

      {!resource.loading && !resource.error && (
        <>
          {tasks.length === 0 ? (
            <EmptyState
              icon="tasks"
              title="No tasks yet"
              description="Add your first task to start tracking study, fitness, work and personal goals."
              action={
                <button type="button" onClick={() => setCreating(true)} className="btn-primary mt-1 !py-1.5 !text-xs">
                  <Icon name="plus" size={14} /> Create a task
                </button>
              }
            />
          ) : visibleTasks.length === 0 ? (
            <EmptyState
              icon="check"
              title="Nothing matches these filters"
              description="Try a different status, category or search term."
              action={
                <button
                  type="button"
                  onClick={() => {
                    setStatus('all');
                    setCategory('all');
                    setSearch('');
                  }}
                  className="btn-secondary mt-1 !py-1.5 !text-xs"
                >
                  Reset filters
                </button>
              }
            />
          ) : (
            <ul className="space-y-2">
              {visibleTasks.map((task) => (
                <div key={task.id}>
                  <TaskItem
                    task={task}
                    today={today}
                    busy={busyId === task.id}
                    editing={editingId === task.id}
                    onToggle={() => void toggleTask(task)}
                    onEdit={() => {
                      setEditingId(task.id === editingId ? null : task.id);
                      setCreating(false);
                    }}
                    onDelete={() => setPendingDelete(task)}
                  />
                  {editingId === task.id && (
                    <div className="mt-2">
                      <TaskForm
                        initial={task}
                        submitting={submitting}
                        onSubmit={(values) => editTask(task.id, values)}
                        onCancel={() => setEditingId(null)}
                      />
                    </div>
                  )}
                </div>
              ))}
            </ul>
          )}

          <p className="mt-4 text-xs text-muted" role="status">
            Showing {visibleTasks.length} of {tasks.length} tasks · {counts.completed} completed ·{' '}
            {counts.overdue} overdue
          </p>
        </>
      )}

      <DeleteDialog
        open={pendingDelete !== null}
        title="Delete this task?"
        description={pendingDelete ? `“${pendingDelete.title}” will be permanently removed.` : undefined}
        pending={deleting}
        onCancel={() => setPendingDelete(null)}
        onConfirm={() => void confirmDelete()}
      />
    </>
  );
}
