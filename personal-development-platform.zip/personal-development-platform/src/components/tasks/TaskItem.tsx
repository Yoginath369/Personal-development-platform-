'use client';

import type { Task } from '@/types';
import { CATEGORY_LABELS, isDueToday, isOverdue } from '@/lib/logic/tasks';
import { relativeDateLabel } from '@/lib/logic/dates';
import { Badge } from '@/components/ui/States';
import { Icon } from '@/components/icons';

const CATEGORY_TONES: Record<Task['category'], 'accent' | 'ok' | 'warn' | 'neutral'> = {
  study: 'accent',
  personal: 'neutral',
  fitness: 'ok',
  work: 'warn',
};

export function TaskItem({
  task,
  today,
  busy,
  onToggle,
  onEdit,
  onDelete,
  editing,
}: {
  task: Task;
  today: string;
  busy: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  editing: boolean;
}) {
  const overdue = isOverdue(task, today);
  const dueToday = isDueToday(task, today);

  return (
    <li
      className={`flex items-start gap-3 rounded-xl border bg-surface p-3 transition-colors ${
        editing ? 'border-accent' : overdue ? 'border-danger/40' : 'border-line'
      }`}
    >
      <input
        type="checkbox"
        id={`task-${task.id}`}
        checked={task.completed}
        disabled={busy}
        onChange={onToggle}
        className="mt-0.5 h-4 w-4 shrink-0 rounded border-line text-accent focus:ring-accent"
      />

      <div className="min-w-0 flex-1">
        <label
          htmlFor={`task-${task.id}`}
          className={`block cursor-pointer break-words text-sm font-medium ${
            task.completed ? 'text-muted line-through' : 'text-ink'
          }`}
        >
          {task.title}
        </label>

        {task.notes && <p className="mt-0.5 line-clamp-2 text-xs text-muted">{task.notes}</p>}

        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          <Badge tone={CATEGORY_TONES[task.category]}>{CATEGORY_LABELS[task.category]}</Badge>
          {task.dueDate && !task.completed && (
            <Badge tone={overdue ? 'danger' : dueToday ? 'warn' : 'neutral'}>
              <Icon name={overdue ? 'alert' : 'check'} size={11} />
              {overdue ? 'Overdue' : 'Due'} {relativeDateLabel(task.dueDate, today).toLowerCase() === 'today'
                ? 'today'
                : task.dueDate}
            </Badge>
          )}
          {task.completed && task.completedAt && (
            <span className="text-[11px] text-muted">
              Completed{' '}
              {new Date(task.completedAt).toLocaleDateString([], {
                day: 'numeric',
                month: 'short',
              })}
            </span>
          )}
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-0.5">
        <button
          type="button"
          onClick={onEdit}
          className="btn-ghost !px-2 !py-1.5"
          aria-label={`Edit ${task.title}`}
          title="Edit task"
        >
          <Icon name="edit" size={15} />
        </button>
        <button
          type="button"
          onClick={onDelete}
          className="btn-ghost !px-2 !py-1.5 hover:text-danger"
          aria-label={`Delete ${task.title}`}
          title="Delete task"
        >
          <Icon name="trash" size={15} />
        </button>
      </div>
    </li>
  );
}
