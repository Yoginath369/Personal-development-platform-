'use client';

import type { TaskCategory } from '@/types';
import { CATEGORY_LABELS, TASK_CATEGORIES, type TaskSort, type TaskStatusFilter, type TaskCounts } from '@/lib/logic/tasks';
import { Icon } from '@/components/icons';

const STATUSES: Array<{ value: TaskStatusFilter; label: string }> = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'completed', label: 'Done' },
  { value: 'overdue', label: 'Overdue' },
];

export function TaskFilters({
  status,
  category,
  search,
  sort,
  counts,
  onStatusChange,
  onCategoryChange,
  onSearchChange,
  onSortChange,
}: {
  status: TaskStatusFilter;
  category: TaskCategory | 'all';
  search: string;
  sort: TaskSort;
  counts: TaskCounts;
  onStatusChange: (status: TaskStatusFilter) => void;
  onCategoryChange: (category: TaskCategory | 'all') => void;
  onSearchChange: (search: string) => void;
  onSortChange: (sort: TaskSort) => void;
}) {
  const badgeFor: Record<TaskStatusFilter, number> = {
    all: counts.total,
    active: counts.active,
    completed: counts.completed,
    overdue: counts.overdue,
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter tasks by status">
        {STATUSES.map((option) => {
          const active = status === option.value;
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={active}
              onClick={() => onStatusChange(option.value)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                active
                  ? 'border-accent bg-accent/10 text-accent'
                  : 'border-line bg-surface text-muted hover:bg-elevated hover:text-ink'
              }`}
            >
              {option.label}
              <span className="ml-1 tabular-nums opacity-70">{badgeFor[option.value]}</span>
            </button>
          );
        })}
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <div className="relative sm:col-span-2">
          <label htmlFor="task-search" className="sr-only">
            Search tasks
          </label>
          <input
            id="task-search"
            type="search"
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search tasks"
            maxLength={120}
            className="field pl-9"
          />
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">
            <svg viewBox="0 0 24 24" width={15} height={15} fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" strokeLinecap="round" />
            </svg>
          </span>
        </div>

        <div>
          <label htmlFor="task-category-filter" className="sr-only">
            Filter by category
          </label>
          <select
            id="task-category-filter"
            value={category}
            onChange={(event) => onCategoryChange(event.target.value as TaskCategory | 'all')}
            className="field"
          >
            <option value="all">All categories</option>
            {TASK_CATEGORIES.map((value) => (
              <option key={value} value={value}>
                {CATEGORY_LABELS[value]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2">
        <label htmlFor="task-sort" className="text-xs text-muted">
          Sort by
        </label>
        <select
          id="task-sort"
          value={sort}
          onChange={(event) => onSortChange(event.target.value as TaskSort)}
          className="field !w-auto !py-1 !text-xs"
        >
          <option value="due">Due date</option>
          <option value="created">Newest</option>
          <option value="category">Category</option>
        </select>
      </div>

      {search.trim().length > 0 && (
        <button
          type="button"
          onClick={() => onSearchChange('')}
          className="btn-ghost !py-1 !text-xs"
        >
          <Icon name="close" size={12} /> Clear search
        </button>
      )}
    </div>
  );
}
