'use client';

import { useMemo } from 'react';
import { shortDate } from '@/lib/logic/dates';

export interface ChartPoint {
  date: string;
  value: number;
}

export interface MetricChartProps {
  title: string;
  description?: string;
  points: ChartPoint[];
  goal?: number;
  unit: string;
  color?: 'accent' | 'ok' | 'warn' | 'danger';
  kind?: 'bar' | 'line';
  formatValue?: (value: number) => string;
}

// Deliberately small viewBox: at 320-360px card width the 13px axis labels stay
// legible instead of shrinking to ~5px as they would with a 640-wide canvas.
const WIDTH = 480;
const HEIGHT = 210;
const PADDING = { top: 16, right: 12, bottom: 30, left: 50 };

type ChartColor = 'accent' | 'ok' | 'warn' | 'danger';

const COLOR_CLASSES: Record<ChartColor, { bar: string; line: string }> = {
  accent: { bar: 'fill-accent', line: 'stroke-accent' },
  ok: { bar: 'fill-ok', line: 'stroke-ok' },
  warn: { bar: 'fill-warn', line: 'stroke-warn' },
  danger: { bar: 'fill-danger', line: 'stroke-danger' },
};

function niceMax(value: number): number {
  if (value <= 0) return 1;
  const magnitude = 10 ** Math.floor(Math.log10(value));
  const normalized = value / magnitude;
  const stepped = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10;
  return stepped * magnitude;
}

/**
 * Dependency-free SVG chart (lazy loaded) with a native data table fallback for
 * screen readers. No canvas, no layout shift, scales to any width.
 */
export default function MetricChart({
  title,
  description,
  points,
  goal,
  unit,
  color = 'accent',
  kind = 'bar',
  formatValue = (value) => `${Math.round(value)}`,
}: MetricChartProps) {
  const plotWidth = WIDTH - PADDING.left - PADDING.right;
  const plotHeight = HEIGHT - PADDING.top - PADDING.bottom;

  const { max, ticks } = useMemo(() => {
    const highest = Math.max(...points.map((point) => point.value), goal ?? 0, 1);
    const top = niceMinMax(highest);
    return { max: top, ticks: [0, 0.25, 0.5, 0.75, 1].map((fraction) => top * fraction) };
  }, [points, goal]);

  const total = points.reduce((sum, point) => sum + point.value, 0);
  const activeDays = points.filter((point) => point.value > 0).length;

  const stepX = points.length > 1 ? plotWidth / (points.length - 1) : plotWidth;
  const barWidth = points.length > 0 ? Math.max(3, (plotWidth / points.length) * 0.62) : 0;

  const yFor = (value: number) => PADDING.top + plotHeight - (Math.min(value, max) / max) * plotHeight;

  const linePath = points
    .map((point, index) => {
      const x = points.length === 1 ? PADDING.left + plotWidth / 2 : PADDING.left + index * stepX;
      return `${index === 0 ? 'M' : 'L'}${x.toFixed(1)},${yFor(point.value).toFixed(1)}`;
    })
    .join(' ');

  const labelIndexes = points.length <= 7
    ? points.map((_, index) => index)
    : points.map((_, index) => index).filter((index) => index % Math.ceil(points.length / 6) === 0);

  const colors = COLOR_CLASSES[color];

  return (
    <figure className="card">
      <figcaption>
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-sm font-semibold">{title}</h3>
          <span className="text-xs text-muted">
            {formatValue(total)} total · {activeDays} active {activeDays === 1 ? 'day' : 'days'}
          </span>
        </div>
        {description && <p className="mt-0.5 text-xs text-muted">{description}</p>}
      </figcaption>

      <svg
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        className="mt-3 h-auto w-full"
        role="img"
        aria-label={`${title} over ${points.length} days: ${formatValue(total)} ${unit} total, highest day ${formatValue(
          Math.max(...points.map((point) => point.value), 0),
        )} ${unit}`}
      >
        {ticks.map((tick) => (
          <g key={tick}>
            <line
              x1={PADDING.left}
              x2={WIDTH - PADDING.right}
              y1={yFor(tick)}
              y2={yFor(tick)}
              className="stroke-line"
              strokeWidth="1"
              strokeDasharray={tick === 0 ? undefined : '3 4'}
            />
            <text
              x={PADDING.left - 7}
              y={yFor(tick) + 4}
              textAnchor="end"
              className="fill-muted text-[13px]"
            >
              {formatValue(tick)}
            </text>
          </g>
        ))}

        {typeof goal === 'number' && goal > 0 && (
          <g>
            <line
              x1={PADDING.left}
              x2={WIDTH - PADDING.right}
              y1={yFor(goal)}
              y2={yFor(goal)}
              className="stroke-warn"
              strokeWidth="1.5"
              strokeDasharray="6 4"
            />
            <text x={WIDTH - PADDING.right} y={yFor(goal) - 4} textAnchor="end" className="fill-warn text-[12px]">
              goal {formatValue(goal)}
            </text>
          </g>
        )}

        {kind === 'bar'
          ? points.map((point, index) => {
              const x =
                points.length === 1
                  ? PADDING.left + plotWidth / 2 - barWidth / 2
                  : PADDING.left + index * stepX + (stepX - barWidth) / 2;
              const height = Math.max(point.value > 0 ? 2 : 0, plotHeight - (yFor(point.value) - PADDING.top));
              return (
                <rect
                  key={point.date}
                  x={x}
                  y={PADDING.top + plotHeight - height}
                  width={barWidth}
                  height={height}
                  rx={Math.min(3, barWidth / 2)}
                  className={point.value > 0 ? colors.bar : 'fill-elevated'}
                >
                  <title>{`${shortDate(point.date)}: ${formatValue(point.value)} ${unit}`}</title>
                </rect>
              );
            })
          : (
            <g>
              <path d={linePath} fill="none" strokeWidth="2.5" strokeLinejoin="round" className={colors.line} />
              {points.map((point, index) => {
                const x = points.length === 1 ? PADDING.left + plotWidth / 2 : PADDING.left + index * stepX;
                return (
                  <circle key={point.date} cx={x} cy={yFor(point.value)} r={2.5} className={colors.bar}>
                    <title>{`${shortDate(point.date)}: ${formatValue(point.value)} ${unit}`}</title>
                  </circle>
                );
              })}
            </g>
          )}

        {labelIndexes.map((index) => {
          const point = points[index];
          if (!point) return null;
          const x =
            points.length === 1 ? PADDING.left + plotWidth / 2 : PADDING.left + index * stepX;
          return (
            <text
              key={`label-${point.date}`}
              x={x}
              y={HEIGHT - 9}
              textAnchor="middle"
              className="fill-muted text-[13px]"
            >
              {shortDate(point.date)}
            </text>
          );
        })}
      </svg>

      <details className="mt-2">
        <summary className="cursor-pointer text-xs font-medium text-muted hover:text-ink">
          View data table
        </summary>
        <div className="mt-2 max-h-48 overflow-y-auto">
          <table className="w-full text-left text-xs">
            <caption className="sr-only">{title} values by date</caption>
            <thead>
              <tr className="text-muted">
                <th scope="col" className="py-1 pr-2 font-medium">
                  Date
                </th>
                <th scope="col" className="py-1 font-medium">
                  {unit}
                </th>
              </tr>
            </thead>
            <tbody>
              {points.map((point) => (
                <tr key={point.date} className="border-t border-line">
                  <td className="py-1 pr-2 text-muted">{point.date}</td>
                  <td className="py-1 font-medium tabular-nums">{formatValue(point.value)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
    </figure>
  );
}

function niceMinMax(value: number): number {
  return niceMax(value * 1.1);
}
