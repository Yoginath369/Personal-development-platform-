'use client';

import dynamic from 'next/dynamic';
import { useState } from 'react';
import Link from 'next/link';
import type { AnalyticsSummary } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToday } from '@/hooks/useToday';
import { useAuth } from '@/hooks/useAuth';
import { formatMinutes, formatMl, formatNumber, hitRate } from '@/lib/logic/goals';
import { longDate, shortDate } from '@/lib/logic/dates';
import { PageHeader } from '@/components/shared/PageHeader';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ErrorState, LoadingBlock, EmptyState, Badge } from '@/components/ui/States';
import { Icon } from '@/components/icons';
import { ChartsSectionFallback } from './ChartsSection';

/** Charts are code-split: the SVG renderer only loads on this screen. */
const ChartsSection = dynamic(() => import('./ChartsSection'), {
  ssr: false,
  loading: () => <ChartsSectionFallback />,
});

type Range = 7 | 30;

export function AnalyticsView() {
  const today = useToday();
  const { settings } = useAuth();
  const [range, setRange] = useState<Range>(7);
  const resource = useResource<AnalyticsSummary>(`/api/analytics?end=${today}&days=${range}`);

  return (
    <>
      <PageHeader title="Goals & analytics" description={longDate(today)}>
        <div className="inline-flex items-center gap-0.5 rounded-lg border border-line bg-surface p-0.5" role="group" aria-label="Chart range">
          {([7, 30] as Range[]).map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setRange(option)}
              aria-pressed={range === option}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                range === option ? 'bg-accent text-accent-ink' : 'text-muted hover:bg-elevated hover:text-ink'
              }`}
            >
              {option} days
            </button>
          ))}
        </div>
        <Link href="/settings" className="btn-secondary !py-1.5 !text-xs">
          <Icon name="settings" size={14} />
          Edit goals
        </Link>
      </PageHeader>

      {resource.loading && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }, (_, index) => (
            <div key={index} className="card">
              <LoadingBlock label="Loading analytics" rows={2} />
            </div>
          ))}
        </div>
      )}

      {!resource.loading && resource.error && (
        <ErrorState message={resource.error} onRetry={() => void resource.reload()} />
      )}

      {!resource.loading && resource.data && (
        <>
          <section aria-labelledby="overview-heading" className="mb-5">
            <h2 id="overview-heading" className="sr-only">
              Period overview
            </h2>
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <div className="card !p-4">
                <p className="flex items-center gap-1.5 text-xs font-medium text-muted">
                  <Icon name="flame" size={14} className="text-warn" /> Current streak
                </p>
                <p className="mt-1 text-2xl font-semibold tabular-nums">
                  {resource.data.streak}
                  <span className="ml-1 text-xs font-medium text-muted">days</span>
                </p>
                <p className="mt-0.5 text-[11px] text-muted">Best: {resource.data.bestStreak} days</p>
              </div>

              <div className="card !p-4">
                <p className="flex items-center gap-1.5 text-xs font-medium text-muted">
                  <Icon name="droplet" size={14} className="text-accent" /> Water logged
                </p>
                <p className="mt-1 text-2xl font-semibold tabular-nums">{formatMl(resource.data.totals.waterMl)}</p>
                <p className="mt-0.5 text-[11px] text-muted">
                  avg {formatMl(resource.data.averages.waterMl)}/day
                </p>
              </div>

              <div className="card !p-4">
                <p className="flex items-center gap-1.5 text-xs font-medium text-muted">
                  <Icon name="book" size={14} className="text-ok" /> Study time
                </p>
                <p className="mt-1 text-2xl font-semibold tabular-nums">
                  {formatMinutes(resource.data.totals.studyMinutes)}
                </p>
                <p className="mt-0.5 text-[11px] text-muted">
                  avg {formatMinutes(resource.data.averages.studyMinutes)}/day
                </p>
              </div>

              <div className="card !p-4">
                <p className="flex items-center gap-1.5 text-xs font-medium text-muted">
                  <Icon name="shoe" size={14} className="text-warn" /> Steps
                </p>
                <p className="mt-1 text-2xl font-semibold tabular-nums">
                  {formatNumber(resource.data.totals.steps)}
                </p>
                <p className="mt-0.5 text-[11px] text-muted">
                  avg {formatNumber(resource.data.averages.steps)}/day
                </p>
              </div>
            </div>
          </section>

          <section aria-labelledby="hits-heading" className="card mb-5">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h2 id="hits-heading" className="text-base font-semibold">
                Goal consistency
              </h2>
              <Badge tone="neutral">
                {shortDate(resource.data.range.start)} – {shortDate(resource.data.range.end)}
              </Badge>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1">
                <ProgressBar
                  value={resource.data.goalHitDays.water}
                  max={resource.data.range.days}
                  label={`Water goal · ${resource.data.goalHitDays.water} of ${resource.data.range.days} days`}
                  tone="accent"
                  valueText={`${hitRate(resource.data.goalHitDays.water, resource.data.range.days)}%`}
                />
              </div>
              <div className="space-y-1">
                <ProgressBar
                  value={resource.data.goalHitDays.sleep}
                  max={resource.data.range.days}
                  label={`Sleep goal · ${resource.data.goalHitDays.sleep} of ${resource.data.range.days} days`}
                  tone="accent"
                  valueText={`${hitRate(resource.data.goalHitDays.sleep, resource.data.range.days)}%`}
                />
              </div>
              <div className="space-y-1">
                <ProgressBar
                  value={resource.data.goalHitDays.steps}
                  max={resource.data.range.days}
                  label={`Step goal · ${resource.data.goalHitDays.steps} of ${resource.data.range.days} days`}
                  tone="ok"
                  valueText={`${hitRate(resource.data.goalHitDays.steps, resource.data.range.days)}%`}
                />
              </div>
              <div className="space-y-1">
                <ProgressBar
                  value={resource.data.goalHitDays.study}
                  max={resource.data.range.days}
                  label={`Study goal · ${resource.data.goalHitDays.study} of ${resource.data.range.days} days`}
                  tone="ok"
                  valueText={`${hitRate(resource.data.goalHitDays.study, resource.data.range.days)}%`}
                />
              </div>
            </div>

            <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-3 text-xs sm:grid-cols-4">
              <div>
                <dt className="text-muted">Sleep avg (logged nights)</dt>
                <dd className="font-semibold">{resource.data.averages.sleepHours} h</dd>
              </div>
              <div>
                <dt className="text-muted">Calorie average</dt>
                <dd className="font-semibold">{formatNumber(resource.data.averages.calories)} kcal</dd>
              </div>
              <div>
                <dt className="text-muted">Exercise</dt>
                <dd className="font-semibold">{formatMinutes(resource.data.totals.exerciseMinutes)}</dd>
              </div>
              <div>
                <dt className="text-muted">Tasks completed</dt>
                <dd className="font-semibold">{formatNumber(resource.data.totals.tasksCompleted)}</dd>
              </div>
            </dl>
          </section>

          {resource.data.totals.waterMl === 0 &&
          resource.data.totals.studyMinutes === 0 &&
          resource.data.totals.steps === 0 ? (
            <EmptyState
              icon="chart"
              title="No data in this range yet"
              description="Log water, sleep, activity, meals or a study session and the charts will fill in."
              action={
                <Link href="/health" className="btn-primary mt-1 !py-1.5 !text-xs">
                  Log something
                </Link>
              }
            />
          ) : (
            <ChartsSection summary={resource.data} />
          )}

          <p className="mt-4 text-xs text-muted">
            Goals used for these calculations: {formatMl(settings.waterGoalMl)} water, {settings.sleepGoalHours}h
            sleep, {formatNumber(settings.stepsGoal)} steps, {formatMinutes(settings.studyGoalMinutes)} study ·{' '}
            <Link href="/settings" className="font-medium text-accent hover:underline">
              change goals
            </Link>
          </p>
        </>
      )}
    </>
  );
}
