'use client';

import type { AnalyticsSummary } from '@/types';
import { formatMinutes, formatMl, formatNumber } from '@/lib/logic/goals';
import MetricChart from './MetricChart';

/**
 * Entire chart bundle. Imported with next/dynamic (ssr:false) from AnalyticsView
 * so the SVG chart code is only fetched when someone opens the analytics screen.
 */
export default function ChartsSection({ summary }: { summary: AnalyticsSummary }) {
  const { days, goals } = summary;

  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <MetricChart
        title="Hydration"
        description="Millilitres logged per day"
        points={days.map((day) => ({ date: day.date, value: day.waterMl }))}
        goal={goals.waterGoalMl}
        unit="ml"
        color="accent"
        formatValue={(value) => formatMl(value)}
      />
      <MetricChart
        title="Study time"
        description="Focus minutes logged per day"
        points={days.map((day) => ({ date: day.date, value: day.studyMinutes }))}
        goal={goals.studyGoalMinutes}
        unit="minutes"
        color="ok"
        formatValue={(value) => `${Math.round(value)}`}
      />
      <MetricChart
        title="Steps"
        description="Daily step total"
        points={days.map((day) => ({ date: day.date, value: day.steps }))}
        goal={goals.stepsGoal}
        unit="steps"
        color="warn"
        formatValue={(value) => formatNumber(value)}
      />
      <MetricChart
        title="Calories"
        description="Daily intake against your limit"
        points={days.map((day) => ({ date: day.date, value: day.calories }))}
        goal={goals.calorieLimit}
        unit="kcal"
        color="danger"
        kind="line"
        formatValue={(value) => formatNumber(value)}
      />
      <MetricChart
        title="Sleep"
        description="Hours slept (days without a record show 0)"
        points={days.map((day) => ({ date: day.date, value: day.sleepHours ?? 0 }))}
        goal={goals.sleepGoalHours}
        unit="hours"
        color="accent"
        kind="line"
        formatValue={(value) => `${Math.round(value * 10) / 10}h`}
      />
      <MetricChart
        title="Tasks completed"
        description="Tasks ticked off each day"
        points={days.map((day) => ({ date: day.date, value: day.tasksCompleted }))}
        unit="tasks"
        color="ok"
        formatValue={(value) => `${Math.round(value)}`}
      />
    </div>
  );
}

export function ChartsSectionFallback() {
  return (
    <div className="grid gap-4 xl:grid-cols-2" aria-hidden="true">
      {Array.from({ length: 4 }, (_, index) => (
        <div key={index} className="card">
          <div className="h-4 w-1/3 animate-pulse rounded bg-elevated" />
          <div className="mt-3 h-40 w-full animate-pulse rounded bg-elevated" />
        </div>
      ))}
    </div>
  );
}

export { formatMinutes };
