'use client';

import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { apiFetch, ApiClientError, describeError } from '@/lib/api/client';
import { InlineError } from '@/components/ui/States';
import { Icon } from '@/components/icons';

type Mode = 'login' | 'register';

interface Props {
  mode: Mode;
}

const COPY = {
  login: {
    title: 'Welcome back',
    subtitle: 'Sign in to pick up where you left off.',
    submit: 'Sign in',
    altText: 'New here?',
    altLink: '/register',
    altLabel: 'Create an account',
  },
  register: {
    title: 'Create your account',
    subtitle: 'One private dashboard for health, study and tasks.',
    submit: 'Create account',
    altText: 'Already have an account?',
    altLink: '/login',
    altLabel: 'Sign in',
  },
} as const;

export function AuthForm({ mode }: Props) {
  const copy = COPY[mode];
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get('next');
  const safeNext = nextPath && nextPath.startsWith('/') && !nextPath.startsWith('//') ? nextPath : '/';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (mode === 'register' && name.trim().length < 2) {
      errors.name = 'Please enter your name (at least 2 characters).';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      errors.email = 'Enter a valid email address.';
    }
    if (mode === 'register') {
      if (password.length < 8) errors.password = 'Use at least 8 characters.';
      else if (!/[a-zA-Z]/.test(password)) errors.password = 'Include at least one letter.';
      else if (!/[0-9]/.test(password)) errors.password = 'Include at least one number.';
    } else if (password.length === 0) {
      errors.password = 'Enter your password.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    if (!validate()) return;

    setPending(true);
    try {
      await apiFetch(`/api/auth/${mode}`, {
        method: 'POST',
        body: mode === 'register' ? { name: name.trim(), email: email.trim(), password } : { email: email.trim(), password },
      });
      router.replace(safeNext);
      router.refresh();
    } catch (cause) {
      if (cause instanceof ApiClientError && Object.keys(cause.fieldErrors).length > 0) {
        const next: Record<string, string> = {};
        for (const [field, messages] of Object.entries(cause.fieldErrors)) {
          const first = messages[0];
          if (first) next[field] = first;
        }
        setFieldErrors(next);
        setFormError(cause.message);
      } else {
        setFormError(describeError(cause));
      }
      setPending(false);
    }
  };

  return (
    <div className="card animate-fade-in !p-6">
      <h1 className="text-xl font-semibold tracking-tight">{copy.title}</h1>
      <p className="mt-1 text-sm text-muted">{copy.subtitle}</p>

      <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4">
        {mode === 'register' && (
          <div>
            <label htmlFor="name" className="label">
              Name
            </label>
            <input
              id="name"
              name="name"
              type="text"
              autoComplete="name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              aria-invalid={Boolean(fieldErrors.name)}
              aria-describedby={fieldErrors.name ? 'name-error' : undefined}
              className="field"
              placeholder="Ashwin Kumar"
              maxLength={60}
              required
            />
            {fieldErrors.name && (
              <span id="name-error">
                <InlineError>{fieldErrors.name}</InlineError>
              </span>
            )}
          </div>
        )}

        <div>
          <label htmlFor="email" className="label">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            aria-invalid={Boolean(fieldErrors.email)}
            aria-describedby={fieldErrors.email ? 'email-error' : undefined}
            className="field"
            placeholder="you@example.com"
            maxLength={254}
            required
          />
          {fieldErrors.email && (
            <span id="email-error">
              <InlineError>{fieldErrors.email}</InlineError>
            </span>
          )}
        </div>

        <div>
          <label htmlFor="password" className="label">
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              aria-invalid={Boolean(fieldErrors.password)}
              aria-describedby={
                fieldErrors.password ? 'password-error' : mode === 'register' ? 'password-hint' : undefined
              }
              className="field pr-16"
              maxLength={100}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword((value) => !value)}
              className="absolute inset-y-0 right-0 rounded-r-lg px-3 text-xs font-semibold text-muted hover:text-ink"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              aria-pressed={showPassword}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
          {fieldErrors.password ? (
            <span id="password-error">
              <InlineError>{fieldErrors.password}</InlineError>
            </span>
          ) : (
            mode === 'register' && (
              <p id="password-hint" className="hint">
                At least 8 characters, with a letter and a number.
              </p>
            )
          )}
        </div>

        {formError && (
          <div role="alert" className="flex items-start gap-2 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
            <Icon name="alert" size={16} className="mt-0.5 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <button type="submit" className="btn-primary w-full" disabled={pending}>
          {pending ? 'Please wait…' : copy.submit}
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-muted">
        {copy.altText}{' '}
        <Link href={copy.altLink} className="font-semibold text-accent underline-offset-2 hover:underline">
          {copy.altLabel}
        </Link>
      </p>
    </div>
  );
}
