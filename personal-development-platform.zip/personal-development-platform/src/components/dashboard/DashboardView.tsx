'use client';

import Link from 'next/link';
import { useCallback, useState } from 'react';
import type { DashboardSummary, Task } from '@/types';
import { useResource } from '@/hooks/useResource';
import { useToday } from '@/hooks/useToday';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { apiFetch, describeError } from '@/lib/api/client';
import { longDate } from '@/lib/logic/dates';
import { formatMinutes, formatMl, formatNumber, goalProgress, limitProgress } from '@/lib/logic/goals';
import { CATEGORY_LABELS, isOverdue } from '@/lib/logic/tasks';
import { GoalCard } from '@/components/shared/GoalCard';
import { PageHeader } from '@/components/shared/PageHeader';
import { ErrorState, LoadingBlock, EmptyState, Badge } from '@/components/ui/States';
import { Icon } from '@/components/icons';

export function DashboardView() {
  const today = useToday();
  const { settings } = useAuth();
  const { notify } = useToast();
  const resource = useResource<DashboardSummary>(`/api/summary?date=${today}`);
  const [busyTaskId, setBusyTaskId] = useState<string | null>(null);

  const toggleTask = useCallback(
    async (task: Task) => {
      setBusyTaskId(task.id);
      try {
        await apiFetch(`/api/tasks/${task.id}`, {
          method: 'PATCH',
          body: { completed: !task.completed, completedOn: today },
        });
        notify(task.completed ? 'Task reopened.' : 'Task completed.');
        await resource.reload();
      } catch (error) {
        notify(describeError(error), 'error');
      } finally {
        setBusyTaskId(null);
      }
    },
    [notify, resource, today],
  );

  if (resource.loading) {
    return (
      <>
        <PageHeader title="Dashboard" description={longDate(today)} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }, (_, index) => (
            <div key={index} className="card">
              <LoadingBlock rows={2} label="Loading your day" />
            </div>
          ))}
        </div>
      </>
    );
  }

  if (resource.error || !resource.data) {
    return (
      <>
        <PageHeader title="Dashboard" description={longDate(today)} />
        <ErrorState
          message={resource.error ?? 'Your dashboard could not be loaded.'}
          onRetry={() => void resource.reload()}
        />
      </>
    );
  }

  const summary = resource.data;
  const water = goalProgress(summary.water.totalMl, summary.water.goalMl);
  const sleep = summary.sleep.entry
    ? goalProgress(summary.sleep.entry.hours, summary.sleep.goalHours)
    : null;
  const steps = goalProgress(summary.activity.steps, summary.activity.stepsGoal);
  const study = goalProgress(summary.study.totalMinutes, summary.study.goalMinutes);
  const calories = limitProgress(summary.nutrition.totalCalories, summary.nutrition.calorieLimit);

  const goalsMet = [water.met, Boolean(sleep?.met), steps.met, study.met].filter(Boolean).length;

  return (
    <>
      <PageHeader title="Dashboard" description={longDate(today)}>
        <Badge tone={summary.streak > 0 ? 'warn' : 'neutral'}>
          <Icon name="flame" size={13} />
          {summary.streak > 0 ? `${summary.streak} day streak` : 'Start a streak'}
        </Badge>
        <Badge tone={goalsMet >= 3 ? 'ok' : 'neutral'}>
          {goalsMet}/4 goals met today
        </Badge>
        <Link href="/analytics" className="btn-secondary !py-1.5 !text-xs">
          <Icon name="chart" size={14} />
          Trends
        </Link>
      </PageHeader>

      <section aria-labelledby="goals-heading" className="mb-6">
        <h2 id="goals-heading" className="sr-only">
          Today&apos;s goals
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <GoalCard
            icon="droplet"
            label="Hydration"
            valueText={formatMl(summary.water.totalMl)}
            targetText={formatMl(summary.water.goalMl)}
            value={summary.water.totalMl}
            max={summary.water.goalMl}
            href="/health#hydration"
            tone="accent"
            met={water.met}
          />
          <GoalCard
            icon="bed"
            label="Sleep"
            valueText={summary.sleep.entry ? `${summary.sleep.entry.hours}h` : '—'}
            targetText={`${summary.sleep.goalHours}h`}
            value={summary.sleep.entry?.hours ?? 0}
            max={summary.sleep.goalHours}
            href="/health#sleep"
            tone="accent"
            met={Boolean(sleep?.met)}
          />
          <GoalCard
            icon="shoe"
            label="Activity"
            valueText={formatNumber(summary.activity.steps)}
            targetText={formatNumber(summary.activity.stepsGoal)}
            value={summary.activity.steps}
            max={summary.activity.stepsGoal}
            href="/health#activity"
            tone="ok"
            met={steps.met}
          />
          <GoalCard
            icon="book"
            label="Study"
            valueText={formatMinutes(summary.study.totalMinutes)}
            targetText={formatMinutes(summary.study.goalMinutes)}
            value={summary.study.totalMinutes}
            max={summary.study.goalMinutes}
            href="/study"
            tone="accent"
            met={study.met}
          />
          <GoalCard
            icon="meal"
            label="Calories"
            valueText={formatNumber(summary.nutrition.totalCalories)}
            targetText={formatNumber(summary.nutrition.calorieLimit)}
            value={summary.nutrition.totalCalories}
            max={summary.nutrition.calorieLimit}
            href="/health#nutrition"
            tone={calories.over ? 'danger' : 'warn'}
          />
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section aria-labelledby="tasks-heading" className="card">
          <div className="mb-3 flex items-center justify-between">
            <h2 id="tasks-heading" className="text-base font-semibold">
              Your next tasks
            </h2>
            <Link href="/tasks" className="text-xs font-semibold text-accent hover:underline">
              View all
            </Link>
          </div>

          {summary.tasks.overdue > 0 && (
            <p className="mb-2 flex items-center gap-1.5 rounded-lg bg-danger/10 px-2.5 py-1.5 text-xs font-medium text-danger">
              <Icon name="alert" size={13} />
              {summary.tasks.overdue} overdue {summary.tasks.overdue === 1 ? 'task' : 'tasks'} need attention
            </p>
          )}

          {summary.tasks.open.length === 0 ? (
            <EmptyState
              icon="tasks"
              title="No open tasks"
              description="Add something you want to move forward today."
              action={
                <Link href="/tasks" className="btn-secondary mt-1 !py-1.5 !text-xs">
                  <Icon name="plus" size={14} /> New task
                </Link>
              }
            />
          ) : (
            <ul className="divide-y divide-line">
              {summary.tasks.open.map((task) => {
                const overdue = isOverdue(task, today);
                return (
                  <li key={task.id} className="flex items-start gap-3 py-2.5">
                    <input
                      type="checkbox"
                      id={`dash-task-${task.id}`}
                      checked={task.completed}
                      disabled={busyTaskId === task.id}
                      onChange={() => void toggleTask(task)}
                      className="mt-0.5 h-4 w-4 shrink-0 rounded border-line text-accent focus:ring-accent"
                    />
                    <label htmlFor={`dash-task-${task.id}`} className="min-w-0 flex-1 cursor-pointer">
                      <span className="block truncate text-sm font-medium text-ink">{task.title}</span>
                      <span className="mt-0.5 flex items-center gap-1.5 text-xs text-muted">
                        <span className="chip !border-transparent !px-0">{CATEGORY_LABELS[task.category]}</span>
                        {task.dueDate && (
                          <span className={overdue ? 'font-semibold text-danger' : ''}>
                            {overdue ? 'Overdue · ' : 'Due '}
                            {task.dueDate}
                          </span>
                        )}
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          )}

          <p className="mt-3 text-xs text-muted">
            {summary.tasks.completedToday} completed today · {summary.tasks.open.length} open
          </p>
        </section>

        <section aria-labelledby="study-heading" className="card">
          <div className="mb-3 flex items-center justify-between">
            <h2 id="study-heading" className="text-base font-semibold">
              Study today
            </h2>
            <Link href="/study" className="text-xs font-semibold text-accent hover:underline">
              Open timer
            </Link>
          </div>

          <p className="text-2xl font-semibold tabular-nums">
            {formatMinutes(summary.study.totalMinutes)}
            <span className="ml-1 text-xs font-medium text-muted">
              of {formatMinutes(summary.study.goalMinutes)}
            </span>
          </p>

          <div className="mt-3 flex h-16 items-end gap-1.5" aria-hidden="true">
            {summary.study.last7Days.map((day) => {
              const max = Math.max(...summary.study.last7Days.map((entry) => entry.minutes), 1);
              const height = day.minutes === 0 ? 4 : Math.max(8, Math.round((day.minutes / max) * 60));
              return (
                <div key={day.date} className="flex flex-1 flex-col items-center gap-1">
                  <div
                    className={`w-full rounded-t ${day.minutes > 0 ? 'bg-accent' : 'bg-line'}`}
                    style={{ height }}
                  />
                </div>
              );
            })}
          </div>

          {summary.study.sessions.length === 0 ? (
            <p className="mt-4 rounded-lg border border-dashed border-line p-3 text-xs text-muted">
              No focus sessions logged today. Start a {settings.studyGoalMinutes >= 45 ? '45' : '25'}-minute block
              to build momentum.
            </p>
          ) : (
            <ul className="mt-3 space-y-1.5">
              {summary.study.sessions.slice(0, 3).map((session) => (
                <li key={session.id} className="flex items-center justify-between gap-2 text-xs">
                  <span className="flex min-w-0 items-center gap-1.5 text-ink">
                    <Icon name="book" size={13} className="shrink-0 text-muted" />
                    <span className="truncate font-medium">{session.subject}</span>
                  </span>
                  <span className="shrink-0 text-muted">{formatMinutes(session.focusMinutes)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section aria-labelledby="quick-heading" className="mt-6">
        <h2 id="quick-heading" className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
          Quick log
        </h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Link href="/health#hydration" className="btn-secondary !justify-start">
            <Icon name="droplet" size={16} /> Water
          </Link>
          <Link href="/health#sleep" className="btn-secondary !justify-start">
            <Icon name="bed" size={16} /> Sleep
          </Link>
          <Link href="/health#nutrition" className="btn-secondary !justify-start">
            <Icon name="meal" size={16} /> Meal
          </Link>
          <Link href="/tasks" className="btn-secondary !justify-start">
            <Icon name="plus" size={16} /> Task
          </Link>
        </div>
      </section>
    </>
  );
}
