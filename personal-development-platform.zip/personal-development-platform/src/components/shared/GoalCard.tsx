import Link from 'next/link';
import { Icon, type IconName } from '@/components/icons';
import { ProgressBar } from '@/components/ui/ProgressBar';

interface Props {
  icon: IconName;
  label: string;
  valueText: string;
  targetText: string;
  value: number;
  max: number;
  href: string;
  tone?: 'accent' | 'ok' | 'warn' | 'danger';
  met?: boolean;
}

/** Compact goal tile used on the dashboard and analytics summary. */
export function GoalCard({
  icon,
  label,
  valueText,
  targetText,
  value,
  max,
  href,
  tone = 'accent',
  met = false,
}: Props) {
  return (
    <Link
      href={href}
      className="card group !p-4 transition-colors hover:border-accent/60 focus-visible:outline-none"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="flex items-center gap-2 text-sm font-medium text-ink">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-elevated text-muted group-hover:text-accent">
            <Icon name={icon} size={15} />
          </span>
          {label}
        </span>
        {met && (
          <span className="flex items-center gap-1 rounded-full bg-ok/10 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ok">
            <Icon name="check" size={11} /> met
          </span>
        )}
      </div>

      <p className="mt-3 text-xl font-semibold tabular-nums leading-none">
        {valueText}
        <span className="ml-1 text-xs font-medium text-muted">/ {targetText}</span>
      </p>

      <div className="mt-3">
        <ProgressBar
          value={value}
          max={max}
          label={`${label} progress`}
          tone={tone}
          showValue={false}
          hideLabel
          valueText={`${valueText} of ${targetText}`}
        />
      </div>
    </Link>
  );
}
