import 'server-only';

import { query, queryOne } from '@/lib/db/client';

/** Sessions are stored as a SHA-256 hash of the cookie token - never the token itself. */

export async function createSession(input: {
  tokenHash: string;
  userId: string;
  expiresAt: Date;
}): Promise<void> {
  await query(
    `INSERT INTO sessions (token_hash, user_id, expires_at) VALUES ($1, $2, $3)`,
    [input.tokenHash, input.userId, input.expiresAt.toISOString()],
  );
}

export async function findUserIdBySessionHash(tokenHash: string): Promise<string | null> {
  const row = await queryOne<{ user_id: string }>(
    `SELECT user_id FROM sessions WHERE token_hash = $1 AND expires_at > now()`,
    [tokenHash],
  );
  return row?.user_id ?? null;
}

export async function deleteSession(tokenHash: string): Promise<void> {
  await query(`DELETE FROM sessions WHERE token_hash = $1`, [tokenHash]);
}

export async function deleteExpiredSessions(): Promise<void> {
  await query(`DELETE FROM sessions WHERE expires_at <= now()`);
}
