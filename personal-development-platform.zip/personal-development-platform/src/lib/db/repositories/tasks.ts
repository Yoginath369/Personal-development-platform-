import 'server-only';

import type { Task, TaskCategory } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapTask } from '@/lib/db/mappers';

export interface TaskFilters {
  status?: 'all' | 'active' | 'completed' | 'overdue';
  category?: TaskCategory;
  search?: string;
  today: string;
  limit?: number;
}

/** Server-side filtering for API consumers; the UI also filters locally. */
export async function listTasks(userId: string, filters: TaskFilters): Promise<Task[]> {
  const conditions = ['user_id = $1'];
  const params: unknown[] = [userId];

  if (filters.status === 'active') conditions.push('completed = false');
  if (filters.status === 'completed') conditions.push('completed = true');
  if (filters.status === 'overdue') {
    params.push(filters.today);
    conditions.push(`completed = false AND due_date IS NOT NULL AND due_date < $${params.length}::date`);
  }
  if (filters.category) {
    params.push(filters.category);
    conditions.push(`category = $${params.length}`);
  }
  if (filters.search && filters.search.trim().length > 0) {
    params.push(`%${filters.search.trim()}%`);
    conditions.push(`(title ILIKE $${params.length} OR COALESCE(notes, '') ILIKE $${params.length})`);
  }

  params.push(Math.min(filters.limit ?? 300, 500));

  const rows = await query(
    `SELECT id, title, notes, category, due_date::text AS due_date, completed,
            completed_at, created_at, updated_at
     FROM tasks
     WHERE ${conditions.join(' AND ')}
     ORDER BY completed ASC,
              CASE WHEN due_date IS NULL THEN 1 ELSE 0 END,
              due_date ASC,
              created_at DESC
     LIMIT $${params.length}`,
    params,
  );
  return rows.map(mapTask);
}

export async function getTask(userId: string, id: string): Promise<Task | null> {
  const row = await queryOne(
    `SELECT id, title, notes, category, due_date::text AS due_date, completed,
            completed_at, created_at, updated_at
     FROM tasks WHERE user_id = $1 AND id = $2`,
    [userId, id],
  );
  return row ? mapTask(row) : null;
}

export async function createTask(
  userId: string,
  input: { title: string; notes: string | null; category: TaskCategory; dueDate: string | null },
): Promise<Task> {
  const row = await queryOne(
    `INSERT INTO tasks (user_id, title, notes, category, due_date)
     VALUES ($1, $2, $3, $4, $5::date)
     RETURNING id, title, notes, category, due_date::text AS due_date, completed,
               completed_at, created_at, updated_at`,
    [userId, input.title, input.notes, input.category, input.dueDate],
  );
  if (!row) throw new Error('Task could not be created');
  return mapTask(row);
}

export async function updateTask(
  userId: string,
  id: string,
  patch: {
    title?: string;
    notes?: string | null;
    category?: TaskCategory;
    dueDate?: string | null;
    completed?: boolean;
    completedOn?: string;
    today: string;
  },
): Promise<Task | null> {
  const sets: string[] = [];
  const params: unknown[] = [userId, id];

  const push = (fragment: string, value: unknown) => {
    params.push(value);
    sets.push(`${fragment} = $${params.length}`);
  };

  if (patch.title !== undefined) push('title', patch.title);
  if (patch.notes !== undefined) push('notes', patch.notes);
  if (patch.category !== undefined) push('category', patch.category);
  if (patch.dueDate !== undefined) {
    params.push(patch.dueDate);
    sets.push(`due_date = $${params.length}::date`);
  }
  if (patch.completed !== undefined) {
    push('completed', patch.completed);
    if (patch.completed) {
      params.push(new Date().toISOString());
      sets.push(`completed_at = $${params.length}::timestamptz`);
      params.push(patch.completedOn ?? patch.today);
      sets.push(`completed_on = $${params.length}::date`);
    } else {
      sets.push('completed_at = NULL');
      sets.push('completed_on = NULL');
    }
  }

  if (sets.length === 0) return getTask(userId, id);

  sets.push('updated_at = now()');

  const row = await queryOne(
    `UPDATE tasks SET ${sets.join(', ')}
     WHERE user_id = $1 AND id = $2
     RETURNING id, title, notes, category, due_date::text AS due_date, completed,
               completed_at, created_at, updated_at`,
    params,
  );
  return row ? mapTask(row) : null;
}

export async function deleteTask(userId: string, id: string): Promise<boolean> {
  const rows = await query(`DELETE FROM tasks WHERE user_id = $1 AND id = $2 RETURNING id`, [
    userId,
    id,
  ]);
  return rows.length > 0;
}

export async function duplicateTaskExists(
  userId: string,
  title: string,
  dueDate: string | null,
): Promise<boolean> {
  const row = await queryOne<{ exists: boolean }>(
    `SELECT EXISTS (
       SELECT 1 FROM tasks
       WHERE user_id = $1 AND completed = false AND lower(title) = lower($2)
         AND (($3::date IS NULL AND due_date IS NULL) OR due_date = $3::date)
     ) AS exists`,
    [userId, title, dueDate],
  );
  return row?.exists === true;
}
