import 'server-only';

import type { WaterEntry } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapWaterEntry } from '@/lib/db/mappers';

export async function getWaterEntries(userId: string, date: string): Promise<WaterEntry[]> {
  const rows = await query(
    `SELECT id, amount_ml, logged_at FROM water_logs
     WHERE user_id = $1 AND log_date = $2::date
     ORDER BY logged_at DESC`,
    [userId, date],
  );
  return rows.map(mapWaterEntry);
}

export async function getWaterTotal(userId: string, date: string): Promise<number> {
  const row = await queryOne<{ total: number }>(
    `SELECT COALESCE(SUM(amount_ml), 0)::int AS total FROM water_logs
     WHERE user_id = $1 AND log_date = $2::date`,
    [userId, date],
  );
  return row?.total ?? 0;
}

export async function addWater(userId: string, date: string, amountMl: number): Promise<WaterEntry> {
  const row = await queryOne(
    `INSERT INTO water_logs (user_id, log_date, amount_ml)
     VALUES ($1, $2::date, $3)
     RETURNING id, amount_ml, logged_at`,
    [userId, date, amountMl],
  );
  if (!row) throw new Error('Water entry could not be saved');
  return mapWaterEntry(row);
}

export async function deleteWater(userId: string, id: string): Promise<boolean> {
  const rows = await query(`DELETE FROM water_logs WHERE user_id = $1 AND id = $2 RETURNING id`, [
    userId,
    id,
  ]);
  return rows.length > 0;
}

export async function getWaterTotals(
  userId: string,
  start: string,
  end: string,
): Promise<Map<string, number>> {
  const rows = await query<{ day: string; total: number }>(
    `SELECT log_date::text AS day, COALESCE(SUM(amount_ml), 0)::int AS total
     FROM water_logs
     WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
     GROUP BY log_date`,
    [userId, start, end],
  );
  return new Map(rows.map((row) => [row.day, row.total]));
}
