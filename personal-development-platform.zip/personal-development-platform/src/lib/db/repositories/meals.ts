import 'server-only';

import type { MealEntry, MealType } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapMealEntry } from '@/lib/db/mappers';

export async function getMeals(userId: string, date: string): Promise<MealEntry[]> {
  const rows = await query(
    `SELECT id, meal_type, name, calories, logged_at
     FROM meals
     WHERE user_id = $1 AND log_date = $2::date
     ORDER BY logged_at DESC`,
    [userId, date],
  );
  return rows.map(mapMealEntry);
}

export async function addMeal(
  userId: string,
  input: { date: string; name: string; calories: number; mealType: MealType },
): Promise<MealEntry> {
  const row = await queryOne(
    `INSERT INTO meals (user_id, log_date, meal_type, name, calories)
     VALUES ($1, $2::date, $3, $4, $5)
     RETURNING id, meal_type, name, calories, logged_at`,
    [userId, input.date, input.mealType, input.name, input.calories],
  );
  if (!row) throw new Error('Meal could not be saved');
  return mapMealEntry(row);
}

export async function deleteMeal(userId: string, id: string): Promise<boolean> {
  const rows = await query(`DELETE FROM meals WHERE user_id = $1 AND id = $2 RETURNING id`, [
    userId,
    id,
  ]);
  return rows.length > 0;
}

export async function getCalorieTotals(
  userId: string,
  start: string,
  end: string,
): Promise<Map<string, number>> {
  const rows = await query<{ day: string; total: number }>(
    `SELECT log_date::text AS day, COALESCE(SUM(calories), 0)::int AS total
     FROM meals
     WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
     GROUP BY log_date`,
    [userId, start, end],
  );
  return new Map(rows.map((row) => [row.day, row.total]));
}
