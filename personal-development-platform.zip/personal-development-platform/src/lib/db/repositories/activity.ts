import 'server-only';

import type { ActivityEntry } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapActivityEntry } from '@/lib/db/mappers';

export async function getActivityEntries(userId: string, date: string): Promise<ActivityEntry[]> {
  const rows = await query(
    `SELECT id, kind, steps, exercise_type, duration_minutes, logged_at
     FROM activity_logs
     WHERE user_id = $1 AND log_date = $2::date
     ORDER BY logged_at DESC`,
    [userId, date],
  );
  return rows.map(mapActivityEntry);
}

export async function addSteps(userId: string, date: string, steps: number): Promise<ActivityEntry> {
  const row = await queryOne(
    `INSERT INTO activity_logs (user_id, log_date, kind, steps)
     VALUES ($1, $2::date, 'steps', $3)
     RETURNING id, kind, steps, exercise_type, duration_minutes, logged_at`,
    [userId, date, steps],
  );
  if (!row) throw new Error('Steps could not be saved');
  return mapActivityEntry(row);
}

export async function addExercise(
  userId: string,
  date: string,
  exerciseType: string,
  durationMinutes: number,
): Promise<ActivityEntry> {
  const row = await queryOne(
    `INSERT INTO activity_logs (user_id, log_date, kind, exercise_type, duration_minutes)
     VALUES ($1, $2::date, 'exercise', $3, $4)
     RETURNING id, kind, steps, exercise_type, duration_minutes, logged_at`,
    [userId, date, exerciseType, durationMinutes],
  );
  if (!row) throw new Error('Exercise could not be saved');
  return mapActivityEntry(row);
}

export async function deleteActivity(userId: string, id: string): Promise<boolean> {
  const rows = await query(
    `DELETE FROM activity_logs WHERE user_id = $1 AND id = $2 RETURNING id`,
    [userId, id],
  );
  return rows.length > 0;
}

export interface ActivityTotals {
  steps: number;
  exerciseMinutes: number;
  walkCount: number;
}

export async function getActivityTotals(
  userId: string,
  start: string,
  end: string,
): Promise<Map<string, ActivityTotals>> {
  const rows = await query<{
    day: string;
    steps: number;
    minutes: number;
    walks: number;
  }>(
    `SELECT log_date::text AS day,
            COALESCE(SUM(steps), 0)::int AS steps,
            COALESCE(SUM(duration_minutes), 0)::int AS minutes,
            COUNT(*) FILTER (WHERE kind = 'exercise' AND exercise_type ILIKE '%walk%')::int AS walks
     FROM activity_logs
     WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
     GROUP BY log_date`,
    [userId, start, end],
  );
  return new Map(
    rows.map((row) => [
      row.day,
      { steps: row.steps, exerciseMinutes: row.minutes, walkCount: row.walks },
    ]),
  );
}

export async function getDayActivityTotals(
  userId: string,
  date: string,
): Promise<ActivityTotals> {
  const totals = await getActivityTotals(userId, date, date);
  return totals.get(date) ?? { steps: 0, exerciseMinutes: 0, walkCount: 0 };
}
