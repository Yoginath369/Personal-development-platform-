import 'server-only';

import type { StudySession } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapStudySession } from '@/lib/db/mappers';

export async function getSessions(userId: string, date: string): Promise<StudySession[]> {
  const rows = await query(
    `SELECT id, subject, focus_minutes, started_at, ended_at, completed
     FROM study_sessions
     WHERE user_id = $1 AND log_date = $2::date
     ORDER BY started_at DESC`,
    [userId, date],
  );
  return rows.map(mapStudySession);
}

export async function getDayMinutes(userId: string, date: string): Promise<number> {
  const row = await queryOne<{ total: number }>(
    `SELECT COALESCE(SUM(focus_minutes), 0)::int AS total
     FROM study_sessions WHERE user_id = $1 AND log_date = $2::date`,
    [userId, date],
  );
  return row?.total ?? 0;
}

/**
 * Idempotent: the client sends a stable `clientId` per focus block, so a
 * retried request (flaky network, double effect in React strict mode) can never
 * create a duplicate session.
 */
export async function addSession(
  userId: string,
  input: {
    clientId: string;
    subject: string;
    focusMinutes: number;
    startedAt: string;
    endedAt: string;
    date: string;
  },
): Promise<{ session: StudySession; created: boolean }> {
  const inserted = await queryOne(
    `INSERT INTO study_sessions
       (user_id, client_id, subject, focus_minutes, started_at, ended_at, completed, log_date)
     VALUES ($1, $2, $3, $4, $5, $6, true, $7::date)
     ON CONFLICT (user_id, client_id) DO NOTHING
     RETURNING id, subject, focus_minutes, started_at, ended_at, completed`,
    [
      userId,
      input.clientId,
      input.subject,
      input.focusMinutes,
      input.startedAt,
      input.endedAt,
      input.date,
    ],
  );

  if (inserted) return { session: mapStudySession(inserted), created: true };

  const existing = await queryOne(
    `SELECT id, subject, focus_minutes, started_at, ended_at, completed
     FROM study_sessions WHERE user_id = $1 AND client_id = $2`,
    [userId, input.clientId],
  );
  if (!existing) throw new Error('Study session could not be saved');
  return { session: mapStudySession(existing), created: false };
}

export async function deleteSession(userId: string, id: string): Promise<boolean> {
  const rows = await query(
    `DELETE FROM study_sessions WHERE user_id = $1 AND id = $2 RETURNING id`,
    [userId, id],
  );
  return rows.length > 0;
}

export async function getDailyMinutes(
  userId: string,
  start: string,
  end: string,
): Promise<Map<string, number>> {
  const rows = await query<{ day: string; total: number }>(
    `SELECT log_date::text AS day, COALESCE(SUM(focus_minutes), 0)::int AS total
     FROM study_sessions
     WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
     GROUP BY log_date`,
    [userId, start, end],
  );
  return new Map(rows.map((row) => [row.day, row.total]));
}

/** Most recent distinct subjects, for the timer's datalist suggestions. */
export async function getRecentSubjects(userId: string, limit = 8): Promise<string[]> {
  const rows = await query<{ subject: string }>(
    `SELECT subject FROM (
       SELECT subject, MAX(started_at) AS last_used
       FROM study_sessions
       WHERE user_id = $1
       GROUP BY subject
       ORDER BY last_used DESC
       LIMIT $2
     ) recent`,
    [userId, limit],
  );
  return rows.map((row) => row.subject);
}
