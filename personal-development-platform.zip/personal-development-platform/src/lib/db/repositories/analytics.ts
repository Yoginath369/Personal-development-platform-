import 'server-only';

import type { DayMetrics, Settings } from '@/types';
import { query } from '@/lib/db/client';
import { rangeDates, addDaysISO } from '@/lib/logic/dates';

/**
 * One round trip returns the per-day rollup used by the dashboard, the charts
 * and the streak calculation. `generate_series` guarantees a row for every day,
 * including days with no data at all (zeros), so charts never have gaps.
 */
export async function getRangeMetrics(
  userId: string,
  start: string,
  end: string,
): Promise<DayMetrics[]> {
  const rows = await query<{
    date: string;
    water_ml: number;
    sleep_hours: number | null;
    sleep_quality: number | null;
    steps: number;
    exercise_minutes: number;
    calories: number;
    study_minutes: number;
    tasks_completed: number;
  }>(
    `WITH days AS (
       SELECT generate_series($2::date, $3::date, interval '1 day')::date AS d
     ),
     water AS (
       SELECT log_date, SUM(amount_ml)::int AS v FROM water_logs
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date GROUP BY log_date
     ),
     sleep AS (
       SELECT log_date, hours, quality FROM sleep_logs
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
     ),
     activity AS (
       SELECT log_date, SUM(steps)::int AS steps, SUM(duration_minutes)::int AS minutes
       FROM activity_logs
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date GROUP BY log_date
     ),
     nutrition AS (
       SELECT log_date, SUM(calories)::int AS v FROM meals
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date GROUP BY log_date
     ),
     study AS (
       SELECT log_date, SUM(focus_minutes)::int AS v FROM study_sessions
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date GROUP BY log_date
     ),
     tasks AS (
       SELECT completed_on AS log_date, COUNT(*)::int AS v FROM tasks
       WHERE user_id = $1 AND completed = true AND completed_on BETWEEN $2::date AND $3::date
       GROUP BY completed_on
     )
     SELECT to_char(days.d, 'YYYY-MM-DD') AS date,
            COALESCE(water.v, 0) AS water_ml,
            sleep.hours::double precision AS sleep_hours,
            sleep.quality::int AS sleep_quality,
            COALESCE(activity.steps, 0) AS steps,
            COALESCE(activity.minutes, 0) AS exercise_minutes,
            COALESCE(nutrition.v, 0) AS calories,
            COALESCE(study.v, 0) AS study_minutes,
            COALESCE(tasks.v, 0) AS tasks_completed
     FROM days
     LEFT JOIN water ON water.log_date = days.d
     LEFT JOIN sleep ON sleep.log_date = days.d
     LEFT JOIN activity ON activity.log_date = days.d
     LEFT JOIN nutrition ON nutrition.log_date = days.d
     LEFT JOIN study ON study.log_date = days.d
     LEFT JOIN tasks ON tasks.log_date = days.d
     ORDER BY days.d ASC`,
    [userId, start, end],
  );

  return rows.map((row) => ({
    date: row.date,
    waterMl: row.water_ml,
    sleepHours: row.sleep_hours,
    sleepQuality: row.sleep_quality,
    steps: row.steps,
    exerciseMinutes: row.exercise_minutes,
    calories: row.calories,
    studyMinutes: row.study_minutes,
    tasksCompleted: row.tasks_completed,
  }));
}

/**
 * A day counts toward the streak when at least one goal was hit or a task was
 * completed. Uses the user's *current* goals (documented in the README).
 */
export function activeDayDates(days: readonly DayMetrics[], goals: Settings): string[] {
  return days
    .filter(
      (day) =>
        day.waterMl >= goals.waterGoalMl ||
        (day.sleepHours !== null && day.sleepHours >= goals.sleepGoalHours) ||
        day.steps >= goals.stepsGoal ||
        day.studyMinutes >= goals.studyGoalMinutes ||
        day.tasksCompleted > 0,
    )
    .map((day) => day.date);
}

/** Streak look-back window (long enough for any realistic streak). */
export const STREAK_WINDOW_DAYS = 400;

export async function getStreakMetrics(
  userId: string,
  today: string,
  goals: Settings,
): Promise<{ activeDates: string[]; windowStart: string }> {
  const windowStart = addDaysISO(today, -(STREAK_WINDOW_DAYS - 1));
  const days = await getRangeMetrics(userId, windowStart, today);
  return { activeDates: activeDayDates(days, goals), windowStart };
}

/** Every date in [start,end] that has at least one log, for export/debugging. */
export async function getLoggedDates(userId: string, start: string, end: string): Promise<string[]> {
  const days = await getRangeMetrics(userId, start, end);
  return days
    .filter(
      (day) =>
        day.waterMl > 0 ||
        day.sleepHours !== null ||
        day.steps > 0 ||
        day.exerciseMinutes > 0 ||
        day.calories > 0 ||
        day.studyMinutes > 0 ||
        day.tasksCompleted > 0,
    )
    .map((day) => day.date);
}

export { rangeDates };
