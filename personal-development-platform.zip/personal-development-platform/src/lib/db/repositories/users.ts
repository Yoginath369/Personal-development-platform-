import 'server-only';

import type { Settings, User } from '@/types';
import { query, queryOne, transaction, type Row } from '@/lib/db/client';
import { mapSettings, mapUser } from '@/lib/db/mappers';

export const DEFAULT_SETTINGS: Settings = {
  waterGoalMl: 2500,
  sleepGoalHours: 8,
  stepsGoal: 8000,
  calorieLimit: 2200,
  studyGoalMinutes: 120,
  theme: 'system',
};

/** Creates the user and their settings row atomically. */
export async function createUser(input: {
  email: string;
  name: string;
  passwordHash: string;
}): Promise<User> {
  return transaction(async (tx) => {
    const rows = await tx.query<Row>(
      `INSERT INTO users (email, name, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, email, name, created_at`,
      [input.email.toLowerCase(), input.name, input.passwordHash],
    );
    const created = rows[0];
    if (!created) throw new Error('User could not be created');
    await tx.query(
      `INSERT INTO user_settings (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING`,
      [created.id],
    );
    return mapUser(created);
  });
}

export async function findUserByEmail(
  email: string,
): Promise<{ user: User; passwordHash: string } | null> {
  const row = await queryOne(
    `SELECT id, email, name, created_at, password_hash FROM users WHERE lower(email) = lower($1)`,
    [email],
  );
  if (!row) return null;
  return { user: mapUser(row), passwordHash: typeof row.password_hash === 'string' ? row.password_hash : '' };
}

export async function findUserById(id: string): Promise<User | null> {
  const row = await queryOne<Row>(`SELECT id, email, name, created_at FROM users WHERE id = $1`, [id]);
  return row ? mapUser(row) : null;
}

const SETTINGS_COLUMNS =
  'water_goal_ml, sleep_goal_hours, steps_goal, calorie_limit, study_goal_minutes, theme';

/**
 * Reads settings without writing on the hot path. A row is created only when it
 * is genuinely missing (accounts created before this table existed).
 */
export async function getSettings(userId: string): Promise<Settings> {
  const existing = await queryOne<Row>(
    `SELECT ${SETTINGS_COLUMNS} FROM user_settings WHERE user_id = $1`,
    [userId],
  );
  if (existing) return mapSettings(existing);

  const created = await queryOne<Row>(
    `INSERT INTO user_settings (user_id) VALUES ($1)
     ON CONFLICT (user_id) DO NOTHING
     RETURNING ${SETTINGS_COLUMNS}`,
    [userId],
  );
  if (created) return mapSettings(created);

  const raced = await queryOne<Row>(
    `SELECT ${SETTINGS_COLUMNS} FROM user_settings WHERE user_id = $1`,
    [userId],
  );
  return raced ? mapSettings(raced) : { ...DEFAULT_SETTINGS };
}

export async function updateSettings(userId: string, patch: Partial<Settings>): Promise<Settings> {
  const current = await getSettings(userId);
  const next = { ...current, ...patch };
  const rows = await query<Row>(
    `UPDATE user_settings SET
       water_goal_ml = $2,
       sleep_goal_hours = $3,
       steps_goal = $4,
       calorie_limit = $5,
       study_goal_minutes = $6,
       theme = $7,
       updated_at = now()
     WHERE user_id = $1
     RETURNING water_goal_ml, sleep_goal_hours, steps_goal, calorie_limit, study_goal_minutes, theme`,
    [
      userId,
      next.waterGoalMl,
      next.sleepGoalHours,
      next.stepsGoal,
      next.calorieLimit,
      next.studyGoalMinutes,
      next.theme,
    ],
  );
  const row = rows[0];
  if (!row) throw new Error('Settings could not be updated');
  return mapSettings(row);
}
