import 'server-only';

import type { SleepEntry } from '@/types';
import { query, queryOne } from '@/lib/db/client';
import { mapSleepEntry } from '@/lib/db/mappers';

export async function getSleep(userId: string, date: string): Promise<SleepEntry | null> {
  const row = await queryOne(
    `SELECT log_date::text AS log_date, hours, quality, updated_at
     FROM sleep_logs WHERE user_id = $1 AND log_date = $2::date`,
    [userId, date],
  );
  return row ? mapSleepEntry(row) : null;
}

/** One sleep record per day - a second submit updates the first. */
export async function upsertSleep(
  userId: string,
  date: string,
  hours: number,
  quality: number,
): Promise<SleepEntry> {
  const row = await queryOne(
    `INSERT INTO sleep_logs (user_id, log_date, hours, quality)
     VALUES ($1, $2::date, $3, $4)
     ON CONFLICT (user_id, log_date)
     DO UPDATE SET hours = EXCLUDED.hours, quality = EXCLUDED.quality, updated_at = now()
     RETURNING log_date::text AS log_date, hours, quality, updated_at`,
    [userId, date, hours, quality],
  );
  if (!row) throw new Error('Sleep entry could not be saved');
  return mapSleepEntry(row);
}

export async function deleteSleep(userId: string, date: string): Promise<boolean> {
  const rows = await query(
    `DELETE FROM sleep_logs WHERE user_id = $1 AND log_date = $2::date RETURNING id`,
    [userId, date],
  );
  return rows.length > 0;
}

export async function getSleepTotals(
  userId: string,
  start: string,
  end: string,
): Promise<Map<string, { hours: number; quality: number }>> {
  const rows = await query<{ day: string; hours: number; quality: number }>(
    `SELECT log_date::text AS day, hours::double precision AS hours, quality::int AS quality
     FROM sleep_logs
     WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date`,
    [userId, start, end],
  );
  return new Map(rows.map((row) => [row.day, { hours: row.hours, quality: row.quality }]));
}
