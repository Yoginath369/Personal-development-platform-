import type {
  ActivityEntry,
  MealEntry,
  Settings,
  SleepEntry,
  StudySession,
  Task,
  TaskCategory,
  MealType,
  ActivityKind,
  ThemePreference,
  User,
  WaterEntry,
} from '@/types';
import type { Row } from './client';

/** Row -> domain mappers. Keeps SQL column names out of the rest of the app. */

function num(value: unknown, fallback = 0): number {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function str(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

function nullableStr(value: unknown): string | null {
  return typeof value === 'string' ? value : null;
}

function nullableNum(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function iso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  return str(value);
}

export function mapUser(row: Row): User {
  return {
    id: str(row.id),
    email: str(row.email),
    name: str(row.name),
    createdAt: iso(row.created_at),
  };
}

export function mapSettings(row: Row): Settings {
  return {
    waterGoalMl: num(row.water_goal_ml, 2500),
    sleepGoalHours: num(row.sleep_goal_hours, 8),
    stepsGoal: num(row.steps_goal, 8000),
    calorieLimit: num(row.calorie_limit, 2200),
    studyGoalMinutes: num(row.study_goal_minutes, 120),
    theme: (str(row.theme, 'system') as ThemePreference) ?? 'system',
  };
}

export function mapWaterEntry(row: Row): WaterEntry {
  return {
    id: str(row.id),
    amountMl: num(row.amount_ml),
    loggedAt: iso(row.logged_at),
  };
}

export function mapSleepEntry(row: Row): SleepEntry {
  return {
    date: str(row.log_date),
    hours: num(row.hours),
    quality: num(row.quality),
    updatedAt: iso(row.updated_at),
  };
}

export function mapActivityEntry(row: Row): ActivityEntry {
  return {
    id: str(row.id),
    kind: str(row.kind) as ActivityKind,
    steps: nullableNum(row.steps),
    exerciseType: nullableStr(row.exercise_type),
    durationMinutes: nullableNum(row.duration_minutes),
    loggedAt: iso(row.logged_at),
  };
}

export function mapMealEntry(row: Row): MealEntry {
  return {
    id: str(row.id),
    mealType: str(row.meal_type) as MealType,
    name: str(row.name),
    calories: num(row.calories),
    loggedAt: iso(row.logged_at),
  };
}

export function mapStudySession(row: Row): StudySession {
  return {
    id: str(row.id),
    subject: str(row.subject),
    focusMinutes: num(row.focus_minutes),
    startedAt: iso(row.started_at),
    endedAt: iso(row.ended_at),
    completed: row.completed !== false,
  };
}

export function mapTask(row: Row): Task {
  return {
    id: str(row.id),
    title: str(row.title),
    notes: nullableStr(row.notes),
    category: str(row.category, 'personal') as TaskCategory,
    dueDate: nullableStr(row.due_date),
    completed: row.completed === true,
    completedAt: row.completed_at ? iso(row.completed_at) : null,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
}

export { num, str, nullableNum, nullableStr, iso };
