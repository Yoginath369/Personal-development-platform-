import 'server-only';

import { SCHEMA_SQL } from './schema';

/**
 * Database access.
 *
 * One SQL dialect (PostgreSQL) everywhere:
 *  - DATABASE_URL set  -> node-postgres pool (Neon / Supabase / RDS / local PG)
 *  - DATABASE_URL empty -> embedded PostgreSQL (PGlite) persisted to ./.data
 *
 * Both drivers expose the same `query(text, params) -> rows` contract, so no
 * other module in the app knows or cares which one is active.
 */

export type Row = Record<string, unknown>;

export interface Queryable {
  query<T extends Row = Row>(text: string, params?: readonly unknown[]): Promise<T[]>;
}

type PGliteLike = {
  query<T extends Row = Row>(text: string, params?: readonly unknown[]): Promise<{ rows: T[] }>;
  /** PGlite only allows one statement per query(); multi-statement DDL uses exec(). */
  exec(sql: string): Promise<unknown>;
  close(): Promise<void>;
};

type PgPoolLike = {
  query<T extends Row = Row>(text: string, params?: readonly unknown[]): Promise<{ rows: T[] }>;
  connect(): Promise<{
    query<T extends Row = Row>(text: string, params?: readonly unknown[]): Promise<{ rows: T[] }>;
    release(): void;
  }>;
  end(): Promise<void>;
};

const globalForDb = globalThis as unknown as {
  __pdpPool?: PgPoolLike;
  __pdpPglite?: Promise<PGliteLike>;
  __pdpSchema?: Promise<void>;
  __pdpMutex?: Promise<unknown>;
};

function databaseUrl(): string {
  return (process.env.DATABASE_URL ?? '').trim();
}

export function databaseDriver(): 'postgres' | 'embedded' {
  return databaseUrl() ? 'postgres' : 'embedded';
}

function assertDriverAllowed() {
  const isServerlessProd =
    process.env.NODE_ENV === 'production' &&
    (process.env.VERCEL === '1' || process.env.NETLIFY === 'true');

  if (isServerlessProd && !databaseUrl()) {
    throw new Error(
      'DATABASE_URL is not set. The embedded database cannot write to a read-only ' +
        'serverless filesystem - configure a managed PostgreSQL connection string.',
    );
  }
}

async function getPool(): Promise<PgPoolLike> {
  if (globalForDb.__pdpPool) return globalForDb.__pdpPool;

  const { default: pg } = await import('pg');
  const needsSsl = !/localhost|127\.0\.0\.1|::1/.test(databaseUrl());
  const pool = new pg.Pool({
    connectionString: databaseUrl(),
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
    ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
  }) as unknown as PgPoolLike;

  globalForDb.__pdpPool = pool;
  return pool;
}

async function getPglite(): Promise<PGliteLike> {
  if (!globalForDb.__pdpPglite) {
    globalForDb.__pdpPglite = (async () => {
      const { PGlite } = await import('@electric-sql/pglite');
      const { mkdir } = await import('node:fs/promises');
      const { join } = await import('node:path');
      const dataDir = join(process.cwd(), '.data', 'pgdata');
      await mkdir(dataDir, { recursive: true });
      const db = (await PGlite.create({ dataDir })) as unknown as PGliteLike;
      return db;
    })();
  }
  return globalForDb.__pdpPglite;
}

/** Serialises statements against the single embedded connection. */
async function withMutex<T>(fn: () => Promise<T>): Promise<T> {
  const previous = globalForDb.__pdpMutex ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>((resolve) => {
    release = resolve;
  });
  globalForDb.__pdpMutex = previous.then(() => current);
  await previous;
  try {
    return await fn();
  } finally {
    release();
  }
}

async function runQuery<T extends Row>(text: string, params: readonly unknown[]): Promise<T[]> {
  assertDriverAllowed();
  if (databaseDriver() === 'postgres') {
    const pool = await getPool();
    const result = await pool.query<T>(text, params);
    return result.rows;
  }
  const db = await getPglite();
  return withMutex(async () => {
    const result = await db.query<T>(text, params);
    return result.rows;
  });
}

async function migrate(): Promise<void> {
  assertDriverAllowed();
  if (databaseDriver() === 'postgres') {
    const pool = await getPool();
    await pool.query(SCHEMA_SQL);
    return;
  }
  const db = await getPglite();
  await withMutex(async () => {
    await db.exec(SCHEMA_SQL);
  });
}

/**
 * Runs the idempotent schema exactly once per process (unless disabled).
 * Failures are surfaced to the caller so screens can show a real error state.
 */
export function ensureSchema(): Promise<void> {
  if (!globalForDb.__pdpSchema) {
    globalForDb.__pdpSchema = (async () => {
      if (process.env.MIGRATE_ON_START === 'false') return;
      await migrate();
    })().catch((error: unknown) => {
      globalForDb.__pdpSchema = undefined;
      throw error;
    });
  }
  return globalForDb.__pdpSchema;
}

export async function query<T extends Row = Row>(
  text: string,
  params: readonly unknown[] = [],
): Promise<T[]> {
  await ensureSchema();
  return runQuery<T>(text, params);
}

/** Single-row convenience wrapper. */
export async function queryOne<T extends Row = Row>(
  text: string,
  params: readonly unknown[] = [],
): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows[0] ?? null;
}

/**
 * Transaction helper with an identical signature for both drivers.
 */
export async function transaction<T>(fn: (tx: Queryable) => Promise<T>): Promise<T> {
  await ensureSchema();
  assertDriverAllowed();

  if (databaseDriver() === 'postgres') {
    const pool = await getPool();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn({
        query: async <R extends Row = Row>(text: string, params: readonly unknown[] = []) =>
          (await client.query<R>(text, params)).rows,
      });
      await client.query('COMMIT');
      return result;
    } catch (error) {
      try {
        await client.query('ROLLBACK');
      } catch {
        /* connection already unusable - ignore */
      }
      throw error;
    } finally {
      client.release();
    }
  }

  const db = await getPglite();
  return withMutex(async () => {
    await db.query('BEGIN');
    try {
      const result = await fn({
        query: async <R extends Row = Row>(text: string, params: readonly unknown[] = []) =>
          (await db.query<R>(text, params)).rows,
      });
      await db.query('COMMIT');
      return result;
    } catch (error) {
      await db.query('ROLLBACK');
      throw error;
    }
  });
}

/** Test/CLI helper - closes the pool so Node can exit. */
export async function closeDatabase(): Promise<void> {
  if (globalForDb.__pdpPool) {
    await globalForDb.__pdpPool.end();
    globalForDb.__pdpPool = undefined;
  }
  if (globalForDb.__pdpPglite) {
    const db = await globalForDb.__pdpPglite.catch(() => null);
    if (db) await db.close().catch(() => undefined);
    globalForDb.__pdpPglite = undefined;
  }
  globalForDb.__pdpSchema = undefined;
}
