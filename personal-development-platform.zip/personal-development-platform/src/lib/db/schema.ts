/**
 * Canonical database schema (PostgreSQL).
 *
 * This string is the single source of truth: it is executed automatically on
 * first use (see client.ts -> ensureSchema) and `db/schema.sql` is generated
 * from it for manual/psql migrations. Every statement is idempotent so it is
 * safe to run on every cold start.
 */

export const SCHEMA_SQL = /* sql */ `
CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         text NOT NULL,
  name          text NOT NULL,
  password_hash text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_idx ON users (lower(email));

CREATE TABLE IF NOT EXISTS sessions (
  token_hash text PRIMARY KEY,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);

CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);
CREATE INDEX IF NOT EXISTS sessions_expires_idx ON sessions (expires_at);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id            uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  water_goal_ml      integer NOT NULL DEFAULT 2500 CHECK (water_goal_ml BETWEEN 250 AND 20000),
  sleep_goal_hours   real    NOT NULL DEFAULT 8    CHECK (sleep_goal_hours > 0 AND sleep_goal_hours <= 24),
  steps_goal         integer NOT NULL DEFAULT 8000 CHECK (steps_goal BETWEEN 100 AND 200000),
  calorie_limit      integer NOT NULL DEFAULT 2200 CHECK (calorie_limit BETWEEN 500 AND 20000),
  study_goal_minutes integer NOT NULL DEFAULT 120  CHECK (study_goal_minutes BETWEEN 15 AND 1440),
  theme              text    NOT NULL DEFAULT 'system' CHECK (theme IN ('light','dark','system')),
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS water_logs (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  log_date   date NOT NULL,
  amount_ml  integer NOT NULL CHECK (amount_ml > 0 AND amount_ml <= 5000),
  logged_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS water_logs_user_date_idx ON water_logs (user_id, log_date);

CREATE TABLE IF NOT EXISTS sleep_logs (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  log_date   date NOT NULL,
  hours      real NOT NULL CHECK (hours > 0 AND hours <= 24),
  quality    smallint NOT NULL CHECK (quality BETWEEN 1 AND 5),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, log_date)
);

CREATE INDEX IF NOT EXISTS sleep_logs_user_date_idx ON sleep_logs (user_id, log_date);

CREATE TABLE IF NOT EXISTS activity_logs (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  log_date         date NOT NULL,
  kind             text NOT NULL CHECK (kind IN ('steps','exercise')),
  steps            integer CHECK (steps IS NULL OR (steps > 0 AND steps <= 200000)),
  exercise_type    text,
  duration_minutes integer CHECK (duration_minutes IS NULL OR (duration_minutes > 0 AND duration_minutes <= 1440)),
  logged_at        timestamptz NOT NULL DEFAULT now(),
  CHECK (
    (kind = 'steps' AND steps IS NOT NULL AND exercise_type IS NULL AND duration_minutes IS NULL)
    OR
    (kind = 'exercise' AND exercise_type IS NOT NULL AND duration_minutes IS NOT NULL AND steps IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS activity_logs_user_date_idx ON activity_logs (user_id, log_date);

CREATE TABLE IF NOT EXISTS meals (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  log_date   date NOT NULL,
  meal_type  text NOT NULL CHECK (meal_type IN ('breakfast','lunch','dinner','snack')),
  name       text NOT NULL,
  calories   integer NOT NULL CHECK (calories > 0 AND calories <= 5000),
  logged_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS meals_user_date_idx ON meals (user_id, log_date);

CREATE TABLE IF NOT EXISTS study_sessions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id     text NOT NULL,
  subject       text NOT NULL,
  focus_minutes integer NOT NULL CHECK (focus_minutes > 0 AND focus_minutes <= 240),
  started_at    timestamptz NOT NULL,
  ended_at      timestamptz NOT NULL,
  completed     boolean NOT NULL DEFAULT true,
  log_date      date NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, client_id)
);

CREATE INDEX IF NOT EXISTS study_sessions_user_date_idx ON study_sessions (user_id, log_date);

CREATE TABLE IF NOT EXISTS tasks (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title        text NOT NULL,
  notes        text,
  category     text NOT NULL CHECK (category IN ('study','personal','fitness','work')),
  due_date     date,
  completed    boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  -- Local calendar date of completion (user timezone), so daily analytics and
  -- the dashboard agree even when the server runs in a different timezone.
  completed_on date,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS tasks_user_due_idx ON tasks (user_id, completed, due_date);
CREATE INDEX IF NOT EXISTS tasks_user_completed_on_idx ON tasks (user_id, completed_on);

-- Additive migration for databases created before completed_on existed.
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS completed_on date;
`;
