import { z } from 'zod';
import { isValidISODate } from '@/lib/logic/dates';

/**
 * Every write path is validated here. Messages are user facing (rendered inline
 * under the offending field).
 */

/** Trims, collapses whitespace and strips control characters. */
const cleanText = (value: string): string =>
  value
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const text = (min: number, max: number, label: string) =>
  z
    .string({ invalid_type_error: `${label} must be text.` })
    .transform(cleanText)
    .refine((value) => value.length >= min, { message: `${label} is required.` })
    .refine((value) => value.length <= max, { message: `${label} must be ${max} characters or fewer.` });

const optionalText = (max: number, label: string) =>
  z
    .union([z.string(), z.null()])
    .optional()
    .transform((value) => (typeof value === 'string' ? cleanText(value) : ''))
    .refine((value) => value.length <= max, { message: `${label} must be ${max} characters or fewer.` })
    .transform((value) => (value.length === 0 ? null : value));

const int = (min: number, max: number, label: string) =>
  z.coerce
    .number({
      invalid_type_error: `${label} must be a number.`,
      required_error: `${label} is required.`,
    })
    .refine(Number.isFinite, { message: `${label} must be a number.` })
    .refine((value) => Number.isInteger(value), { message: `${label} must be a whole number.` })
    .refine((value) => value >= min, { message: `${label} must be at least ${min}.` })
    .refine((value) => value <= max, { message: `${label} must be ${max} or less.` });

const decimal = (min: number, max: number, label: string, decimals = 2) =>
  z.coerce
    .number({
      invalid_type_error: `${label} must be a number.`,
      required_error: `${label} is required.`,
    })
    .refine(Number.isFinite, { message: `${label} must be a number.` })
    .refine((value) => value >= min, { message: `${label} must be at least ${min}.` })
    .refine((value) => value <= max, { message: `${label} must be ${max} or less.` })
    .transform((value) => Number(value.toFixed(decimals)));

/** Local calendar date (YYYY-MM-DD) with a sane range guard. */
export const isoDateField = z
  .string({ required_error: 'A date is required.' })
  .refine(isValidISODate, { message: 'Use a valid date (YYYY-MM-DD).' })
  .refine((value) => value >= '2000-01-01' && value <= '2100-12-31', {
    message: 'Date is outside the supported range.',
  });

export const isoDateTimeField = z
  .string({ required_error: 'A timestamp is required.' })
  .refine((value) => !Number.isNaN(Date.parse(value)), { message: 'Use a valid timestamp.' });

/* ------------------------------- auth ---------------------------------- */

export const registerSchema = z.object({
  name: text(2, 60, 'Name'),
  email: z
    .string({ required_error: 'Email is required.' })
    .transform((value) => value.trim().toLowerCase())
    .refine((value) => value.length > 0, { message: 'Email is required.' })
    .refine((value) => value.length <= 254, { message: 'Email is too long.' })
    .refine((value) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value), {
      message: 'Enter a valid email address.',
    }),
  password: z
    .string({ required_error: 'Password is required.' })
    .min(8, { message: 'Password must be at least 8 characters.' })
    .max(100, { message: 'Password must be 100 characters or fewer.' })
    .refine((value) => /[a-zA-Z]/.test(value), { message: 'Include at least one letter.' })
    .refine((value) => /[0-9]/.test(value), { message: 'Include at least one number.' }),
});

export const loginSchema = z.object({
  email: z
    .string({ required_error: 'Email is required.' })
    .transform((value) => value.trim().toLowerCase())
    .refine((value) => value.length > 0, { message: 'Email is required.' }),
  password: z
    .string({ required_error: 'Password is required.' })
    .min(1, { message: 'Password is required.' })
    .max(100, { message: 'Password must be 100 characters or fewer.' }),
});

/* ------------------------------- health -------------------------------- */

const dateQuery = z.object({ date: isoDateField });

export const waterQuerySchema = dateQuery;
export const waterCreateSchema = z.object({
  date: isoDateField,
  amountMl: int(1, 5000, 'Amount'),
});

export const sleepQuerySchema = dateQuery;
export const sleepWriteSchema = z.object({
  date: isoDateField,
  hours: decimal(0.25, 24, 'Hours'),
  quality: int(1, 5, 'Quality'),
});

export const activityQuerySchema = dateQuery;
export const activityCreateSchema = z.discriminatedUnion('kind', [
  z.object({
    kind: z.literal('steps'),
    date: isoDateField,
    steps: int(1, 200000, 'Steps'),
  }),
  z.object({
    kind: z.literal('exercise'),
    date: isoDateField,
    exerciseType: text(2, 60, 'Exercise type'),
    durationMinutes: int(1, 1440, 'Duration'),
  }),
]);

export const nutritionQuerySchema = dateQuery;
export const mealCreateSchema = z.object({
  date: isoDateField,
  name: text(1, 80, 'Meal name'),
  calories: int(1, 5000, 'Calories'),
  mealType: z.enum(['breakfast', 'lunch', 'dinner', 'snack'], {
    errorMap: () => ({ message: 'Choose a meal type.' }),
  }),
});

/* -------------------------------- study -------------------------------- */

export const studyQuerySchema = dateQuery;
export const studyCreateSchema = z
  .object({
    clientId: text(8, 64, 'Session id'),
    subject: z
      .union([z.string(), z.null()])
      .optional()
      .transform((value) => (typeof value === 'string' ? cleanText(value) : ''))
      .refine((value) => value.length <= 60, { message: 'Subject must be 60 characters or fewer.' })
      .transform((value) => (value.length === 0 ? 'General' : value)),
    focusMinutes: int(1, 240, 'Focus length'),
    startedAt: isoDateTimeField,
    endedAt: isoDateTimeField,
    date: isoDateField,
  })
  .refine((value) => Date.parse(value.endedAt) > Date.parse(value.startedAt), {
    message: 'Session must end after it starts.',
    path: ['endedAt'],
  });

/* -------------------------------- tasks -------------------------------- */

export const taskListQuerySchema = z.object({
  status: z.enum(['all', 'active', 'completed', 'overdue']).optional(),
  category: z.enum(['study', 'personal', 'fitness', 'work']).optional(),
  q: z.string().max(120).optional(),
});

export const taskCreateSchema = z.object({
  title: text(1, 120, 'Title'),
  notes: optionalText(1000, 'Notes'),
  category: z.enum(['study', 'personal', 'fitness', 'work'], {
    errorMap: () => ({ message: 'Choose a category.' }),
  }),
  dueDate: z
    .union([isoDateField, z.literal(''), z.null()])
    .optional()
    .transform((value) => (value ? value : null)),
});

export const taskUpdateSchema = z
  .object({
    title: text(1, 120, 'Title').optional(),
    notes: optionalText(1000, 'Notes').optional(),
    category: z
      .enum(['study', 'personal', 'fitness', 'work'], {
        errorMap: () => ({ message: 'Choose a category.' }),
      })
      .optional(),
    // `undefined` means "leave unchanged"; '' or null clears the due date.
    dueDate: z
      .union([isoDateField, z.literal(''), z.null(), z.undefined()])
      .transform((value): string | null | undefined => {
        if (value === undefined) return undefined;
        return value === '' || value === null ? null : value;
      }),
    completed: z.boolean().optional(),
    /** Local date of completion, so analytics stay timezone-correct. */
    completedOn: isoDateField.optional(),
  })
  .refine((value) => Object.entries(value).some(([, field]) => field !== undefined), {
    message: 'Nothing to update.',
  });

/* ------------------------- settings / analytics ------------------------- */

export const settingsPatchSchema = z
  .object({
    waterGoalMl: int(250, 20000, 'Water goal').optional(),
    sleepGoalHours: decimal(1, 24, 'Sleep goal').optional(),
    stepsGoal: int(100, 200000, 'Steps goal').optional(),
    calorieLimit: int(500, 20000, 'Calorie limit').optional(),
    studyGoalMinutes: int(15, 1440, 'Study goal').optional(),
    theme: z.enum(['light', 'dark', 'system'], { errorMap: () => ({ message: 'Choose a theme.' }) }).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, { message: 'Nothing to update.' });

export const analyticsQuerySchema = z
  .object({
    start: isoDateField.optional(),
    end: isoDateField.optional(),
    days: z.coerce.number().int().min(1).max(90).optional(),
  })
  .refine(
    (value) => !(value.start && value.end) || value.start <= value.end,
    { message: 'Start date must be on or before the end date.' },
  );

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type TaskCreateInput = z.infer<typeof taskCreateSchema>;
export type TaskUpdateInput = z.infer<typeof taskUpdateSchema>;
export type SettingsPatchInput = z.infer<typeof settingsPatchSchema>;
