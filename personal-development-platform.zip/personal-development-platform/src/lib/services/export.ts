import 'server-only';

import { query } from '@/lib/db/client';
import type { Settings, User } from '@/types';

/**
 * Full per-user data export (GDPR style). Only ever contains the requesting
 * user's rows - every query is scoped by user_id.
 */
export async function buildUserExport(user: User, settings: Settings, today: string) {
  const [water, sleep, activity, meals, study, tasks] = await Promise.all([
    query(
      `SELECT id, log_date::text AS date, amount_ml, logged_at FROM water_logs
       WHERE user_id = $1 ORDER BY log_date DESC, logged_at DESC`,
      [user.id],
    ),
    query(
      `SELECT id, log_date::text AS date, hours::double precision AS hours, quality, updated_at
       FROM sleep_logs WHERE user_id = $1 ORDER BY log_date DESC`,
      [user.id],
    ),
    query(
      `SELECT id, log_date::text AS date, kind, steps, exercise_type, duration_minutes, logged_at
       FROM activity_logs WHERE user_id = $1 ORDER BY log_date DESC, logged_at DESC`,
      [user.id],
    ),
    query(
      `SELECT id, log_date::text AS date, meal_type, name, calories, logged_at FROM meals
       WHERE user_id = $1 ORDER BY log_date DESC, logged_at DESC`,
      [user.id],
    ),
    query(
      `SELECT id, log_date::text AS date, subject, focus_minutes, started_at, ended_at, completed
       FROM study_sessions WHERE user_id = $1 ORDER BY started_at DESC`,
      [user.id],
    ),
    query(
      `SELECT id, title, notes, category, due_date::text AS due_date, completed, completed_at,
              completed_on::text AS completed_on, created_at, updated_at
       FROM tasks WHERE user_id = $1 ORDER BY created_at DESC`,
      [user.id],
    ),
  ]);

  return {
    exportVersion: 1,
    exportedAt: new Date().toISOString(),
    localDate: today,
    account: { id: user.id, email: user.email, name: user.name, createdAt: user.createdAt },
    settings,
    water,
    sleep,
    activity,
    meals,
    studySessions: study,
    tasks,
    counts: {
      water: water.length,
      sleep: sleep.length,
      activity: activity.length,
      meals: meals.length,
      studySessions: study.length,
      tasks: tasks.length,
    },
  };
}
