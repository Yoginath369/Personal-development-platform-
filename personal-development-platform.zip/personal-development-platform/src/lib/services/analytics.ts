import 'server-only';

import type { AnalyticsSummary, Settings } from '@/types';
import { activeDayDates, getRangeMetrics, getStreakMetrics } from '@/lib/db/repositories/analytics';
import { average, countReached, round, sum } from '@/lib/logic/goals';
import { computeBestStreak, computeStreak } from '@/lib/logic/streak';
import { addDaysISO, daysBetweenISO, isValidISODate, rangeDates, toISODate } from '@/lib/logic/dates';

export function resolveRange(params: {
  start?: string;
  end?: string;
  days?: number;
  today?: string;
}): { start: string; end: string; days: number } {
  const today = params.today && isValidISODate(params.today) ? params.today : toISODate(new Date());
  const end = params.end && isValidISODate(params.end) ? params.end : today;
  const span = Math.min(Math.max(params.days ?? 7, 1), 90);
  const start =
    params.start && isValidISODate(params.start) ? params.start : addDaysISO(end, -(span - 1));

  const cappedStart = daysBetweenISO(start, end) > 89 ? addDaysISO(end, -89) : start;
  return { start: cappedStart, end, days: daysBetweenISO(cappedStart, end) + 1 };
}

export async function getAnalytics(
  userId: string,
  settings: Settings,
  params: { start?: string; end?: string; days?: number },
): Promise<AnalyticsSummary> {
  const range = resolveRange(params);
  const [days, streakMetrics] = await Promise.all([
    getRangeMetrics(userId, range.start, range.end),
    getStreakMetrics(userId, range.end, settings),
  ]);

  const sleepValues = days
    .map((day) => day.sleepHours)
    .filter((value): value is number => value !== null && value > 0);

  const waterValues = days.map((day) => day.waterMl);
  const stepValues = days.map((day) => day.steps);
  const studyValues = days.map((day) => day.studyMinutes);
  const calorieValues = days.map((day) => day.calories);

  return {
    range,
    goals: settings,
    days,
    totals: {
      waterMl: sum(waterValues),
      sleepHours: round(sum(sleepValues), 1),
      steps: sum(stepValues),
      exerciseMinutes: sum(days.map((day) => day.exerciseMinutes)),
      calories: sum(calorieValues),
      studyMinutes: sum(studyValues),
      tasksCompleted: sum(days.map((day) => day.tasksCompleted)),
    },
    averages: {
      waterMl: round(average(waterValues)),
      sleepHours: round(sleepValues.length > 0 ? average(sleepValues) : 0, 1),
      steps: round(average(stepValues)),
      studyMinutes: round(average(studyValues)),
      calories: round(average(calorieValues)),
    },
    goalHitDays: {
      water: countReached(waterValues, settings.waterGoalMl),
      sleep: countReached(sleepValues, settings.sleepGoalHours),
      steps: countReached(stepValues, settings.stepsGoal),
      study: countReached(studyValues, settings.studyGoalMinutes),
    },
    streak: computeStreak(streakMetrics.activeDates, range.end),
    bestStreak: computeBestStreak(streakMetrics.activeDates),
  };
}

export { activeDayDates, rangeDates };
