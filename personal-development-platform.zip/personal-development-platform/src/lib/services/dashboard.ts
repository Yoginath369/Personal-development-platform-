import 'server-only';

import type { DashboardSummary, Settings } from '@/types';
import { getWaterEntries, getWaterTotal } from '@/lib/db/repositories/water';
import { getSleep } from '@/lib/db/repositories/sleep';
import { getActivityEntries, getDayActivityTotals } from '@/lib/db/repositories/activity';
import { getCalorieTotals, getMeals } from '@/lib/db/repositories/meals';
import { getDayMinutes, getSessions } from '@/lib/db/repositories/study';
import { getStreakMetrics } from '@/lib/db/repositories/analytics';
import { query } from '@/lib/db/client';
import { mapTask } from '@/lib/db/mappers';
import { computeStreak } from '@/lib/logic/streak';
import { addDaysISO, isValidISODate, todayISO } from '@/lib/logic/dates';

/** Everything the dashboard needs, in one request. */
export async function getDashboardSummary(
  userId: string,
  settings: Settings,
  requestedDate?: string,
): Promise<DashboardSummary> {
  const today = requestedDate && isValidISODate(requestedDate) ? requestedDate : todayISO();
  const weekStart = addDaysISO(today, -6);

  const [
    waterEntries,
    waterTotal,
    sleepEntry,
    activityEntries,
    activityTotals,
    meals,
    calorieTotal,
    studySessions,
    studyTotal,
    studyWeek,
    overdueRow,
    completedTodayRow,
    openTasks,
    streakMetrics,
  ] = await Promise.all([
    getWaterEntries(userId, today),
    getWaterTotal(userId, today),
    getSleep(userId, today),
    getActivityEntries(userId, today),
    getDayActivityTotals(userId, today),
    getMeals(userId, today),
    getCalorieTotals(userId, today, today),
    getSessions(userId, today),
    getDayMinutes(userId, today),
    query<{ day: string; total: number }>(
      `SELECT log_date::text AS day, SUM(focus_minutes)::int AS total
       FROM study_sessions
       WHERE user_id = $1 AND log_date BETWEEN $2::date AND $3::date
       GROUP BY log_date`,
      [userId, weekStart, today],
    ),
    query<{ count: number }>(
      `SELECT COUNT(*)::int AS count FROM tasks
       WHERE user_id = $1 AND completed = false AND due_date IS NOT NULL AND due_date < $2::date`,
      [userId, today],
    ),
    query<{ count: number }>(
      `SELECT COUNT(*)::int AS count FROM tasks
       WHERE user_id = $1 AND completed = true AND completed_on = $2::date`,
      [userId, today],
    ),
    query(
      `SELECT id, title, notes, category, due_date::text AS due_date, completed,
              completed_at, created_at, updated_at
       FROM tasks
       WHERE user_id = $1 AND completed = false
       ORDER BY CASE WHEN due_date IS NULL THEN 1 ELSE 0 END, due_date ASC, created_at DESC
       LIMIT 5`,
      [userId],
    ),
    getStreakMetrics(userId, today, settings),
  ]);

  const minutesByDay = new Map(studyWeek.map((row) => [row.day, row.total]));

  return {
    today,
    goals: settings,
    water: { date: today, totalMl: waterTotal, goalMl: settings.waterGoalMl, entries: waterEntries },
    sleep: { date: today, entry: sleepEntry, goalHours: settings.sleepGoalHours },
    activity: {
      date: today,
      steps: activityTotals.steps,
      stepsGoal: settings.stepsGoal,
      exerciseMinutes: activityTotals.exerciseMinutes,
      walkCount: activityTotals.walkCount,
      entries: activityEntries,
    },
    nutrition: {
      date: today,
      totalCalories: calorieTotal.get(today) ?? 0,
      calorieLimit: settings.calorieLimit,
      entries: meals,
    },
    study: {
      date: today,
      totalMinutes: studyTotal,
      goalMinutes: settings.studyGoalMinutes,
      sessions: studySessions,
      last7Days: Array.from({ length: 7 }, (_, index) => {
        const date = addDaysISO(weekStart, index);
        return { date, minutes: minutesByDay.get(date) ?? 0 };
      }),
    },
    tasks: {
      open: openTasks.map(mapTask),
      completedToday: completedTodayRow[0]?.count ?? 0,
      overdue: overdueRow[0]?.count ?? 0,
    },
    streak: computeStreak(streakMetrics.activeDates, today),
  };
}
