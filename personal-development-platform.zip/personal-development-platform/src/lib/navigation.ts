import type { IconName } from '@/components/icons';

export interface NavItem {
  href: string;
  label: string;
  icon: IconName;
  description: string;
}

export const PRIMARY_NAV: NavItem[] = [
  { href: '/', label: 'Dashboard', icon: 'home', description: "Today's snapshot" },
  { href: '/health', label: 'Health', icon: 'heart', description: 'Water, sleep, activity, food' },
  { href: '/study', label: 'Study', icon: 'timer', description: 'Pomodoro and sessions' },
  { href: '/tasks', label: 'Tasks', icon: 'tasks', description: 'Plan and track work' },
  { href: '/analytics', label: 'Analytics', icon: 'chart', description: '7 and 30 day trends' },
];

/** Mobile bottom bar keeps the five primary destinations; settings lives in the header. */
export const MOBILE_NAV = PRIMARY_NAV;

export const SETTINGS_NAV: NavItem = {
  href: '/settings',
  label: 'Settings',
  icon: 'settings',
  description: 'Goals, theme and data',
};

export function isActivePath(pathname: string, href: string): boolean {
  if (href === '/') return pathname === '/';
  return pathname === href || pathname.startsWith(`${href}/`);
}
