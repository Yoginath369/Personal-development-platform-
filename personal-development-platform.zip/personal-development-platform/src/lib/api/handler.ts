import 'server-only';

import { ZodError, type ZodTypeAny, type z } from 'zod';
import { ApiError } from './errors';
import type { ApiErrorBody } from '@/types';

export function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    },
  });
}

function zodToFieldErrors(error: ZodError): Record<string, string[]> {
  const fieldErrors: Record<string, string[]> = {};
  for (const issue of error.issues) {
    const key = issue.path.length > 0 ? issue.path.join('.') : 'form';
    fieldErrors[key] = [...(fieldErrors[key] ?? []), issue.message];
  }
  return fieldErrors;
}

/** Maps thrown errors onto the JSON error contract used by the client. */
export function toErrorResponse(error: unknown): Response {
  if (error instanceof ZodError) {
    const body: ApiErrorBody = {
      error: 'Please check the highlighted fields.',
      fieldErrors: zodToFieldErrors(error),
    };
    return jsonResponse(body, 422);
  }
  if (error instanceof ApiError) {
    const body: ApiErrorBody = { error: error.message, fieldErrors: error.fieldErrors };
    return jsonResponse(body, error.status);
  }
  const message = error instanceof Error ? error.message : 'Unexpected server error';
  // Never leak stack traces or SQL to the client, but keep it in server logs.
  console.error('[api] unhandled error:', message, error instanceof Error ? error.stack : '');
  return jsonResponse({ error: 'Something went wrong on our side. Please try again.' }, 500);
}

/**
 * Wraps a route handler: catches everything, returns JSON, and blocks
 * cross-site state-changing requests (defence in depth on top of SameSite).
 */
export function route<Context = unknown>(
  handler: (request: Request, context: Context) => Promise<Response>,
): (request: Request, context: Context) => Promise<Response> {
  return async (request: Request, context: Context) => {
    try {
      if (!['GET', 'HEAD', 'OPTIONS'].includes(request.method)) {
        assertSameOrigin(request);
      }
      return await handler(request, context);
    } catch (error) {
      return toErrorResponse(error);
    }
  };
}

const LOOPBACK_HOST = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/;

export function assertSameOrigin(request: Request): void {
  const origin = request.headers.get('origin');
  if (!origin) return;

  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    throw new ApiError(403, 'Invalid request origin.');
  }

  const candidateHosts = [
    request.headers.get('x-forwarded-host'),
    request.headers.get('host'),
  ].filter((value): value is string => Boolean(value));

  if (candidateHosts.includes(originHost)) return;

  // Reverse proxies used by preview sandboxes forward `Host: localhost:3000`
  // while the browser's origin is the public host. Relax only in that case;
  // a real deployment (public host header) keeps the strict comparison above.
  if (candidateHosts.some((host) => LOOPBACK_HOST.test(host))) return;

  throw new ApiError(403, 'Cross-site request blocked.');
}

/** Parses + validates a JSON body. Empty bodies and malformed JSON become 400s. */
export async function readJson<S extends ZodTypeAny>(request: Request, schema: S): Promise<z.output<S>> {
  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    throw new ApiError(400, 'Expected a JSON request body.');
  }
  return schema.parse(raw);
}

/** Parses + validates query string params. */
export function readQuery<S extends ZodTypeAny>(request: Request, schema: S): z.output<S> {
  const url = new URL(request.url);
  const entries: Record<string, string> = {};
  url.searchParams.forEach((value, key) => {
    entries[key] = value;
  });
  return schema.parse(entries);
}
