import 'server-only';

import { createHash, randomBytes } from 'node:crypto';
import { cookies } from 'next/headers';
import { createSession, deleteSession, findUserIdBySessionHash } from '@/lib/db/repositories/sessions';
import { findUserById, getSettings } from '@/lib/db/repositories/users';
import type { Settings, User } from '@/types';

export const SESSION_COOKIE = 'pdp_session';
export const SESSION_TTL_DAYS = 30;

function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function generateSessionToken(): string {
  return randomBytes(32).toString('base64url');
}

export function sessionExpiryDate(): Date {
  return new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
}

/** Creates the DB row and sets the httpOnly cookie. */
export async function startSession(userId: string): Promise<void> {
  const token = generateSessionToken();
  const expiresAt = sessionExpiryDate();
  await createSession({ tokenHash: hashToken(token), userId, expiresAt });

  const cookieStore = await cookies();
  cookieStore.set({
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires: expiresAt,
  });
}

export async function endSession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    await deleteSession(hashToken(token)).catch(() => undefined);
  }
  cookieStore.set({
    name: SESSION_COOKIE,
    value: '',
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  });
}

export interface SessionUser {
  user: User;
  settings: Settings;
}

/** Resolves the cookie into a user + settings, or null when unauthenticated. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const userId = await findUserIdBySessionHash(hashToken(token));
  if (!userId) return null;

  const user = await findUserById(userId);
  if (!user) return null;

  const settings = await getSettings(userId);
  return { user, settings };
}

export async function getSessionToken(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(SESSION_COOKIE)?.value ?? null;
}
