import 'server-only';

import { cache } from 'react';
import { redirect } from 'next/navigation';
import { getSessionUser, type SessionUser } from './session';
import { ApiError } from '@/lib/api/errors';

/**
 * `cache` de-duplicates the session lookup between layout, page and metadata
 * inside a single server render.
 */
export const currentSession = cache(async (): Promise<SessionUser | null> => {
  try {
    return await getSessionUser();
  } catch {
    return null;
  }
});

/** For server components: redirects to /login when there is no session. */
export async function requirePageUser(): Promise<SessionUser> {
  const session = await currentSession();
  if (!session) redirect('/login');
  return session;
}

/** For route handlers: throws a 401 that the API wrapper turns into JSON. */
export async function requireApiUser(): Promise<SessionUser> {
  const session = await currentSession();
  if (!session) throw new ApiError(401, 'You need to sign in to do that.');
  return session;
}
