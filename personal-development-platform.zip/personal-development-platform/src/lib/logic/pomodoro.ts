/**
 * Pomodoro state machine - pure, timestamp driven.
 *
 * The UI only renders `remainingMs(state, now)` where `now` is `Date.now()`.
 * Nothing depends on the interval callback firing: if the tab is throttled for
 * ten minutes, the next render/visibility change recomputes the truth from
 * timestamps and emits the same completion events it would have emitted live.
 */

export type PomodoroPhase = 'idle' | 'focus' | 'break';

export interface FocusSessionDraft {
  clientId: string;
  subject: string;
  focusMinutes: number;
  startedAt: number;
  endedAt: number;
}

export type PomodoroEvent =
  | { type: 'focus-completed'; session: FocusSessionDraft }
  | { type: 'break-completed' };

export interface PomodoroState {
  phase: PomodoroPhase;
  focusMinutes: number;
  breakMinutes: number;
  subject: string;
  startedAt: number | null;
  endsAt: number | null;
  pausedRemainingMs: number | null;
  sessionId: string | null;
  completedFocusCount: number;
}

export const FOCUS_OPTIONS = [25, 45, 50] as const;
export const BREAK_MINUTES = 5;

export function initialPomodoroState(subject = ''): PomodoroState {
  return {
    phase: 'idle',
    focusMinutes: 25,
    breakMinutes: BREAK_MINUTES,
    subject,
    startedAt: null,
    endsAt: null,
    pausedRemainingMs: null,
    sessionId: null,
    completedFocusCount: 0,
  };
}

export function remainingMs(state: PomodoroState, now: number): number {
  if (state.phase === 'idle') return state.focusMinutes * 60_000;
  if (state.pausedRemainingMs !== null) return Math.max(0, state.pausedRemainingMs);
  if (state.endsAt === null) return 0;
  return Math.max(0, state.endsAt - now);
}

export function isPaused(state: PomodoroState): boolean {
  return state.pausedRemainingMs !== null;
}

export function isRunning(state: PomodoroState): boolean {
  return state.phase !== 'idle' && state.pausedRemainingMs === null;
}

export function startFocus(
  state: PomodoroState,
  now: number,
  sessionId: string,
): PomodoroState {
  return {
    ...state,
    phase: 'focus',
    startedAt: now,
    endsAt: now + state.focusMinutes * 60_000,
    pausedRemainingMs: null,
    sessionId,
  };
}

export function pause(state: PomodoroState, now: number): PomodoroState {
  if (state.phase === 'idle' || isPaused(state)) return state;
  return { ...state, pausedRemainingMs: remainingMs(state, now), endsAt: null };
}

export function resume(state: PomodoroState, now: number): PomodoroState {
  if (!isPaused(state)) return state;
  const remaining = Math.max(0, state.pausedRemainingMs ?? 0);
  const endsAt = now + remaining;
  const startedAt =
    state.phase === 'focus' && state.startedAt === null
      ? now
      : state.phase === 'focus'
        ? now - (state.focusMinutes * 60_000 - remaining)
        : state.startedAt;
  return { ...state, endsAt, startedAt, pausedRemainingMs: null };
}

/** Abandon the current focus/break block without logging it. */
export function reset(state: PomodoroState, subject = state.subject): PomodoroState {
  return { ...initialPomodoroState(subject), focusMinutes: state.focusMinutes };
}

export function setFocusMinutes(state: PomodoroState, minutes: number): PomodoroState {
  if (state.phase !== 'idle') return state;
  return { ...state, focusMinutes: minutes };
}

export function setSubject(state: PomodoroState, subject: string): PomodoroState {
  return { ...state, subject };
}

/**
 * Advances the machine to `now`. Emits an event for every block that finished
 * in the meantime (a tab that slept through focus *and* break emits both).
 */
export function tick(
  state: PomodoroState,
  now: number,
): { state: PomodoroState; events: PomodoroEvent[] } {
  if (state.phase === 'idle' || state.pausedRemainingMs !== null || state.endsAt === null) {
    return { state, events: [] };
  }

  if (now < state.endsAt) return { state, events: [] };

  if (state.phase === 'focus') {
    const endedAt = state.endsAt;
    const startedAt = state.startedAt ?? endedAt - state.focusMinutes * 60_000;
    const events: PomodoroEvent[] = [
      {
        type: 'focus-completed',
        session: {
          clientId: state.sessionId ?? `s-${startedAt}`,
          subject: state.subject.trim(),
          focusMinutes: state.focusMinutes,
          startedAt,
          endedAt,
        },
      },
    ];

    const breakEndsAt = endedAt + state.breakMinutes * 60_000;
    const nextState: PomodoroState = {
      ...state,
      phase: 'break',
      startedAt: endedAt,
      endsAt: breakEndsAt,
      pausedRemainingMs: null,
      sessionId: null,
      completedFocusCount: state.completedFocusCount + 1,
    };

    if (now >= breakEndsAt) {
      events.push({ type: 'break-completed' });
      return {
        state: {
          ...nextState,
          phase: 'idle',
          startedAt: null,
          endsAt: null,
        },
        events,
      };
    }
    return { state: nextState, events };
  }

  // break completed
  return {
    state: { ...state, phase: 'idle', startedAt: null, endsAt: null, sessionId: null },
    events: [{ type: 'break-completed' }],
  };
}

/** 1_500_000 -> "25:00" (always mm:ss, minutes may exceed 99). */
export function formatClock(ms: number): string {
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${`${minutes}`.padStart(2, '0')}:${`${seconds}`.padStart(2, '0')}`;
}

/** Fraction elapsed 0..1 for the progress ring. */
export function progressFraction(state: PomodoroState, now: number): number {
  const total = (state.phase === 'break' ? state.breakMinutes : state.focusMinutes) * 60_000;
  if (total <= 0) return 0;
  return Math.min(1, Math.max(0, 1 - remainingMs(state, now) / total));
}

/** Serialisable snapshot for localStorage (survives reloads / closed tabs). */
export interface PersistedPomodoro {
  phase: PomodoroPhase;
  focusMinutes: number;
  subject: string;
  startedAt: number | null;
  endsAt: number | null;
  pausedRemainingMs: number | null;
  sessionId: string | null;
  completedFocusCount: number;
}

export function serializePomodoro(state: PomodoroState): PersistedPomodoro {
  return {
    phase: state.phase,
    focusMinutes: state.focusMinutes,
    subject: state.subject,
    startedAt: state.startedAt,
    endsAt: state.endsAt,
    pausedRemainingMs: state.pausedRemainingMs,
    sessionId: state.sessionId,
    completedFocusCount: state.completedFocusCount,
  };
}

export function deserializePomodoro(raw: unknown, fallbackSubject = ''): PomodoroState {
  const base = initialPomodoroState(fallbackSubject);
  if (!raw || typeof raw !== 'object') return base;
  const value = raw as Partial<PersistedPomodoro>;
  const isNumberOrNull = (input: unknown): input is number | null =>
    input === null || (typeof input === 'number' && Number.isFinite(input));

  if (!['idle', 'focus', 'break'].includes(value.phase ?? '')) return base;
  if (typeof value.focusMinutes !== 'number' || !FOCUS_OPTIONS.includes(value.focusMinutes as 25)) {
    return base;
  }
  if (!isNumberOrNull(value.startedAt) || !isNumberOrNull(value.endsAt)) return base;
  if (!isNumberOrNull(value.pausedRemainingMs)) return base;
  if (value.phase !== 'idle' && value.endsAt === null && value.pausedRemainingMs === null) {
    return base;
  }

  return {
    phase: value.phase as PomodoroPhase,
    focusMinutes: value.focusMinutes,
    breakMinutes: BREAK_MINUTES,
    subject: typeof value.subject === 'string' ? value.subject.slice(0, 60) : fallbackSubject,
    startedAt: value.startedAt ?? null,
    endsAt: value.endsAt ?? null,
    pausedRemainingMs: value.pausedRemainingMs ?? null,
    sessionId: typeof value.sessionId === 'string' ? value.sessionId : null,
    completedFocusCount:
      typeof value.completedFocusCount === 'number' && value.completedFocusCount >= 0
        ? Math.floor(value.completedFocusCount)
        : 0,
  };
}
