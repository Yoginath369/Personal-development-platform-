/**
 * Date helpers. Everything the user sees is keyed by a *local* calendar date in
 * the form `YYYY-MM-DD` (the user's own timezone), never by UTC midnight.
 * Pure functions only - no `Date.now()` inside except the documented defaults.
 */

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

/** Converts a JS Date to the ISO date of *that* Date's local calendar day. */
export function toISODate(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/** Today in the runtime's local timezone (browser timezone on the client). */
export function todayISO(now: Date = new Date()): string {
  return toISODate(now);
}

/** Strict validation: format *and* real calendar date (rejects 2026-02-31). */
export function isValidISODate(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const match = ISO_DATE.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return false;
  const probe = new Date(Date.UTC(year, month - 1, day));
  return (
    probe.getUTCFullYear() === year &&
    probe.getUTCMonth() === month - 1 &&
    probe.getUTCDate() === day
  );
}

/** UTC-based calendar arithmetic - immune to DST transitions. */
function toUTCStamp(iso: string): number {
  const [year, month, day] = iso.split('-').map(Number);
  return Date.UTC(year ?? 1970, (month ?? 1) - 1, day ?? 1);
}

function fromUTCStamp(stamp: number): string {
  const d = new Date(stamp);
  const year = d.getUTCFullYear();
  const month = `${d.getUTCMonth() + 1}`.padStart(2, '0');
  const day = `${d.getUTCDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function addDaysISO(iso: string, days: number): string {
  if (!isValidISODate(iso)) throw new Error(`Invalid ISO date: ${iso}`);
  return fromUTCStamp(toUTCStamp(iso) + Math.trunc(days) * 86_400_000);
}

/** Whole days from `a` to `b` (b - a). */
export function daysBetweenISO(a: string, b: string): number {
  if (!isValidISODate(a) || !isValidISODate(b)) {
    throw new Error(`Invalid ISO date range: ${a}..${b}`);
  }
  return Math.round((toUTCStamp(b) - toUTCStamp(a)) / 86_400_000);
}

/** Inclusive list of dates from start to end. Hard-capped at 400 entries. */
export function rangeDates(startISO: string, endISO: string): string[] {
  if (!isValidISODate(startISO) || !isValidISODate(endISO)) {
    throw new Error(`Invalid ISO date range: ${startISO}..${endISO}`);
  }
  const span = daysBetweenISO(startISO, endISO);
  if (span < 0) return [];
  const dates: string[] = [];
  for (let i = 0; i <= Math.min(span, 399); i += 1) {
    dates.push(addDaysISO(startISO, i));
  }
  return dates;
}

/** Milliseconds until the next local midnight (used for rollover refresh). */
export function msUntilNextMidnight(now: Date = new Date()): number {
  const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 50);
  return Math.max(1_000, next.getTime() - now.getTime());
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** "13 Nov" - locale-independent so server and client markup always match. */
export function shortDate(iso: string): string {
  if (!isValidISODate(iso)) return iso;
  const [, month, day] = iso.split('-').map(Number);
  return `${day} ${MONTHS[(month ?? 1) - 1]}`;
}

/** "Thu" */
export function weekdayShort(iso: string): string {
  if (!isValidISODate(iso)) return '';
  const d = new Date(toUTCStamp(iso));
  return WEEKDAYS[d.getUTCDay()] ?? '';
}

/** "Thu, 13 Nov 2026" */
export function longDate(iso: string): string {
  if (!isValidISODate(iso)) return iso;
  const [year] = iso.split('-');
  return `${weekdayShort(iso)}, ${shortDate(iso)} ${year}`;
}

/** "Today" / "Yesterday" / "Thu, 13 Nov 2026" relative to a reference date. */
export function relativeDateLabel(iso: string, today: string): string {
  const diff = daysBetweenISO(iso, today);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff === -1) return 'Tomorrow';
  return longDate(iso);
}

/** Local date for an epoch timestamp (used when a timer crosses midnight). */
export function localDateFromTimestamp(timestampMs: number): string {
  return toISODate(new Date(timestampMs));
}

/** 0..23 local hour for a timestamp. */
export function localHourFromTimestamp(timestampMs: number): number {
  return new Date(timestampMs).getHours();
}
