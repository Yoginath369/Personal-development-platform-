import { addDaysISO } from './dates';

/**
 * Streaks.
 *
 * A day is "active" when the user hit at least one daily goal or completed at
 * least one task. The current streak keeps running if today is not active yet -
 * it only breaks once a whole calendar day is missed.
 */

export function computeStreak(activeDates: Iterable<string>, today: string): number {
  const set = activeDates instanceof Set ? activeDates : new Set(activeDates);
  if (set.size === 0) return 0;

  let cursor = set.has(today) ? today : addDaysISO(today, -1);
  if (!set.has(cursor)) return 0;

  let streak = 0;
  while (set.has(cursor)) {
    streak += 1;
    cursor = addDaysISO(cursor, -1);
  }
  return streak;
}

export function computeBestStreak(activeDates: Iterable<string>): number {
  const dates = Array.from(new Set(activeDates)).sort();
  let best = 0;
  let run = 0;
  let previous: string | null = null;

  for (const date of dates) {
    if (previous !== null && addDaysISO(previous, 1) === date) {
      run += 1;
    } else {
      run = 1;
    }
    if (run > best) best = run;
    previous = date;
  }
  return best;
}
