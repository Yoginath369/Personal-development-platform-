/**
 * Goal / progress maths shared by the dashboard, analytics and tests.
 */

export interface GoalProgress {
  value: number;
  target: number;
  /** 0-100, capped for display. `met` is the source of truth for "done". */
  pct: number;
  met: boolean;
  remaining: number;
  /** Uncapped percentage, useful for "124% of goal" copy. */
  rawPct: number;
}

export function goalProgress(value: number, target: number): GoalProgress {
  const safeValue = Number.isFinite(value) ? Math.max(0, value) : 0;
  const safeTarget = Number.isFinite(target) && target > 0 ? target : 0;
  if (safeTarget === 0) {
    return { value: safeValue, target: 0, pct: 0, met: false, remaining: 0, rawPct: 0 };
  }
  const rawPct = (safeValue / safeTarget) * 100;
  return {
    value: safeValue,
    target: safeTarget,
    pct: Math.min(100, Math.round(rawPct)),
    met: safeValue >= safeTarget,
    remaining: Math.max(0, safeTarget - safeValue),
    rawPct: Math.round(rawPct),
  };
}

/** Progress for limits (calories): "met" means inside the limit. */
export function limitProgress(value: number, limit: number): GoalProgress & { over: boolean; overBy: number } {
  const progress = goalProgress(value, limit);
  const over = limit > 0 && value > limit;
  return { ...progress, over, overBy: over ? value - limit : 0 };
}

export function sum(values: readonly number[]): number {
  return values.reduce((total, value) => total + (Number.isFinite(value) ? value : 0), 0);
}

export function average(values: readonly number[]): number {
  if (values.length === 0) return 0;
  return sum(values) / values.length;
}

export function round(value: number, decimals = 0): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

/** Number of entries in `values` that reach `target`. */
export function countReached(values: readonly number[], target: number): number {
  if (target <= 0) return 0;
  return values.filter((value) => value >= target).length;
}

/** Percentage of a goal string like "3 of 7 days" - used for the analytics grid. */
export function hitRate(hits: number, days: number): number {
  if (days <= 0) return 0;
  return Math.round((hits / days) * 100);
}

/** Human-readable duration: 90 -> "1h 30m", 45 -> "45m", 0 -> "0m". */
export function formatMinutes(totalMinutes: number): string {
  const minutes = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}m`;
  if (mins === 0) return `${hours}h`;
  return `${hours}h ${mins}m`;
}

export function formatMl(ml: number): string {
  if (ml >= 1000) {
    const litres = ml / 1000;
    return `${round(litres, litres % 1 === 0 ? 0 : 1)}L`;
  }
  return `${Math.round(ml)}ml`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(value));
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
