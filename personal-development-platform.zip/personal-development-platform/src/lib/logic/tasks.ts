import type { Task, TaskCategory } from '@/types';
import { daysBetweenISO } from './dates';

export type TaskStatusFilter = 'all' | 'active' | 'completed' | 'overdue';
export type TaskSort = 'due' | 'created' | 'category';

export const TASK_CATEGORIES: TaskCategory[] = ['study', 'personal', 'fitness', 'work'];

export const CATEGORY_LABELS: Record<TaskCategory, string> = {
  study: 'Study',
  personal: 'Personal',
  fitness: 'Fitness',
  work: 'Work',
};

/** A task is overdue only after its due date has passed (today is still on time). */
export function isOverdue(task: Task, today: string): boolean {
  if (task.completed || !task.dueDate) return false;
  return daysBetweenISO(task.dueDate, today) > 0;
}

export function isDueToday(task: Task, today: string): boolean {
  return !task.completed && task.dueDate === today;
}

export function filterTasks(tasks: readonly Task[], filter: TaskStatusFilter, today: string): Task[] {
  switch (filter) {
    case 'active':
      return tasks.filter((task) => !task.completed);
    case 'completed':
      return tasks.filter((task) => task.completed);
    case 'overdue':
      return tasks.filter((task) => isOverdue(task, today));
    case 'all':
    default:
      return [...tasks];
  }
}

export function searchTasks(tasks: readonly Task[], term: string): Task[] {
  const needle = term.trim().toLowerCase();
  if (!needle) return [...tasks];
  return tasks.filter(
    (task) =>
      task.title.toLowerCase().includes(needle) ||
      (task.notes ?? '').toLowerCase().includes(needle) ||
      CATEGORY_LABELS[task.category].toLowerCase().includes(needle),
  );
}

/**
 * Sort order: incomplete before complete, then the chosen key.
 * Missing due dates sink to the bottom of the incomplete list.
 */
export function sortTasks(tasks: readonly Task[], sort: TaskSort): Task[] {
  const copy = [...tasks];
  copy.sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;

    if (sort === 'due') {
      if (a.dueDate && b.dueDate) return a.dueDate.localeCompare(b.dueDate);
      if (a.dueDate) return -1;
      if (b.dueDate) return 1;
      return b.createdAt.localeCompare(a.createdAt);
    }
    if (sort === 'category') {
      const byCategory = a.category.localeCompare(b.category);
      if (byCategory !== 0) return byCategory;
      return a.title.localeCompare(b.title);
    }
    return b.createdAt.localeCompare(a.createdAt);
  });
  return copy;
}

export interface TaskCounts {
  total: number;
  active: number;
  completed: number;
  overdue: number;
  dueToday: number;
  completedToday: number;
}

export function taskCounts(tasks: readonly Task[], today: string): TaskCounts {
  let active = 0;
  let completed = 0;
  let overdue = 0;
  let dueToday = 0;
  let completedToday = 0;

  for (const task of tasks) {
    if (task.completed) {
      completed += 1;
      if (task.completedAt && task.completedAt.slice(0, 10) === today) completedToday += 1;
      continue;
    }
    active += 1;
    if (isOverdue(task, today)) overdue += 1;
    if (isDueToday(task, today)) dueToday += 1;
  }

  return { total: tasks.length, active, completed, overdue, dueToday, completedToday };
}

/** Groups tasks by due date bucket for the "upcoming" list. */
export function groupByDueDate(
  tasks: readonly Task[],
  today: string,
): Array<{ key: string; label: string; tasks: Task[] }> {
  const buckets: Array<{ key: string; label: string; tasks: Task[] }> = [
    { key: 'overdue', label: 'Overdue', tasks: [] },
    { key: 'today', label: 'Due today', tasks: [] },
    { key: 'upcoming', label: 'Upcoming', tasks: [] },
    { key: 'someday', label: 'No due date', tasks: [] },
  ];

  for (const task of tasks) {
    if (task.completed) continue;
    const bucket = !task.dueDate
      ? buckets[3]
      : isOverdue(task, today)
        ? buckets[0]
        : task.dueDate === today
          ? buckets[1]
          : buckets[2];
    bucket?.tasks.push(task);
  }
  return buckets.filter((bucket) => bucket.tasks.length > 0);
}

/** Validates a category coming from the network / storage. */
export function isTaskCategory(value: unknown): value is TaskCategory {
  return typeof value === 'string' && (TASK_CATEGORIES as string[]).includes(value);
}
