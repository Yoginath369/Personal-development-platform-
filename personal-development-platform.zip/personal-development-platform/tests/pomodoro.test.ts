import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BREAK_MINUTES,
  deserializePomodoro,
  formatClock,
  initialPomodoroState,
  isPaused,
  pause,
  progressFraction,
  remainingMs,
  reset,
  resume,
  serializePomodoro,
  setFocusMinutes,
  startFocus,
  tick,
  type PomodoroState,
} from '../src/lib/logic/pomodoro';

const T0 = 1_700_000_000_000; // fixed epoch
const MIN = 60_000;

test('initial state is idle at the chosen focus length', () => {
  const state = initialPomodoroState('Maths');
  assert.equal(state.phase, 'idle');
  assert.equal(state.focusMinutes, 25);
  assert.equal(state.breakMinutes, BREAK_MINUTES);
  assert.equal(state.subject, 'Maths');
  assert.equal(remainingMs(state, T0), 25 * MIN);
});

test('starting a focus block schedules an absolute end timestamp', () => {
  const state = startFocus(initialPomodoroState('Maths'), T0, 'client-1');
  assert.equal(state.phase, 'focus');
  assert.equal(state.endsAt, T0 + 25 * MIN);
  assert.equal(state.startedAt, T0);
  assert.equal(remainingMs(state, T0 + 10 * MIN), 15 * MIN);
});

test('tick before the deadline emits nothing', () => {
  const state = startFocus(initialPomodoroState('Maths'), T0, 'client-1');
  const result = tick(state, T0 + 24 * MIN);
  assert.equal(result.events.length, 0);
  assert.equal(result.state.phase, 'focus');
});

test('tick at the deadline completes the focus block and starts a break', () => {
  const state = startFocus(initialPomodoroState('Maths'), T0, 'client-1');
  const result = tick(state, T0 + 25 * MIN);

  assert.equal(result.events.length, 1);
  const event = result.events[0];
  assert.equal(event?.type, 'focus-completed');
  if (event?.type === 'focus-completed') {
    assert.equal(event.session.focusMinutes, 25);
    assert.equal(event.session.subject, 'Maths');
    assert.equal(event.session.clientId, 'client-1');
    assert.equal(event.session.startedAt, T0);
    assert.equal(event.session.endedAt, T0 + 25 * MIN);
  }
  assert.equal(result.state.phase, 'break');
  assert.equal(result.state.endsAt, T0 + 25 * MIN + 5 * MIN);
  assert.equal(result.state.completedFocusCount, 1);
});

test('a backgrounded tab that oversleeps still logs exactly one focus block', () => {
  const state = startFocus(initialPomodoroState('Chemistry'), T0, 'client-2');
  // Tab was inactive for two hours.
  const result = tick(state, T0 + 120 * MIN);

  const focusEvents = result.events.filter((event) => event.type === 'focus-completed');
  assert.equal(focusEvents.length, 1);
  if (focusEvents[0]?.type === 'focus-completed') {
    // The logged duration is the scheduled block, not the wall clock gap.
    assert.equal(focusEvents[0].session.endedAt - focusEvents[0].session.startedAt, 25 * MIN);
  }
  // Focus + break both finished -> idle.
  assert.equal(result.state.phase, 'idle');
  assert.equal(result.events.some((event) => event.type === 'break-completed'), true);
});

test('the result is identical whether ticked every second or once after a jump', () => {
  let stepped = startFocus(initialPomodoroState('Physics'), T0, 'client-3');
  for (let second = 1; second <= 1500; second += 1) {
    stepped = tick(stepped, T0 + second * 1000).state;
  }
  const jumped = tick(startFocus(initialPomodoroState('Physics'), T0, 'client-3'), T0 + 1500 * 1000).state;

  assert.equal(stepped.phase, jumped.phase);
  assert.equal(stepped.endsAt, jumped.endsAt);
  assert.equal(stepped.completedFocusCount, jumped.completedFocusCount);
});

test('break completion returns to idle without logging a focus session', () => {
  const focus = startFocus(initialPomodoroState('Bio'), T0, 'client-4');
  const inBreak = tick(focus, T0 + 25 * MIN).state;
  const afterBreak = tick(inBreak, T0 + 30 * MIN);
  assert.equal(afterBreak.state.phase, 'idle');
  assert.equal(afterBreak.events.length, 1);
  assert.equal(afterBreak.events[0]?.type, 'break-completed');
});

test('pause freezes the remainder and resume re-anchors it', () => {
  const running = startFocus(initialPomodoroState('Maths'), T0, 'client-5');
  const paused = pause(running, T0 + 5 * MIN);
  assert.equal(isPaused(paused), true);
  assert.equal(remainingMs(paused, T0 + 20 * MIN), 20 * MIN);

  // Time keeps passing while paused, but nothing is emitted.
  const duringPause = tick(paused, T0 + 60 * MIN);
  assert.equal(duringPause.events.length, 0);
  assert.equal(duringPause.state.phase, 'focus');

  const resumed = resume(paused, T0 + 60 * MIN);
  assert.equal(resumed.pausedRemainingMs, null);
  assert.equal(remainingMs(resumed, T0 + 60 * MIN), 20 * MIN);
  assert.equal(remainingMs(resumed, T0 + 65 * MIN), 15 * MIN);
});

test('cancelling a block leaves no session behind', () => {
  const running = startFocus(initialPomodoroState('Maths'), T0, 'client-6');
  const cleared = reset(running, 'Maths');
  assert.equal(cleared.phase, 'idle');
  assert.equal(cleared.endsAt, null);
  assert.equal(cleared.sessionId, null);
  assert.equal(cleared.completedFocusCount, 0);
});

test('focus length can only change while idle', () => {
  const idle = setFocusMinutes(initialPomodoroState(), 50);
  assert.equal(idle.focusMinutes, 50);
  assert.equal(remainingMs(idle, T0), 50 * MIN);

  const running = startFocus(initialPomodoroState(), T0, 'client-7');
  assert.equal(setFocusMinutes(running, 45).focusMinutes, 25);
});

test('formatClock renders mm:ss', () => {
  assert.equal(formatClock(0), '00:00');
  assert.equal(formatClock(61_000), '01:01');
  assert.equal(formatClock(25 * MIN), '25:00');
  assert.equal(formatClock(999), '00:01');
  assert.equal(formatClock(-5000), '00:00');
});

test('progressFraction moves from 0 to 1', () => {
  const state = startFocus(initialPomodoroState(), T0, 'client-8');
  assert.equal(progressFraction(state, T0), 0);
  assert.equal(progressFraction(state, T0 + 12.5 * MIN), 0.5);
  assert.equal(progressFraction(state, T0 + 25 * MIN), 1);
});

test('persisted state round-trips and rejects corrupt data', () => {
  const state: PomodoroState = startFocus(initialPomodoroState('History'), T0, 'client-9');
  const restored = deserializePomodoro(JSON.parse(JSON.stringify(serializePomodoro(state))), '');
  assert.deepEqual(restored, state);

  assert.equal(deserializePomodoro(null).phase, 'idle');
  assert.equal(deserializePomodoro({ phase: 'nonsense' }).phase, 'idle');
  assert.equal(deserializePomodoro({ phase: 'focus', focusMinutes: 25 }).phase, 'idle');
  assert.equal(
    deserializePomodoro({ phase: 'focus', focusMinutes: 30, endsAt: T0 + MIN }).phase,
    'idle',
  );
});

test('a restored timer that expired while the tab was closed logs the session on first tick', () => {
  const state = startFocus(initialPomodoroState('Spanish'), T0, 'client-10');
  const restored = deserializePomodoro(serializePomodoro(state));
  const result = tick(restored, T0 + 26 * MIN);
  assert.equal(result.state.phase, 'break');
  assert.equal(result.events[0]?.type, 'focus-completed');
});
