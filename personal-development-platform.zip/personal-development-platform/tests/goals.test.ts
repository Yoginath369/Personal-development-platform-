import test from 'node:test';
import assert from 'node:assert/strict';
import {
  average,
  clamp,
  countReached,
  formatMinutes,
  formatMl,
  formatNumber,
  goalProgress,
  hitRate,
  limitProgress,
  round,
  sum,
} from '../src/lib/logic/goals';

test('goalProgress computes percentages and completion', () => {
  const progress = goalProgress(1500, 2500);
  assert.equal(progress.pct, 60);
  assert.equal(progress.met, false);
  assert.equal(progress.remaining, 1000);
  assert.equal(progress.rawPct, 60);

  const met = goalProgress(2500, 2500);
  assert.equal(met.met, true);
  assert.equal(met.pct, 100);
  assert.equal(met.remaining, 0);
});

test('goalProgress caps the bar but keeps the raw percentage', () => {
  const over = goalProgress(5000, 2500);
  assert.equal(over.pct, 100);
  assert.equal(over.rawPct, 200);
  assert.equal(over.met, true);
});

test('goalProgress handles zero, negative and invalid values safely', () => {
  assert.deepEqual(goalProgress(0, 0), { value: 0, target: 0, pct: 0, met: false, remaining: 0, rawPct: 0 });
  assert.equal(goalProgress(-50, 2500).value, 0);
  assert.equal(goalProgress(Number.NaN, 2500).pct, 0);
  assert.equal(goalProgress(100, Number.NaN).pct, 0);
});

test('limitProgress flags calories over the limit', () => {
  const under = limitProgress(1800, 2200);
  assert.equal(under.over, false);
  assert.equal(under.overBy, 0);

  const over = limitProgress(2500, 2200);
  assert.equal(over.over, true);
  assert.equal(over.overBy, 300);
  assert.equal(over.pct, 100);
});

test('aggregate helpers', () => {
  assert.equal(sum([1, 2, 3]), 6);
  assert.equal(sum([]), 0);
  assert.equal(sum([1, Number.NaN as unknown as number, 2]), 3);
  assert.equal(average([2, 4, 6]), 4);
  assert.equal(average([]), 0);
  assert.equal(countReached([1000, 2500, 3000], 2500), 2);
  assert.equal(countReached([100], 0), 0);
  assert.equal(hitRate(3, 7), 43);
  assert.equal(hitRate(0, 0), 0);
  assert.equal(round(1.25, 1), 1.3);
  assert.equal(clamp(150, 0, 100), 100);
});

test('formatting helpers produce readable values', () => {
  assert.equal(formatMinutes(0), '0m');
  assert.equal(formatMinutes(25), '25m');
  assert.equal(formatMinutes(60), '1h');
  assert.equal(formatMinutes(90), '1h 30m');
  assert.equal(formatMinutes(1234), '20h 34m');
  assert.equal(formatMinutes(-5), '0m');
  assert.equal(formatMl(250), '250ml');
  assert.equal(formatMl(1000), '1L');
  assert.equal(formatMl(1500), '1.5L');
  assert.equal(formatNumber(8000), '8,000');
});
