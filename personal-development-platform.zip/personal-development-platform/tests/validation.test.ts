import test from 'node:test';
import assert from 'node:assert/strict';
import {
  activityCreateSchema,
  loginSchema,
  mealCreateSchema,
  registerSchema,
  settingsPatchSchema,
  sleepWriteSchema,
  studyCreateSchema,
  taskCreateSchema,
  taskUpdateSchema,
  waterCreateSchema,
} from '../src/lib/validation/schemas';

const DATE = '2026-11-13';

test('register rejects short passwords, bad emails and empty names', () => {
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'a@b.co', password: 'abcd1234' }).success, true);
  assert.equal(registerSchema.safeParse({ name: '', email: 'a@b.co', password: 'abcd1234' }).success, false);
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'not-an-email', password: 'abcd1234' }).success, false);
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'a@b.co', password: 'short1' }).success, false);
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'a@b.co', password: 'abcdefgh' }).success, false);
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'a@b.co', password: '12345678' }).success, false);
  assert.equal(registerSchema.safeParse({ name: 'Al', email: 'a@b.co', password: 'a'.repeat(101) + '1' }).success, false);
});

test('register normalises email casing and trims names', () => {
  const parsed = registerSchema.parse({ name: '  Ada   Lovelace ', email: ' ADA@Example.COM ', password: 'abcd1234' });
  assert.equal(parsed.email, 'ada@example.com');
  assert.equal(parsed.name, 'Ada Lovelace');
});

test('login accepts any non-empty password', () => {
  assert.equal(loginSchema.safeParse({ email: 'a@b.co', password: 'x' }).success, true);
  assert.equal(loginSchema.safeParse({ email: 'a@b.co', password: '' }).success, false);
});

test('water rejects zero, negative, huge and non-numeric amounts', () => {
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: 250 }).success, true);
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: 0 }).success, false);
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: -250 }).success, false);
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: 5001 }).success, false);
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: 250.5 }).success, false);
  assert.equal(waterCreateSchema.safeParse({ date: DATE, amountMl: 'abc' }).success, false);
  assert.equal(waterCreateSchema.safeParse({ date: '2026-02-31', amountMl: 250 }).success, false);
});

test('sleep enforces the 0.25–24 hour range and 1–5 quality', () => {
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 7.5, quality: 4 }).success, true);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 0, quality: 4 }).success, false);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: -1, quality: 4 }).success, false);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 25, quality: 4 }).success, false);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 7, quality: 0 }).success, false);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 7, quality: 6 }).success, false);
  assert.equal(sleepWriteSchema.safeParse({ date: DATE, hours: 7, quality: 3.5 }).success, false);
});

test('activity discriminated union validates both kinds', () => {
  assert.equal(activityCreateSchema.safeParse({ kind: 'steps', date: DATE, steps: 1200 }).success, true);
  assert.equal(activityCreateSchema.safeParse({ kind: 'steps', date: DATE, steps: -5 }).success, false);
  assert.equal(activityCreateSchema.safeParse({ kind: 'steps', date: DATE, steps: 300000 }).success, false);
  assert.equal(
    activityCreateSchema.safeParse({ kind: 'exercise', date: DATE, exerciseType: 'Walk', durationMinutes: 30 })
      .success,
    true,
  );
  assert.equal(
    activityCreateSchema.safeParse({ kind: 'exercise', date: DATE, exerciseType: 'W', durationMinutes: 30 })
      .success,
    false,
  );
  assert.equal(
    activityCreateSchema.safeParse({ kind: 'exercise', date: DATE, exerciseType: 'Walk', durationMinutes: 0 })
      .success,
    false,
  );
  assert.equal(activityCreateSchema.safeParse({ kind: 'other', date: DATE }).success, false);
});

test('meals require a name, calories in range and a valid type', () => {
  assert.equal(
    mealCreateSchema.safeParse({ date: DATE, name: 'Oats', calories: 350, mealType: 'breakfast' }).success,
    true,
  );
  assert.equal(mealCreateSchema.safeParse({ date: DATE, name: '', calories: 350, mealType: 'lunch' }).success, false);
  assert.equal(mealCreateSchema.safeParse({ date: DATE, name: 'Oats', calories: 0, mealType: 'lunch' }).success, false);
  assert.equal(
    mealCreateSchema.safeParse({ date: DATE, name: 'Oats', calories: 6000, mealType: 'lunch' }).success,
    false,
  );
  assert.equal(
    mealCreateSchema.safeParse({ date: DATE, name: 'Oats', calories: 300, mealType: 'brunch' }).success,
    false,
  );
});

test('study sessions default the subject and reject inverted timestamps', () => {
  const base = {
    clientId: 'abcdef12-3456-7890',
    focusMinutes: 25,
    startedAt: '2026-11-13T09:00:00.000Z',
    endedAt: '2026-11-13T09:25:00.000Z',
    date: DATE,
  };
  assert.equal(studyCreateSchema.safeParse(base).success, true);
  assert.equal(studyCreateSchema.parse(base).subject, 'General');

  assert.equal(studyCreateSchema.safeParse({ ...base, subject: '  Maths  ' }).success, true);
  assert.equal(studyCreateSchema.parse({ ...base, subject: '  Maths  ' }).subject, 'Maths');

  assert.equal(studyCreateSchema.safeParse({ ...base, focusMinutes: 0 }).success, false);
  assert.equal(studyCreateSchema.safeParse({ ...base, focusMinutes: 300 }).success, false);
  assert.equal(studyCreateSchema.safeParse({ ...base, clientId: 'short' }).success, false);
  assert.equal(
    studyCreateSchema.safeParse({ ...base, endedAt: '2026-11-13T08:00:00.000Z' }).success,
    false,
  );
  assert.equal(studyCreateSchema.safeParse({ ...base, startedAt: 'not-a-date' }).success, false);
});

test('tasks validate title, notes, category and due date', () => {
  assert.equal(
    taskCreateSchema.safeParse({ title: 'Study', category: 'study', dueDate: DATE }).success,
    true,
  );
  assert.equal(taskCreateSchema.safeParse({ title: '   ', category: 'study' }).success, false);
  assert.equal(taskCreateSchema.safeParse({ title: 'x'.repeat(121), category: 'study' }).success, false);
  assert.equal(taskCreateSchema.safeParse({ title: 'Study', category: 'hobby' }).success, false);
  assert.equal(taskCreateSchema.safeParse({ title: 'Study', category: 'study', notes: 'y'.repeat(1001) }).success, false);
  assert.equal(taskCreateSchema.safeParse({ title: 'Study', category: 'study', dueDate: '2026-02-31' }).success, false);

  assert.equal(taskCreateSchema.parse({ title: 'Study', category: 'study', dueDate: '' }).dueDate, null);
  assert.equal(taskCreateSchema.parse({ title: 'Study', category: 'study' }).dueDate, null);
  assert.equal(taskCreateSchema.parse({ title: 'Study', category: 'study', notes: '  ' }).notes, null);
});

test('task updates accept partial payloads but reject empty ones', () => {
  assert.equal(taskUpdateSchema.safeParse({ completed: true }).success, true);
  assert.equal(taskUpdateSchema.safeParse({ title: 'New title' }).success, true);
  assert.equal(taskUpdateSchema.safeParse({}).success, false);
  assert.equal(taskUpdateSchema.safeParse({ title: '' }).success, false);
});

test('settings bounds prevent absurd goals and unknown themes', () => {
  assert.equal(settingsPatchSchema.safeParse({ waterGoalMl: 2500 }).success, true);
  assert.equal(settingsPatchSchema.safeParse({ waterGoalMl: 0 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ waterGoalMl: 50000 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ sleepGoalHours: 30 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ stepsGoal: 50 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ calorieLimit: 100 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ studyGoalMinutes: 0 }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ theme: 'neon' }).success, false);
  assert.equal(settingsPatchSchema.safeParse({ theme: 'dark' }).success, true);
  assert.equal(settingsPatchSchema.safeParse({}).success, false);
});
