import test from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../src/types';
import {
  filterTasks,
  groupByDueDate,
  isOverdue,
  searchTasks,
  sortTasks,
  taskCounts,
  taskCounts as counts,
} from '../src/lib/logic/tasks';

const TODAY = '2026-11-13';

function makeTask(overrides: Partial<Task> & Pick<Task, 'id' | 'title'>): Task {
  return {
    notes: null,
    category: 'personal',
    dueDate: null,
    completed: false,
    completedAt: null,
    createdAt: '2026-11-01T10:00:00.000Z',
    updatedAt: '2026-11-01T10:00:00.000Z',
    ...overrides,
  };
}

const tasks: Task[] = [
  makeTask({ id: '1', title: 'Revise calculus', category: 'study', dueDate: '2026-11-10' }),
  makeTask({ id: '2', title: 'Gym session', category: 'fitness', dueDate: TODAY }),
  makeTask({ id: '3', title: 'Send invoice', category: 'work', dueDate: '2026-11-20' }),
  makeTask({ id: '4', title: 'Call mother', dueDate: null }),
  makeTask({
    id: '5',
    title: 'Read 20 pages',
    category: 'study',
    dueDate: '2026-11-12',
    completed: true,
    completedAt: '2026-11-12T18:00:00.000Z',
  }),
];

test('overdue only applies to open tasks past their due date', () => {
  assert.equal(isOverdue(tasks[0] as Task, TODAY), true);
  assert.equal(isOverdue(tasks[1] as Task, TODAY), false);
  assert.equal(isOverdue(tasks[2] as Task, TODAY), false);
  assert.equal(isOverdue(tasks[3] as Task, TODAY), false);
  assert.equal(isOverdue(tasks[4] as Task, TODAY), false);
});

test('filterTasks splits by status', () => {
  assert.equal(filterTasks(tasks, 'all', TODAY).length, 5);
  assert.equal(filterTasks(tasks, 'active', TODAY).length, 4);
  assert.equal(filterTasks(tasks, 'completed', TODAY).length, 1);
  assert.deepEqual(
    filterTasks(tasks, 'overdue', TODAY).map((task) => task.id),
    ['1'],
  );
  assert.equal(filterTasks([], 'all', TODAY).length, 0);
});

test('searchTasks matches title, notes and category case-insensitively', () => {
  assert.deepEqual(searchTasks(tasks, 'CALC').map((task) => task.id), ['1']);
  assert.deepEqual(searchTasks(tasks, 'gym').map((task) => task.id), ['2']);
  assert.deepEqual(searchTasks(tasks, 'work').map((task) => task.id), ['3']);
  assert.equal(searchTasks(tasks, '   ').length, 5);
  assert.equal(searchTasks(tasks, 'zzz').length, 0);
});

test('sortTasks keeps open tasks first and orders by due date', () => {
  const sorted = sortTasks(tasks, 'due');
  assert.deepEqual(
    sorted.map((task) => task.id),
    ['1', '2', '3', '4', '5'],
  );
});

test('sorting by creation puts the newest open task first', () => {
  const newest = makeTask({ id: '6', title: 'Latest', createdAt: '2026-11-13T08:00:00.000Z' });
  const sorted = sortTasks([...tasks, newest], 'created');
  assert.equal(sorted[0]?.id, '6');
  assert.equal(sorted[sorted.length - 1]?.completed, true);
});

test('sorting by category groups deterministically', () => {
  const sorted = sortTasks(tasks, 'category');
  const categories = sorted.filter((task) => !task.completed).map((task) => task.category);
  assert.deepEqual(categories, [...categories].sort());
});

test('taskCounts summarises the list for a date', () => {
  const summary = counts(tasks, TODAY);
  assert.equal(summary.total, 5);
  assert.equal(summary.active, 4);
  assert.equal(summary.completed, 1);
  assert.equal(summary.overdue, 1);
  assert.equal(summary.dueToday, 1);
  assert.equal(summary.completedToday, 0);
});

test('completed-on-today is counted from completedAt', () => {
  const task = makeTask({
    id: '7',
    title: 'Done today',
    completed: true,
    completedAt: `${TODAY}T09:00:00.000Z`,
  });
  assert.equal(taskCounts([task], TODAY).completedToday, 1);
});

test('groupByDueDate buckets open tasks and skips empty groups', () => {
  const groups = groupByDueDate(tasks, TODAY);
  assert.deepEqual(
    groups.map((group) => group.key),
    ['overdue', 'today', 'upcoming', 'someday'],
  );
  assert.equal(groups[0]?.tasks.length, 1);
  assert.equal(groupByDueDate([], TODAY).length, 0);
});

test('empty lists produce zeroed counts', () => {
  const summary = taskCounts([], TODAY);
  assert.deepEqual(summary, {
    total: 0,
    active: 0,
    completed: 0,
    overdue: 0,
    dueToday: 0,
    completedToday: 0,
  });
});
