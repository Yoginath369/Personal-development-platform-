import test from 'node:test';
import assert from 'node:assert/strict';
import { computeBestStreak, computeStreak } from '../src/lib/logic/streak';

const TODAY = '2026-11-13';

test('no active days means no streak', () => {
  assert.equal(computeStreak([], TODAY), 0);
  assert.equal(computeBestStreak([]), 0);
});

test('consecutive days ending today', () => {
  const dates = ['2026-11-11', '2026-11-12', '2026-11-13'];
  assert.equal(computeStreak(dates, TODAY), 3);
});

test('a streak survives until a full day is missed', () => {
  // Today not logged yet, yesterday was -> streak still alive.
  assert.equal(computeStreak(['2026-11-11', '2026-11-12'], TODAY), 2);
  // Yesterday missing -> streak broken.
  assert.equal(computeStreak(['2026-11-10', '2026-11-11'], TODAY), 0);
});

test('a gap in the middle stops the count', () => {
  const dates = ['2026-11-09', '2026-11-10', '2026-11-12', '2026-11-13'];
  assert.equal(computeStreak(dates, TODAY), 2);
  assert.equal(computeBestStreak(dates), 2);
});

test('streak crosses month and year boundaries', () => {
  assert.equal(computeStreak(['2025-12-30', '2025-12-31', '2026-01-01'], '2026-01-01'), 3);
  assert.equal(
    computeStreak(['2026-10-31', '2026-11-01', '2026-11-02', '2026-11-03'], '2026-11-03'),
    4,
  );
});

test('duplicates and unordered input do not inflate the streak', () => {
  const dates = ['2026-11-13', '2026-11-13', '2026-11-12', '2026-11-12', '2026-11-11'];
  assert.equal(computeStreak(dates, TODAY), 3);
  assert.equal(computeBestStreak(dates), 3);
});

test('best streak finds the longest historical run', () => {
  const dates = [
    '2026-10-01',
    '2026-10-02',
    '2026-10-03',
    '2026-10-04',
    '2026-10-10',
    '2026-10-11',
    '2026-11-13',
  ];
  assert.equal(computeBestStreak(dates), 4);
  assert.equal(computeStreak(dates, TODAY), 1);
});

test('leap day is a normal day in the sequence', () => {
  assert.equal(computeStreak(['2024-02-28', '2024-02-29', '2024-03-01'], '2024-03-01'), 3);
});
