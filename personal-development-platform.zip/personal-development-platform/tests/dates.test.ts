import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDaysISO,
  daysBetweenISO,
  isValidISODate,
  localDateFromTimestamp,
  longDate,
  msUntilNextMidnight,
  rangeDates,
  relativeDateLabel,
  shortDate,
  toISODate,
  todayISO,
  weekdayShort,
} from '../src/lib/logic/dates';

test('toISODate uses local calendar fields, not UTC', () => {
  assert.equal(toISODate(new Date(2026, 0, 1, 0, 0, 0)), '2026-01-01');
  assert.equal(toISODate(new Date(2026, 11, 31, 23, 59, 59)), '2026-12-31');
  assert.equal(toISODate(new Date(2026, 10, 13, 12, 0, 0)), '2026-11-13');
  // No timezone suffix -> parsed as local time, so the calendar day is stable.
  assert.equal(toISODate(new Date('2026-11-13T00:30:00')), '2026-11-13');
});

test('todayISO mirrors toISODate for the current instant', () => {
  const now = new Date(2026, 10, 13, 9, 30, 0);
  assert.equal(todayISO(now), '2026-11-13');
});

test('midnight rollover changes the date exactly at 00:00 local', () => {
  const before = new Date(2026, 10, 13, 23, 59, 59, 999);
  const after = new Date(2026, 10, 14, 0, 0, 0, 0);
  assert.equal(todayISO(before), '2026-11-13');
  assert.equal(todayISO(after), '2026-11-14');
  assert.equal(localDateFromTimestamp(before.getTime()), '2026-11-13');
  assert.equal(localDateFromTimestamp(after.getTime()), '2026-11-14');
});

test('isValidISODate rejects malformed and impossible dates', () => {
  assert.equal(isValidISODate('2026-11-13'), true);
  assert.equal(isValidISODate('2024-02-29'), true);
  assert.equal(isValidISODate('2026-02-29'), false);
  assert.equal(isValidISODate('2026-02-31'), false);
  assert.equal(isValidISODate('2026-13-01'), false);
  assert.equal(isValidISODate('13-11-2026'), false);
  assert.equal(isValidISODate('2026-1-3'), false);
  assert.equal(isValidISODate(''), false);
  assert.equal(isValidISODate('2026-11-13T00:00:00Z'), false);
  assert.equal(isValidISODate(20260113), false);
  assert.equal(isValidISODate(null), false);
  assert.equal(isValidISODate(undefined), false);
});

test('addDaysISO crossing months, years and leap days', () => {
  assert.equal(addDaysISO('2026-11-13', 1), '2026-11-14');
  assert.equal(addDaysISO('2026-11-30', 1), '2026-12-01');
  assert.equal(addDaysISO('2026-12-31', 1), '2027-01-01');
  assert.equal(addDaysISO('2027-01-01', -1), '2026-12-31');
  assert.equal(addDaysISO('2024-02-28', 1), '2024-02-29');
  assert.equal(addDaysISO('2024-02-29', 1), '2024-03-01');
  assert.equal(addDaysISO('2026-03-01', -1), '2026-02-28');
  assert.equal(addDaysISO('2026-11-13', 0), '2026-11-13');
  // 400 day window used by the streak calculation
  assert.equal(addDaysISO('2026-11-13', -399), '2025-10-10');
});

test('addDaysISO is DST safe (calendar days, not 24h blocks)', () => {
  // US spring-forward (2026-03-08) and EU fall-back (2026-10-25) boundaries.
  assert.equal(addDaysISO('2026-03-07', 1), '2026-03-08');
  assert.equal(addDaysISO('2026-03-08', 1), '2026-03-09');
  assert.equal(addDaysISO('2026-10-24', 1), '2026-10-25');
  assert.equal(addDaysISO('2026-10-25', 1), '2026-10-26');
});

test('daysBetweenISO returns signed day differences', () => {
  assert.equal(daysBetweenISO('2026-11-13', '2026-11-13'), 0);
  assert.equal(daysBetweenISO('2026-11-13', '2026-11-20'), 7);
  assert.equal(daysBetweenISO('2026-11-20', '2026-11-13'), -7);
  assert.equal(daysBetweenISO('2026-03-07', '2026-03-09'), 2);
  assert.equal(daysBetweenISO('2025-12-31', '2026-01-01'), 1);
});

test('rangeDates is inclusive and capped', () => {
  assert.deepEqual(rangeDates('2026-11-11', '2026-11-13'), ['2026-11-11', '2026-11-12', '2026-11-13']);
  assert.equal(rangeDates('2026-10-15', '2026-11-13').length, 30);
  assert.equal(rangeDates('2026-11-13', '2026-11-14').length, 2);
  assert.deepEqual(rangeDates('2026-11-13', '2026-11-12'), []);
  assert.equal(rangeDates('2020-01-01', '2026-11-13').length, 400);
});

test('msUntilNextMidnight is positive and under a day', () => {
  const now = new Date(2026, 10, 13, 23, 0, 0);
  const ms = msUntilNextMidnight(now);
  assert.ok(ms > 0);
  assert.ok(ms <= 24 * 60 * 60 * 1000);
  assert.ok(ms <= 60 * 60 * 1000 + 100);
});

test('display helpers are deterministic', () => {
  assert.equal(shortDate('2026-11-13'), '13 Nov');
  assert.equal(weekdayShort('2026-11-13'), 'Fri');
  assert.equal(longDate('2026-11-13'), 'Fri, 13 Nov 2026');
  assert.equal(relativeDateLabel('2026-11-13', '2026-11-13'), 'Today');
  assert.equal(relativeDateLabel('2026-11-12', '2026-11-13'), 'Yesterday');
  assert.equal(relativeDateLabel('2026-11-14', '2026-11-13'), 'Tomorrow');
  assert.equal(relativeDateLabel('2026-11-01', '2026-11-13'), 'Sun, 1 Nov 2026');
  assert.equal(shortDate('bogus'), 'bogus');
});

test('invalid input throws rather than silently corrupting data', () => {
  assert.throws(() => addDaysISO('2026-02-31', 1));
  assert.throws(() => daysBetweenISO('nope', '2026-11-13'));
  assert.throws(() => rangeDates('2026-13-01', '2026-11-13'));
});
