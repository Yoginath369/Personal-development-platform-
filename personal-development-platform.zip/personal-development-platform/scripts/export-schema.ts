/**
 * Writes db/schema.sql from the canonical SCHEMA_SQL constant so the SQL that
 * ships to PostgreSQL is byte-identical to what the app applies at runtime.
 *
 * Usage: npm run db:schema
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SCHEMA_SQL } from '../src/lib/db/schema';

const here = dirname(fileURLToPath(import.meta.url));
const targetDir = resolve(here, '../db');
mkdirSync(targetDir, { recursive: true });

const body = `-- Personal Development Platform - PostgreSQL schema
-- Generated from src/lib/db/schema.ts. Do not edit by hand.
-- Apply with: psql "$DATABASE_URL" -f db/schema.sql
-- Every statement is idempotent, so re-running is safe.

${SCHEMA_SQL.trim()}
`;

writeFileSync(resolve(targetDir, 'schema.sql'), body, 'utf8');
console.log(`Wrote db/schema.sql (${body.length} bytes)`);
