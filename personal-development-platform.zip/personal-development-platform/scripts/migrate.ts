/**
 * Applies the idempotent schema to the database in DATABASE_URL.
 * Usage: npm run db:migrate
 */
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

async function main() {
  // Imported through a function so the script works whether it is executed with
  // tsx (TS source) or from a compiled build.
  const { SCHEMA_SQL } = await import(resolve(here, '../src/lib/db/schema.ts'));

  const url = (process.env.DATABASE_URL ?? '').trim();
  if (!url) {
    console.error(
      'DATABASE_URL is not set. The app falls back to embedded PGlite locally, which migrates itself on first use.',
    );
    process.exitCode = 1;
    return;
  }

  const { default: pg } = await import('pg');
  const needsSsl = !/localhost|127\.0\.0\.1|::1/.test(url);
  const pool = new pg.Pool({
    connectionString: url,
    ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
  });

  try {
    console.log('Applying schema…');
    await pool.query(SCHEMA_SQL);
    console.log('Schema applied. Writing db/schema.sql snapshot…');

    const { writeFileSync, mkdirSync } = await import('node:fs');
    mkdirSync(resolve(here, '../db'), { recursive: true });
    writeFileSync(
      resolve(here, '../db/schema.sql'),
      `-- Generated from src/lib/db/schema.ts - do not edit by hand.\n-- Apply with: psql "$DATABASE_URL" -f db/schema.sql\n\n${SCHEMA_SQL}\n`,
      'utf8',
    );
    console.log('Done.');
  } catch (error) {
    console.error('Migration failed:', error instanceof Error ? error.message : error);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

// Touch the local schema file so bundlers keep it; also proves the file exists.
try {
  readFileSync(resolve(here, '../src/lib/db/schema.ts'), 'utf8');
} catch {
  console.error('Cannot find src/lib/db/schema.ts');
  process.exit(1);
}

void main();
